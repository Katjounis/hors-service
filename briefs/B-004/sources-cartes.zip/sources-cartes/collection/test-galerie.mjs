// Essais de la galerie : erreurs, grille, visionneuse, retournement, fluidité, téléphone, animations réduites.
import { createRequire } from 'node:module';
const { chromium, devices } = createRequire(import.meta.url)('playwright');
const page = 'file://' + new URL('./galerie-100-skins.html', import.meta.url).pathname;
const b = await chromium.launch(); const res = [];
const ips = (p) => p.evaluate(() => new Promise((ok) => { let nb = 0, pire = 0, av = performance.now(); const t0 = av; (function f(t) { nb++; pire = Math.max(pire, t - av); av = t; if (t - t0 < 2500) requestAnimationFrame(f); else ok({ ips: Math.round(nb / ((t - t0) / 1000)), pire: Math.round(pire) }); })(performance.now()); }));
for (const [nom, opts] of [['ordinateur', { viewport: { width: 1280, height: 860 } }], ['téléphone', { ...devices['iPhone 13'] }]]) {
  const c = await b.newContext(opts); const p = await c.newPage(); const errs = []; p.on('pageerror', (e) => errs.push(e.message)); p.on('console', (m) => { if (m.type() === 'error') errs.push(m.text()); });
  await p.goto(page); await p.waitForTimeout(900);
  const g = await p.evaluate(() => ({ tuiles: document.querySelectorAll('.vignette').length, dessinees: document.querySelectorAll('.vignette[data-pret]').length, largeur: document.documentElement.scrollWidth, fenetre: innerWidth, anims: document.getAnimations().filter((a) => a.playState === 'running').length }));
  res.push(`${nom} : ${g.tuiles} vignettes, ${g.dessinees} dessinées au départ, page ${g.largeur}/${g.fenetre} px, ${g.anims} animations, ${JSON.stringify(await ips(p))}`);
  await p.screenshot({ path: `vues/galerie-${nom}.png` });
  // filtre légendaires puis ouverture du premier
  await p.locator('.filtre[data-r="Légendaire"]').click(); await p.waitForTimeout(400);
  const visibles = await p.evaluate(() => [...document.querySelectorAll('.vignette')].filter((v) => !v.hidden).length);
  await p.locator('.vignette:not([hidden])').first().click(); await p.waitForTimeout(800);
  const v = await p.evaluate(() => ({ ouvert: document.getElementById('visionneuse').open, titre: document.getElementById('v-titre')?.textContent, minis: document.querySelectorAll('.mini').length, anims: document.getElementById('v-anims')?.textContent, largeur: document.documentElement.scrollWidth }));
  res.push(`  filtre Légendaires : ${visibles} visibles ; visionneuse ${v.ouvert ? 'ouverte' : 'FERMÉE'} sur « ${v.titre} », ${v.minis} petites cartes, ${v.anims} ; ${JSON.stringify(await ips(p))}`);
  await p.locator('.bascule').click(); await p.waitForTimeout(1200); await p.screenshot({ path: `vues/visionneuse-${nom}.png` });
  await p.locator('.mini').nth(1).click(); await p.waitForTimeout(900);
  const dame = await p.evaluate(() => document.querySelector('.bascule .recto svg')?.getAttribute('aria-label'));
  await p.locator('#v-apres').click(); await p.waitForTimeout(600); const suivant = await p.evaluate(() => document.getElementById('v-titre')?.textContent);
  await p.keyboard.press('Escape'); await p.waitForTimeout(300); const ferme = await p.evaluate(() => !document.getElementById('visionneuse').open);
  res.push(`  petite carte 2 → ${dame} ; suivant → ${suivant} ; Échap ferme : ${ferme}`);
  await p.locator('.filtre').first().click(); await p.locator('#calme').click(); await p.waitForTimeout(300);
  res.push(`  animations réduites : ${await p.evaluate(() => document.getAnimations().filter((a) => a.playState === 'running').length)} animations en cours`);
  await p.evaluate(() => window.scrollTo(0, document.body.scrollHeight)); await p.waitForTimeout(800);
  res.push(`  bas de page : ${await p.evaluate(() => document.querySelectorAll('.vignette[data-pret]').length)} vignettes dessinées ; erreurs : ${errs.length ? errs.slice(0, 3).join(' | ') : 'aucune'}`);
  await c.close();
}
await b.close(); console.log(res.join('\n'));
