// Petites fabriques pour dessiner les dos : motifs répétés, ovales « HS », étiquettes, étoiles, cadres, reflet des communes.
import { L, H, R, n, cadre, texte, hasard, clair, sombre } from './base.mjs';
export const plein = (c) => cadre(`fill="${c}"`);
// motif répété : contenu dessiné dans une case w × h
export const motif = (id, w, h, contenu, transform = '') => `<defs><pattern id="${id}" width="${w}" height="${h}" patternUnits="userSpaceOnUse"${transform ? ` patternTransform="${transform}"` : ''}>${contenu}</pattern></defs>${cadre(`fill="url(#${id})"`)}`;
export const filet = (c, w = 2, m = 8, rx = 15, extra = '') => `<rect x="${m}" y="${m}" width="${L - 2 * m}" height="${H - 2 * m}" rx="${rx}" fill="none" stroke="${c}" stroke-width="${w}" ${extra}/>`;
export const bordure = (c, w = 12) => `<rect x="${w / 2}" y="${w / 2}" width="${L - w}" height="${H - w}" rx="${R - w / 2}" fill="none" stroke="${c}" stroke-width="${w}"/>`;
export const etoile = (cx, cy, r1, r2, nb, attrs = '', rot = -90) => { const p = []; for (let i = 0; i < nb * 2; i++) { const r = i % 2 ? r2 : r1, a = ((rot + (i * 180) / nb) * Math.PI) / 180; p.push(`${n(cx + Math.cos(a) * r)},${n(cy + Math.sin(a) * r)}`); } return `<polygon points="${p.join(' ')}" ${attrs}/>`; };
export const polygone = (cx, cy, r, nb, attrs = '', rot = -90) => { const p = []; for (let i = 0; i < nb; i++) { const a = ((rot + (i * 360) / nb) * Math.PI) / 180; p.push(`${n(cx + Math.cos(a) * r)},${n(cy + Math.sin(a) * r)}`); } return `<polygon points="${p.join(' ')}" ${attrs}/>`; };
// ovale « HS » (ou autre texte) : fond, filet double, lettres
export const ovale = (cx, cy, rx, ry, fond, trait, mot = 'HS', encre = trait, taille = ry * 1.05) => `<ellipse cx="${cx}" cy="${cy}" rx="${rx}" ry="${ry}" fill="${fond}" stroke="${trait}" stroke-width="2.4"/><ellipse cx="${cx}" cy="${cy}" rx="${rx - 5}" ry="${ry - 5}" fill="none" stroke="${trait}" stroke-width=".9"/>${texte(mot, cx, cy + taille * .36, taille, `fill="${encre}"`)}`;
// étiquette rectangulaire, éventuellement penchée et cousue
export const etiquette = (cx, cy, w, h, mot, fond, encre, { angle = 0, couture = null, taille = h * .5, rx = 4 } = {}) => `<g transform="rotate(${angle} ${cx} ${cy})"><rect x="${n(cx - w / 2)}" y="${n(cy - h / 2)}" width="${w}" height="${h}" rx="${rx}" fill="${fond}"/>${couture ? `<rect x="${n(cx - w / 2 + 4)}" y="${n(cy - h / 2 + 4)}" width="${w - 8}" height="${h - 8}" rx="${rx}" fill="none" stroke="${couture}" stroke-width="1.2" stroke-dasharray="4 3"/>` : ''}${texte(mot, cx, cy + taille * .36, taille, `fill="${encre}"`)}</g>`;
// semis de points au hasard dans la carte
export const semer = (nb, graine, fn, { x0 = 0, x1 = L, y0 = 0, y1 = H } = {}) => { const h = hasard(graine); return Array.from({ length: nb }, (_, i) => fn(n(x0 + h() * (x1 - x0)), n(y0 + h() * (y1 - y0)), i, h)).join(''); };
// grille de positions (quinconce possible)
export const grille = (pasX, pasY, fn, { quinconce = false, x0 = 0, y0 = 0, marge = 1 } = {}) => { const out = []; let j = 0; for (let y = y0 - pasY * marge; y <= H + pasY * marge; y += pasY, j++) { const dx = quinconce && j % 2 ? pasX / 2 : 0; for (let x = x0 - pasX * marge + dx; x <= L + pasX * marge; x += pasX) out.push(fn(n(x), n(y), out.length, j)); } return out.join(''); };
// le reflet des communes : une bande claire traverse la carte de temps en temps
export const lustre = (u, retard = 0) => `<defs><linearGradient id="lu-${u}" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#fff" stop-opacity="0"/><stop offset=".5" stop-color="#fff" stop-opacity=".42"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient></defs><rect class="hs-lustre" style="animation-delay:${retard}s" x="-150" y="-40" width="90" height="430" fill="url(#lu-${u})"/>`;
export const CSS_DESSIN = `
.hs-lustre { transform: translateX(0) skewX(-18deg); animation: hs-lustre 7.5s ease-in-out infinite; }
@keyframes hs-lustre { 0%, 72% { transform: translateX(0) skewX(-18deg); } 100% { transform: translateX(470px) skewX(-18deg); } }
`;
export { clair, sombre };
