// Charte du jeu : « pas de dégradés ». Chaque dégradé d'un dessin est remplacé par des aplats :
// un halo (dégradé circulaire) devient trois disques de couleur franche, un dégradé linéaire devient sa couleur du milieu,
// et un dégradé arc-en-ciel distribue ses couleurs, une par forme.
const attr = (s, a) => { const m = s.match(new RegExp(`\\b${a}="([^"]*)"`)); return m ? m[1] : null; };
function lireDegrades(svg) {
  const out = new Map();
  for (const m of svg.matchAll(/<(linear|radial)Gradient\b([^>]*)>([\s\S]*?)<\/\1Gradient>/g)) {
    const id = attr(m[2], 'id'); if (!id) continue;
    const stops = [...m[3].matchAll(/<stop\b([^>]*)\/?>/g)].map((s) => { let off = attr(s[1], 'offset') || '0'; off = off.endsWith('%') ? parseFloat(off) / 100 : parseFloat(off); const st = attr(s[1], 'style') || ''; const col = attr(s[1], 'stop-color') || (st.match(/stop-color:\s*([^;]+)/) || [])[1] || '#000'; const op = attr(s[1], 'stop-opacity') ?? (st.match(/stop-opacity:\s*([^;]+)/) || [])[1] ?? '1'; return { off, col: col.trim(), op: parseFloat(op) }; });
    if (stops.length) out.set(id, { type: m[1], stops, n: 0 });
  }
  return out;
}
const hex = (c) => { if (!/^#[0-9a-f]{3,6}$/i.test(c)) return null; if (c.length === 4) c = '#' + [...c.slice(1)].map((x) => x + x).join(''); return [1, 3, 5].map((i) => parseInt(c.slice(i, i + 2), 16)); };
// couleur et opacité du dégradé à la position t (entre 0 et 1), par interpolation entre les deux arrêts voisins
function pres(stops, t) {
  const l = [...stops].sort((x, y) => x.off - y.off); let a = l[0], b = l[l.length - 1];
  for (let i = 0; i < l.length - 1; i++) if (l[i].off <= t && l[i + 1].off >= t) { a = l[i]; b = l[i + 1]; break; }
  if (t <= l[0].off) return l[0]; if (t >= l[l.length - 1].off) return l[l.length - 1];
  const f = b.off === a.off ? 0 : (t - a.off) / (b.off - a.off); const A = hex(a.col), B = hex(b.col);
  const col = A && B ? '#' + A.map((v, i) => Math.round(v + (B[i] - v) * f).toString(16).padStart(2, '0')).join('') : (f < .5 ? a.col : b.col);
  return { off: t, col, op: a.op + (b.op - a.op) * f };
}
const remplissage = (s, prop) => `${prop}="${s.col}"${s.op < 1 ? ` ${prop}-opacity="${+s.op.toFixed(2)}"` : ''}`;
export function aplatir(svg) {
  if (!svg.includes('Gradient')) return svg;
  const deg = lireDegrades(svg);
  let res = svg.replace(/<(linear|radial)Gradient\b[^>]*>[\s\S]*?<\/\1Gradient>/g, '');
  // halos : un cercle ou une ellipse rempli d'un dégradé circulaire devient trois formes emboîtées
  res = res.replace(/<(circle|ellipse)\b([^>]*?)fill="url\(#([^)]+)\)"([^>]*?)\/>/g, (tout, tag, a1, id, a2) => {
    const d = deg.get(id); if (!d) return tout;
    const attrs = (a1 + a2).replace(/\s+/g, ' ');
    if (d.type === 'linear') return `<${tag}${a1}${remplissage(pres(d.stops, .5), 'fill')}${a2}/>`;
    const cls = attr(attrs, 'class'), style = attr(attrs, 'style'), tr = attr(attrs, 'transform'), op = attr(attrs, 'opacity');
    const geo = attrs.replace(/\s(class|style|transform|opacity)="[^"]*"/g, '');
    const g = (k) => { if (tag === 'circle') { const r = parseFloat(attr(geo, 'r')); return geo.replace(/\br="[^"]*"/, `r="${+(r * k).toFixed(2)}"`); } const rx = parseFloat(attr(geo, 'rx')), ry = parseFloat(attr(geo, 'ry')); return geo.replace(/\brx="[^"]*"/, `rx="${+(rx * k).toFixed(2)}"`).replace(/\bry="[^"]*"/, `ry="${+(ry * k).toFixed(2)}"`); };
    const couches = [[1, .82], [.66, .45], [.33, .08]].map(([k, t]) => { const s = pres(d.stops, t); return s.op <= 0.02 ? '' : `<${tag}${g(k)} ${remplissage(s, 'fill')}/>`; }).join('');
    return `<g${cls ? ` class="${cls}"` : ''}${style ? ` style="${style}"` : ''}${tr ? ` transform="${tr}"` : ''}${op ? ` opacity="${op}"` : ''}>${couches}</g>`;
  });
  // le reste : couleur du milieu, ou une couleur de l'arc-en-ciel par forme
  res = res.replace(/(fill|stroke)="url\(#([^)]+)\)"/g, (tout, prop, id) => {
    const d = deg.get(id); if (!d) return tout;
    if (d.type === 'linear' && d.stops.length >= 4) { const s = d.stops[d.n++ % d.stops.length]; return remplissage(s, prop); }
    return remplissage(pres(d.stops, d.type === 'radial' ? .35 : .5), prop);
  });
  return res;
}
