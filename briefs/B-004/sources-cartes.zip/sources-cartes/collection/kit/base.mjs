// Base commune de la collection : outils de dessin, enseignes, et texte en contours (la police Alfa Slab One devient des chemins,
// donc chaque SVG s'affiche pareil partout, sans charger de police).
export * from './outils.mjs';
import { n } from './outils.mjs';
import G from './glyphes.json' with { type: 'json' };
const UPM = G.upm;
export const largeurTexte = (s, taille, espace = 0) => { let w = 0; for (const ch of s) w += (G.g[ch] ? G.g[ch].a : 500); return (w * taille) / UPM + espace * (s.length - 1); };
// texte(chaîne, x, y de la ligne de base, taille, attributs, ancrage 'start' | 'middle' | 'end', espacement en px)
export function texte(s, x, y, taille, attrs = '', ancre = 'middle', espace = 0) {
  const k = taille / UPM, w = largeurTexte(s, taille, espace);
  let x0 = ancre === 'middle' ? x - w / 2 : ancre === 'end' ? x - w : x; const morceaux = [];
  for (const ch of s) { const g = G.g[ch]; if (g && g.d) morceaux.push(`<path transform="translate(${n(x0, 2)} ${n(y, 2)}) scale(${n(k, 4)} ${n(-k, 4)})" d="${g.d}"/>`); x0 += (g ? g.a : 500) * k + espace; }
  return `<g ${attrs}>${morceaux.join('')}</g>`;
}
// texte posé en cercle (lettrage d'un sous-bock, d'un jeton) : centre, rayon, angle de départ en degrés
export function texteCercle(s, cx, cy, r, taille, attrs = '', depart = -90, espace = 0) {
  const k = taille / UPM; const total = largeurTexte(s, taille, espace); let a = depart - ((total / r) * 180) / Math.PI / 2; const out = [];
  for (const ch of s) { const g = G.g[ch]; const w = (g ? g.a : 500) * k; const am = a + ((w / 2 / r) * 180) / Math.PI; const rad = (am * Math.PI) / 180;
    if (g && g.d) out.push(`<path transform="translate(${n(cx + Math.cos(rad) * r, 2)} ${n(cy + Math.sin(rad) * r, 2)}) rotate(${n(am + 90, 2)}) translate(${n(-w / 2, 2)} 0) scale(${n(k, 4)} ${n(-k, 4)})" d="${g.d}"/>`);
    a += (((w + espace) / r) * 180) / Math.PI; }
  return `<g ${attrs}>${out.join('')}</g>`;
}
// petit générateur de couleurs : mélange de deux couleurs hexadécimales (t de 0 à 1)
export function melange(a, b, t) { const p = (h) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16)); const A = p(a), B = p(b); return '#' + A.map((v, i) => Math.round(v + (B[i] - v) * t).toString(16).padStart(2, '0')).join(''); }
export const clair = (c, t = .5) => melange(c, '#ffffff', t), sombre = (c, t = .5) => melange(c, '#000000', t);
// luminance (pour choisir une encre lisible)
export function lum(h) { const [r, g, b] = [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16) / 255); return .2126 * r + .7152 * g + .0722 * b; }
