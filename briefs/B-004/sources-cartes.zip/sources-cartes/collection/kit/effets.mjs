// Effets dessinés pour les épiques et les légendaires : flammes, braises, éclairs, fumée, étincelles, bulles, pièces.
// Charte du Drive : aplats et trait d'encre, pas de dégradé ni de flou. Animations en CSS sur transform et opacity
// seulement (légères pour le téléphone), coupées quand l'appareil demande moins d'animations.
import { n, hasard } from './base.mjs';

// --- flammes ---
// Une langue de flamme dessinée dans un repère normalisé : base en (0, 0), largeur 1, pointe en y = -1, penchée de k.
function langueNorm(k, r) {
  const a = (r() - .5) * .08, b = (r() - .5) * .08;
  const pts = [
    ['M', -.5, 0],
    ['C', -.66, -.14 + a, -.6, -.4, -.4 + a, -.56],
    ['C', -.22, -.72, -.08 + k * .3, -.8, k * .42, -1],
    ['C', .14 + k * .28, -.84, .3 + b, -.7, .3, -.52],
    ['C', .5, -.36, .62, -.16 + b, .5, 0],
    ['C', .34, .12, -.34, .12, -.5, 0],
  ];
  return pts;
}
const versChemin = (pts, x, y, l, h) => pts.map(([c, ...v]) => c + v.map((q, i) => n(i % 2 ? y + q * h : x + q * l)).join(' ')).join(' ') + ' Z';
// Rangée de flammes le long d'une base (x0 → x1, y), hauteur moyenne h. Couleurs : [encre, extérieur, milieu, cœur].
export function flammes({ x0 = 0, x1 = 250, y = 350, h = 90, nb = 7, couleurs = ['#3a0a02', '#C8301E', '#FF8A1F', '#FFE27A'], graine = 1, ep = 2.2, cls = '' }) {
  const r = hasard(graine * 97 + 13); const pas = (x1 - x0) / nb; let out = '';
  for (let i = 0; i < nb; i++) {
    const cx = x0 + pas * (i + .5) + (r() - .5) * pas * .3, hh = h * (.65 + r() * .6) * (1 - Math.abs(i - (nb - 1) / 2) / nb * .5), l = pas * (1.2 + r() * .5), k = (r() - .5) * 1.2;
    const forme = langueNorm(k, r);
    out += `<g class="fx-fl" style="--d:${n(.9 + r() * .9, 2)}s;--r:${n(-r() * 2, 2)}s">`
      + `<path d="${versChemin(forme, cx, y, l, hh)}" fill="${couleurs[1]}" stroke="${couleurs[0]}" stroke-width="${ep}" stroke-linejoin="round"/>`
      + `<path class="fx-fl-m" d="${versChemin(forme, cx + k * l * .04, y, l * .64, hh * .72)}" fill="${couleurs[2]}"/>`
      + `<path class="fx-fl-c" d="${versChemin(forme, cx + k * l * .06, y, l * .34, hh * .42)}" fill="${couleurs[3]}"/></g>`;
  }
  return `<g class="fx-flammes ${cls}">${out}</g>`;
}
// Braises qui montent : petits éclats irréguliers
export function braises({ x0 = 20, x1 = 230, y = 340, nb = 10, couleurs = ['#FFE27A', '#FF8A1F'], monte = 150, graine = 2 }) {
  const r = hasard(graine * 31 + 5); let out = '';
  for (let i = 0; i < nb; i++) {
    const x = x0 + r() * (x1 - x0), t = 1.6 + r() * 2, s = 1.6 + r() * 2.2;
    const p = [0, 1, 2, 3].map((k) => { const a = (k / 4) * Math.PI * 2 + r() * .6, q = s * (.6 + r() * .6); return `${n(Math.cos(a) * q)},${n(Math.sin(a) * q)}`; }).join(' ');
    out += `<g transform="translate(${n(x)} ${n(y - r() * 20)})"><polygon class="fx-braise" style="--d:${n(t, 2)}s;--r:${n(-r() * t, 2)}s;--x:${n((r() - .5) * 40)}px;--m:${-monte}px" points="${p}" fill="${couleurs[i % couleurs.length]}"/></g>`;
  }
  return `<g class="fx-braises">${out}</g>`;
}

// --- éclairs ---
// Tracé brisé par déplacement du milieu, avec une branche ; encre large dessous, cœur clair dessus.
function brise(x0, y0, x1, y1, ecart, r, prof = 6) {
  // déplacement du milieu proportionnel à la longueur du segment : un vrai zigzag, pas une courbe
  const rugueux = Math.min(.75, .25 + ecart / 140);
  let pts = [[x0, y0], [x1, y1]];
  for (let p = 0; p < prof; p++) {
    const nv = [pts[0]];
    for (let i = 1; i < pts.length; i++) {
      const [ax, ay] = pts[i - 1], [bx, by] = pts[i], dx = bx - ax, dy = by - ay, L = Math.hypot(dx, dy) || 1;
      const d = (r() - .5) * L * (p < 2 ? .3 : rugueux); // grands traits presque droits, détails brisés
      nv.push([(ax + bx) / 2 - (dy / L) * d, (ay + by) / 2 + (dx / L) * d], [bx, by]);
    }
    pts = nv;
  }
  return pts;
}
const pl = (pts) => pts.map(([x, y]) => `${n(x)},${n(y)}`).join(' ');
export function eclair({ x0, y0, x1, y1, ecart = 60, couleurs = ['#1a1033', '#FFF6C8'], ep = 7, graine = 3, d = 4, r = 0, eclaire = '' }) {
  const h = hasard(graine * 17 + 1); const tronc = brise(x0, y0, x1, y1, ecart, h);
  const k = Math.floor(tronc.length * (.35 + h() * .3)), [bx, by] = tronc[k];
  const branche = brise(bx, by, bx + (h() - .5) * 110, by + 40 + h() * 70, ecart * .8, h, 5);
  const trait = (p, w) => `<polyline points="${pl(p)}" fill="none" stroke="${couleurs[0]}" stroke-width="${w}" stroke-linejoin="round" stroke-linecap="round"/><polyline points="${pl(p)}" fill="none" stroke="${couleurs[1]}" stroke-width="${n(w * .38, 2)}" stroke-linejoin="round" stroke-linecap="round"/>`;
  return `<g class="fx-eclair" style="--d:${d}s;--r:${r}s">${eclaire ? `<rect width="250" height="350" fill="${eclaire}" class="fx-eclair-flash"/>` : ''}${trait(branche, ep * .6)}${trait(tronc, ep)}</g>`;
}

// --- fumée ---
// Nuages de fumée : bouffées rondes et bosselées (trait d'encre, deux tons), qui montent, gonflent et s'effacent.
function bouffee(r, h) {
  const nb = 7, pts = [];
  for (let i = 0; i < nb; i++) { const a = (i / nb) * Math.PI * 2, q = r * (.82 + h() * .3); pts.push([Math.cos(a) * q, Math.sin(a) * q * .86]); }
  let d = `M${n(pts[0][0])} ${n(pts[0][1])}`;
  for (let i = 0; i < nb; i++) { const [ax, ay] = pts[i], [bx, by] = pts[(i + 1) % nb], mx = (ax + bx) / 2, my = (ay + by) / 2, L = Math.hypot(mx, my) || 1, bosse = r * .42; d += ` Q${n(mx + (mx / L) * bosse)} ${n(my + (my / L) * bosse)} ${n(bx)} ${n(by)}`; }
  return d + ' Z';
}
export function fumee({ x = 125, y = 300, nb = 5, couleurs = ['#2a1250', '#8B5CF6', '#C4B5FD'], taille = 20, monte = 120, largeur = 70, graine = 4 }) {
  const r = hasard(graine * 13 + 7); let out = '';
  for (let i = 0; i < nb; i++) {
    const s = taille * (.7 + r() * .6), cx = x + (r() - .5) * largeur, forme = bouffee(s, r), ombre = bouffee(s * .62, r);
    out += `<g transform="translate(${n(cx)} ${n(y)})"><g class="fx-fumee" style="--d:${n(3.6 + r() * 2.4, 2)}s;--r:${n(-r() * 6, 2)}s;--m:${-monte}px;--x:${n((r() - .5) * 36)}px">`
      + `<path d="${forme}" fill="${couleurs[1]}" stroke="${couleurs[0]}" stroke-width="2" stroke-linejoin="round"/>`
      + `<path d="${ombre}" transform="translate(${n(s * .18)} ${n(s * .16)})" fill="${couleurs[0]}" opacity=".28"/>`
      + `<path d="M${n(-s * .55)} ${n(-s * .1)} Q${n(-s * .5)} ${n(-s * .6)} ${n(-s * .05)} ${n(-s * .62)}" fill="none" stroke="${couleurs[2]}" stroke-width="${n(Math.max(1.4, s * .12), 2)}" stroke-linecap="round"/></g></g>`;
  }
  return `<g class="fx-fumees">${out}</g>`;
}

// Nuages plats (décor fixe) : grappes de bouffées d'une seule couleur
export function nuages({ y = 40, nb = 4, couleur = '#E3E6FB', taille = 22, graine = 10, x0 = 0, x1 = 250 }) {
  const r = hasard(graine * 23 + 3); let out = '';
  for (let i = 0; i < nb; i++) { const s = taille * (.8 + r() * .5), x = x0 + (x1 - x0) * (i + .5) / nb + (r() - .5) * 20; out += `<path transform="translate(${n(x)} ${n(y + (r() - .5) * 16)})" d="${bouffee(s, r)}" fill="${couleur}"/>`; }
  return `<g class="fx-nuages">${out}</g>`;
}

// --- étincelles, bulles, pièces ---
// étoile à quatre branches aux côtés creusés (pas une forme géométrique sèche)
export const astre = (r) => { const q = n(r * .2); return `M0 ${-r} C${q} ${-q} ${q} ${-q} ${r} 0 C${q} ${q} ${q} ${q} 0 ${r} C${-q} ${q} ${-q} ${q} ${-r} 0 C${-q} ${-q} ${-q} ${-q} 0 ${-r} Z`; };
export function etincelles({ zones = [[20, 20, 230, 330]], nb = 9, couleurs = ['#FFF6C8'], encre = '#1a1033', taille = [7, 14], graine = 5 }) {
  const r = hasard(graine * 7 + 3); let out = '';
  for (let i = 0; i < nb; i++) {
    const [x0, y0, x1, y1] = zones[i % zones.length], x = x0 + r() * (x1 - x0), y = y0 + r() * (y1 - y0), s = taille[0] + r() * (taille[1] - taille[0]);
    out += `<g transform="translate(${n(x)} ${n(y)})"><path class="fx-etincelle" style="--d:${n(1.4 + r() * 1.8, 2)}s;--r:${n(-r() * 3, 2)}s" d="${astre(n(s))}" fill="${couleurs[i % couleurs.length]}" stroke="${encre}" stroke-width="1.2" stroke-linejoin="round"/></g>`;
  }
  return `<g class="fx-etincelles">${out}</g>`;
}
export function bulles({ x0 = 20, x1 = 230, y = 345, nb = 8, couleurs = ['#BDFBFF', '#0B3B5C'], monte = 300, graine = 6 }) {
  const r = hasard(graine * 11 + 9); let out = '';
  for (let i = 0; i < nb; i++) {
    const x = x0 + r() * (x1 - x0), s = 3 + r() * 6, t = 4 + r() * 4;
    out += `<g transform="translate(${n(x)} ${n(y)})"><g class="fx-bulle" style="--d:${n(t, 2)}s;--r:${n(-r() * t, 2)}s;--m:${-monte}px;--x:${n((r() - .5) * 24)}px"><circle r="${n(s)}" fill="${couleurs[1]}" fill-opacity=".35" stroke="${couleurs[0]}" stroke-width="1.4"/><path d="M${n(-s * .5)} ${n(-s * .15)} A${n(s * .55)} ${n(s * .55)} 0 0 1 ${n(s * .1)} ${n(-s * .55)}" fill="none" stroke="#fff" stroke-width="1.2" stroke-linecap="round"/></g></g>`;
  }
  return `<g class="fx-bulles">${out}</g>`;
}
export function pieces({ x0 = 20, x1 = 230, y = -20, nb = 7, couleurs = ['#5a3a00', '#F5B301', '#FFE27A'], chute = 400, graine = 7 }) {
  const r = hasard(graine * 5 + 11); let out = '';
  for (let i = 0; i < nb; i++) {
    const x = x0 + r() * (x1 - x0), s = 9 + r() * 5, t = 2.4 + r() * 2;
    out += `<g transform="translate(${n(x)} ${n(y)})"><g class="fx-piece" style="--d:${n(t, 2)}s;--r:${n(-r() * t, 2)}s;--m:${chute}px"><g class="fx-piece-tour" style="--d:${n(.6 + r() * .5, 2)}s"><ellipse rx="${n(s)}" ry="${n(s)}" fill="${couleurs[1]}" stroke="${couleurs[0]}" stroke-width="1.6"/><ellipse rx="${n(s * .62)}" ry="${n(s * .62)}" fill="none" stroke="${couleurs[0]}" stroke-width="1"/><path d="M${n(-s * .2)} ${n(-s * .35)} L${n(s * .25)} ${n(-s * .35)} L${n(-s * .1)} ${n(s * .38)}" fill="none" stroke="${couleurs[0]}" stroke-width="1.4" stroke-linecap="round"/><path d="M${n(-s * .55)} ${n(-s * .2)} A${n(s * .6)} ${n(s * .6)} 0 0 1 ${n(-s * .1)} ${n(-s * .62)}" fill="none" stroke="${couleurs[2]}" stroke-width="1.4" stroke-linecap="round"/></g></g></g>`;
  }
  return `<g class="fx-pieces">${out}</g>`;
}
// Pluie : traits obliques qui tombent
export function pluie({ nb = 16, couleur = '#9CC3FF', graine = 8 }) {
  const r = hasard(graine * 3 + 1); let out = '';
  for (let i = 0; i < nb; i++) { const x = r() * 270 - 10, y = r() * 200 - 60, l = 14 + r() * 16; out += `<path class="fx-goutte" style="--d:${n(.7 + r() * .5, 2)}s;--r:${n(-r(), 2)}s" d="M${n(x)} ${n(y)} l${n(-l * .3)} ${n(l)}" stroke="${couleur}" stroke-width="1.6" stroke-linecap="round" opacity=".8"/>`; }
  return `<g class="fx-pluie">${out}</g>`;
}
// Traits de vent qui filent (tornade, vitesse)
export function vent({ nb = 7, couleur = '#E6E1D6', encre = '#2a2a33', graine = 9, zone = [10, 40, 240, 330] }) {
  const r = hasard(graine * 19 + 4); let out = '';
  for (let i = 0; i < nb; i++) {
    const y = zone[1] + r() * (zone[3] - zone[1]), x = zone[0] + r() * (zone[2] - zone[0]) * .5, l = 40 + r() * 70, c = (r() - .5) * 26;
    const d = `M${n(x)} ${n(y)} q${n(l / 2)} ${n(c)} ${n(l)} 0 q${n(l * .18)} ${n(-c * .2)} ${n(l * .1)} ${n(-9)}`;
    out += `<g class="fx-vent" style="--d:${n(1.6 + r() * 1.4, 2)}s;--r:${n(-r() * 3, 2)}s"><path d="${d}" fill="none" stroke="${encre}" stroke-width="4.2" stroke-linecap="round"/><path d="${d}" fill="none" stroke="${couleur}" stroke-width="1.8" stroke-linecap="round"/></g>`;
  }
  return `<g class="fx-vents">${out}</g>`;
}

export const CSS_EFFETS = `
.fx-fl { transform-box: fill-box; transform-origin: 50% 100%; animation: fx-fl var(--d, 1.2s) ease-in-out var(--r, 0s) infinite alternate; }
@keyframes fx-fl { 0% { transform: scale(1, 1) skewX(0deg); } 30% { transform: scale(.94, 1.12) skewX(-5deg); } 65% { transform: scale(1.05, .9) skewX(4deg); } 100% { transform: scale(.97, 1.07) skewX(-2deg); } }
.fx-fl-c { animation: fx-fl-c calc(var(--d, 1.2s) * .6) steps(2, jump-none) var(--r, 0s) infinite alternate; }
@keyframes fx-fl-c { from { opacity: 1; } to { opacity: .55; } }
.fx-braise { opacity: 0; animation: fx-braise var(--d, 2s) linear var(--r, 0s) infinite; }
@keyframes fx-braise { 0% { opacity: 0; transform: translate(0, 0) rotate(0deg); } 12% { opacity: 1; } 80% { opacity: .9; } 100% { opacity: 0; transform: translate(var(--x, 0px), var(--m, -150px)) rotate(240deg) scale(.4); } }
.fx-eclair { opacity: 0; animation: fx-eclair var(--d, 4s) steps(1, end) var(--r, 0s) infinite; }
@keyframes fx-eclair { 0%, 86% { opacity: 0; } 87% { opacity: 1; } 89% { opacity: .15; } 91% { opacity: 1; } 95%, 100% { opacity: 0; } }
.fx-eclair-flash { opacity: .14; }
.fx-fumee { opacity: 0; transform-box: fill-box; transform-origin: 50% 100%; animation: fx-fumee var(--d, 5s) ease-out var(--r, 0s) infinite; }
@keyframes fx-fumee { 0% { opacity: 0; transform: translate(0, 0) scale(.6); } 15% { opacity: .95; } 70% { opacity: .7; } 100% { opacity: 0; transform: translate(var(--x, 0px), var(--m, -110px)) scale(1.35); } }
.fx-etincelle { transform-box: fill-box; transform-origin: 50% 50%; animation: fx-etincelle var(--d, 2s) ease-in-out var(--r, 0s) infinite; }
@keyframes fx-etincelle { 0%, 100% { transform: scale(.25) rotate(0deg); opacity: .2; } 45% { transform: scale(1) rotate(45deg); opacity: 1; } 60% { transform: scale(.85) rotate(60deg); opacity: .9; } }
.fx-bulle { animation: fx-bulle var(--d, 5s) ease-in var(--r, 0s) infinite; }
@keyframes fx-bulle { 0% { opacity: 0; transform: translate(0, 0); } 10% { opacity: 1; } 50% { transform: translate(var(--x, 0px), calc(var(--m, -300px) * .5)); } 90% { opacity: 1; } 100% { opacity: 0; transform: translate(calc(var(--x, 0px) * -1), var(--m, -300px)); } }
.fx-piece { animation: fx-piece var(--d, 3s) cubic-bezier(.45, 0, .8, .6) var(--r, 0s) infinite; }
@keyframes fx-piece { 0% { opacity: 0; transform: translateY(0); } 8% { opacity: 1; } 92% { opacity: 1; } 100% { opacity: 0; transform: translateY(var(--m, 400px)); } }
.fx-piece-tour { animation: fx-piece-tour var(--d, .8s) linear infinite; }
@keyframes fx-piece-tour { 0% { transform: scaleX(1); } 25% { transform: scaleX(.15); } 50% { transform: scaleX(-1); } 75% { transform: scaleX(.15); } 100% { transform: scaleX(1); } }
.fx-goutte { animation: fx-goutte var(--d, .9s) linear var(--r, 0s) infinite; }
@keyframes fx-goutte { from { transform: translate(0, 0); } to { transform: translate(-60px, 200px); } }
.fx-vent { opacity: 0; animation: fx-vent var(--d, 2s) ease-in-out var(--r, 0s) infinite; }
@keyframes fx-vent { 0% { opacity: 0; transform: translateX(-30px); } 30% { opacity: 1; } 70% { opacity: 1; } 100% { opacity: 0; transform: translateX(60px); } }
@media (prefers-reduced-motion: reduce) { .fx-fl, .fx-fl-c, .fx-braise, .fx-eclair, .fx-fumee, .fx-etincelle, .fx-bulle, .fx-piece, .fx-piece-tour, .fx-goutte, .fx-vent { animation: none; } .fx-eclair { opacity: .9; } .fx-eclair-flash { opacity: 0; } .fx-fumee { opacity: .8; } .fx-braise { opacity: .8; } }
`;
