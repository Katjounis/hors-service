// Les trois figures, chacune avec sa silhouette propre, pour qu'on les reconnaisse au premier coup d'œil :
//   ROI   : de face, grande couronne, barbe pleine, cape à col d'hermine, sceptre levé, orbe en bas à gauche.
//   DAME  : de trois quarts, longs cheveux jusqu'aux épaules, diadème, boucles d'oreilles, fleur (ou éventail) à gauche.
//   VALET : de profil (il regarde à gauche), sans barbe, cheveux courts, toque à longue plume, lance à gauche.
// Chaque skin les habille : un style de rendu, une palette, des variantes de coiffe et d'objet, un niveau d'animation.
import { n, enseigne, miroir } from './base.mjs';

// --- le peintre : traduit « forme + rôle » en SVG selon le style ---
// rôles : peau, cheveux, habit, habit2, metal, blanc, accent, levres, oeil, bois, trait
const ROLES_OR = new Set(['peau', 'cheveux', 'habit', 'habit2', 'metal', 'blanc', 'bois']);
const TONS_OR = { peau: 'clair', blanc: 'clair', metal: 'moyen', habit: 'moyen', habit2: 'fonce', cheveux: 'fonce', bois: 'fonce' };
export function peintre(style, pal, u) {
  const st = style || 'plat';
  const W = { plat: 1.6, pop: 2.6, or: 1.9, ombre: 0, neon: 2.1, grave: 1.25, vitrail: 3 }[st] ?? 1.6;
  // style « or » : trois tons d'or en aplat (clair, moyen, foncé) selon la partie, et un trait d'encre plus marqué
  const OR = { clair: pal.or1 || '#FFF1A8', moyen: pal.or2 || '#F5B301', fonce: pal.or3 || '#9A6400' };
  const bord = st === 'pop' || st === 'vitrail' ? '#151515' : pal.trait;
  const col = (r) => pal[r] || r;
  const remplir = (r) => {
    if (st === 'or') return ROLES_OR.has(r) ? OR[TONS_OR[r]] : col(r);
    if (st === 'ombre') return r === 'metal' || r === 'accent' || r === 'oeil' || r === 'levres' ? col(r === 'oeil' ? 'accent' : r) : pal.silhouette || '#16121c';
    if (st === 'grave') return r === 'habit' || r === 'cheveux' ? `url(#fh-${u})` : r === 'habit2' ? `url(#fh2-${u})` : r === 'metal' || r === 'accent' || r === 'levres' || r === 'oeil' ? col(r) : pal.papierFig || '#F6EFE2';
    return col(r);
  };
  const neon = (d, c, cls) => `<g${cls ? ` class="${cls}"` : ''} fill="none" stroke-linejoin="round" stroke-linecap="round"><path d="${d}" fill="${c}" fill-opacity=".09" stroke="${c}" stroke-width="${n(W * 3.4)}" stroke-opacity=".22"/><path d="${d}" stroke="${c}" stroke-width="${W}"/><path d="${d}" stroke="#fff" stroke-width="${n(W * .34, 2)}" stroke-opacity=".8"/></g>`;
  const f = (d, r, cls = '', extra = '') => st === 'neon' ? neon(d, col(r === 'peau' ? 'neonPeau' : r), cls)
    : `<path${cls ? ` class="${cls}"` : ''} d="${d}" fill="${remplir(r)}"${W ? ` stroke="${bord}" stroke-width="${W}" stroke-linejoin="round"` : ''}${extra ? ' ' + extra : ''}/>`;
  const e = (cx, cy, rx, ry, r, cls = '') => f(`M${cx - rx} ${cy}a${rx} ${ry} 0 1 0 ${2 * rx} 0a${rx} ${ry} 0 1 0 ${-2 * rx} 0Z`, r, cls);
  const lc = (r) => st === 'neon' ? col(r === 'trait' ? 'neonTrait' : r) : st === 'ombre' ? (r === 'trait' ? pal.ombreTrait || '#6b5a7a' : col(r)) : st === 'pop' && r === 'trait' ? '#151515' : col(r);
  const l = (d, r = 'trait', w = 1.6, cls = '', extra = '') => `<path${cls ? ` class="${cls}"` : ''} d="${d}" fill="none" stroke="${lc(r)}" stroke-width="${st === 'pop' ? w * 1.3 : w}" stroke-linecap="round" stroke-linejoin="round"${extra ? ' ' + extra : ''}/>`;
  // ombre propre sur la moitié droite (relief), sauf pour les styles où ça n'a pas de sens
  const om = (d, k = .16) => st === 'neon' || st === 'ombre' || st === 'grave' ? '' : `<path d="${d}" fill="#000" opacity="${k}"/>`;
  const defs = `<defs>${st === 'grave' ? `<pattern id="fh-${u}" width="5" height="5" patternUnits="userSpaceOnUse" patternTransform="rotate(35)"><rect width="5" height="5" fill="${pal.papierFig || '#F6EFE2'}"/><path d="M0 0 V5" stroke="${pal.trait}" stroke-width="1.5"/></pattern><pattern id="fh2-${u}" width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(-30)"><rect width="6" height="6" fill="${pal.papierFig || '#F6EFE2'}"/><path d="M0 0 V6 M3 0 V6" stroke="${pal.trait}" stroke-width=".8"/></pattern>` : ''}</defs>`;
  return { f, e, l, om, defs, st, col, pal };
}

// --- coiffes ---
const COURONNE_ROI = {
  couronne: (P, a) => P.f('M86 124 L80 78 L101 104 L112 66 L125 96 L138 66 L149 104 L170 78 L164 124 Z', 'metal') + P.f('M86 122 H164 L162 140 H88 Z', 'metal') + P.om('M125 96 L138 66 L149 104 L170 78 L164 124 V140 H125 Z', .12)
    + [[80, 76], [112, 64], [138, 64], [170, 76]].map(([x, y]) => P.e(x, y, 4.6, 4.6, 'metal')).join('') + P.e(125, 131, 5, 5, 'accent') + P.e(104, 131, 3.2, 3.2, 'accent') + P.e(146, 131, 3.2, 3.2, 'accent') + (a >= 3 ? eclat(112, 64, 7, 'fg-eclat') + eclat(170, 76, 5, 'fg-eclat b') : ''),
  haute: (P, a) => P.f('M84 124 L76 58 L96 92 L104 44 L116 84 L125 34 L134 84 L146 44 L154 92 L174 58 L166 124 Z', 'metal') + P.f('M84 120 H166 L163 140 H87 Z', 'metal') + P.om('M125 34 L134 84 L146 44 L154 92 L174 58 L166 124 V140 H125 Z', .12)
    + [[76, 56], [104, 42], [125, 32], [146, 42], [174, 56]].map(([x, y]) => P.e(x, y, 4.4, 4.4, 'accent')).join('') + P.e(125, 130, 5.5, 5.5, 'accent') + (a >= 3 ? eclat(125, 32, 8, 'fg-eclat') : ''),
  chapeau: (P) => P.f('M94 122 L98 52 H152 L156 122 Z', 'habit2') + P.f('M95 110 L96.6 96 H153.4 L155 110 Z', 'accent') + P.f('M74 120 C74 114 176 114 176 120 C176 130 74 130 74 120 Z', 'habit2') + P.om('M125 52 H152 L156 122 H125 Z', .14),
  laurier: (P) => [0, 1, 2, 3, 4, 5].map((i) => { const a = 200 + i * 14, r = 36, x = 125 + Math.cos(a * Math.PI / 180) * r, y = 150 + Math.sin(a * Math.PI / 180) * r * 1.05; return P.f(`M${n(x)} ${n(y)} c-6 -8 -4 -14 2 -16 c4 6 4 12 -2 16 Z`, 'metal') + P.f(`M${n(250 - x)} ${n(y)} c6 -8 4 -14 -2 -16 c-4 6 -4 12 2 16 Z`, 'metal'); }).join('') + P.e(125, 112, 4, 4, 'accent'),
  cornes: (P, a) => P.f('M92 126 C70 112 62 84 72 58 C78 84 90 100 106 110 Z', 'metal') + P.f('M158 126 C180 112 188 84 178 58 C172 84 160 100 144 110 Z', 'metal') + COURONNE_ROI.couronne(P, a),
  casque: (P) => P.f('M88 150 C86 104 164 104 162 150 L162 128 C150 120 100 120 88 128 Z', 'metal') + P.f('M118 96 C122 80 128 80 132 96 Z', 'accent') + P.f('M88 128 C100 120 150 120 162 128 L162 142 C150 134 100 134 88 142 Z', 'habit2'),
};
const COIFFE_DAME = {
  diademe: (P, a) => P.f('M99 118 L104 100 L112 112 L121 88 L130 112 L138 100 L143 118 Q121 107 99 118 Z', 'metal') + P.e(121, 103, 3.4, 3.4, 'accent') + (a >= 3 ? eclat(121, 86, 7, 'fg-eclat') : ''),
  voile: (P, a) => COIFFE_DAME.diademe(P, a),
  chignon: (P) => P.e(122, 92, 17, 14, 'cheveux') + P.l('M110 90 Q122 82 134 92', 'trait', 1) + P.f('M136 82 l10 -10 l3 3 l-10 10 Z', 'metal') + P.e(147, 72, 3, 3, 'accent'),
  fleurs: (P) => [[100, 118], [108, 106], [121, 100], [134, 106], [142, 118]].map(([x, y], i) => P.e(x, y, 6.5, 6.5, i % 2 ? 'accent' : 'blanc') + P.e(x, y, 2.4, 2.4, 'metal')).join(''),
  plumes: (P) => [[-18, 'accent'], [0, 'metal'], [18, 'accent']].map(([a, r]) => `<g transform="rotate(${a} 121 112)">${P.f('M121 112 C110 92 112 66 121 50 C130 66 132 92 121 112 Z', r)}${P.l('M121 108 V56', 'trait', .8)}</g>`).join('') + P.f('M104 118 Q121 108 138 118 L138 124 Q121 114 104 124 Z', 'metal'),
  couronne: (P) => P.f('M102 118 L100 94 L111 106 L121 86 L131 106 L142 94 L140 118 Z', 'metal') + P.e(121, 112, 3, 3, 'accent'),
};
const COIFFE_VALET = {
  toque: (P, a) => P.f('M90 126 C94 102 124 90 156 94 C180 98 190 110 186 122 C170 128 120 132 90 126 Z', 'habit2') + P.l('M94 125 C130 131 170 127 186 121', 'metal', 3) + plume(P, a),
  casquette: (P) => P.f('M98 128 C98 102 150 92 166 118 C150 126 120 130 98 128 Z', 'habit2') + P.f('M100 128 C88 127 76 131 70 136 C84 139 102 135 114 130 Z', 'habit2') + P.l('M106 110 C124 104 144 106 156 114', 'trait', 1, '', 'opacity=".5"') + P.e(132, 96, 3.6, 3.6, 'accent'),
  bonnet: (P) => P.f('M94 130 C92 100 116 84 140 88 C162 92 172 112 168 130 Z', 'habit2') + P.f('M92 126 H170 V138 H92 Z', 'accent') + P.e(142, 84, 9, 9, 'blanc'),
  capuche: (P) => P.f('M92 196 C76 160 82 104 124 98 C166 96 182 140 172 196 C164 170 160 140 140 128 C118 120 100 140 98 168 Z', 'habit2'),
  casque: (P) => P.f('M94 150 C90 108 120 96 146 100 C170 106 178 130 172 160 L164 150 C162 126 146 114 126 116 C112 118 102 130 102 150 Z', 'metal') + P.f('M120 100 C126 74 150 66 168 70 C154 78 140 88 136 102 Z', 'accent'),
  melon: (P) => P.f('M100 122 C100 96 156 92 160 120 Z', 'habit2') + P.f('M84 124 C84 116 176 114 176 122 C176 130 84 132 84 124 Z', 'habit2') + P.l('M101 116 C120 112 146 112 159 116', 'accent', 3),
};
function plume(P, a) { return `<g${a >= 2 ? ' class="fg-plume"' : ''}>${P.f('M158 104 C184 84 206 62 230 48 C220 70 202 94 176 114 Z', 'accent')}${P.l('M164 108 C186 90 206 70 226 52', 'trait', .9, '', 'opacity=".55"')}</g>`; }
const eclat = (x, y, r, cls) => `<g transform="translate(${x} ${y})"><path class="${cls}" d="M0 ${-r}L${n(r * .22)} ${n(-r * .22)}L${r} 0L${n(r * .22)} ${n(r * .22)}L0 ${r}L${n(-r * .22)} ${n(r * .22)}L${-r} 0L${n(-r * .22)} ${n(-r * .22)}Z" fill="#fff"/></g>`;

// --- objets tenus ---
const OBJET_ROI = {
  sceptre: (P, a) => P.l('M191 228 L199 64', 'trait', 7.5) + P.l('M191 228 L199 64', 'metal', 4.6) + P.e(200, 54, 10, 10, 'metal') + P.e(200, 54, 4, 4, 'accent') + P.l('M200 44 V28 M192 36 H208', 'metal', 3.4) + (a >= 2 ? `<g class="fg-objet">${eclat(200, 54, 12, 'fg-eclat')}</g>` : ''),
  epee: (P, a) => P.f('M195 232 L192 70 L198 52 L204 70 L201 232 Z', 'metal') + P.l('M198 70 V226', 'trait', .8, '', 'opacity=".5"') + P.f('M182 232 H214 V240 H182 Z', 'metal') + (a >= 2 ? `<g class="fg-objet">${eclat(198, 60, 10, 'fg-eclat')}</g>` : ''),
  chope: (P) => P.f('M182 180 H214 V226 C214 232 182 232 182 226 Z', 'metal') + P.f('M214 190 C226 190 228 214 214 216', 'metal') + P.f('M180 182 C178 168 196 162 200 170 C206 160 222 166 216 182 Z', 'blanc'),
  trident: (P) => P.l('M191 228 L199 70', 'metal', 4) + P.l('M186 92 C186 70 190 62 192 50 M199 86 V44 M212 92 C212 70 208 62 206 50 M186 92 H212', 'metal', 3.4),
  baguette: (P, a) => P.l('M191 228 L201 76', 'bois', 4) + eclat(202, 66, 14, a >= 2 ? 'fg-eclat' : ''),
};
const OBJET_DAME = {
  rose: (P, a) => P.l('M57 250 C53 230 56 214 51 196', 'vert', 2.6) + P.f('M54 228 C42 222 38 212 40 205 C49 209 53 216 54 228 Z', 'vert') + `<g${a >= 2 ? ' class="fg-objet"' : ''}>${P.e(50, 190, 11, 10, 'accent')}${P.l('M45 189 C45 184 54 183 55 189 C55 194 47 195 47 190', 'trait', 1.1)}</g>`,
  eventail: (P, a) => `<g${a >= 2 ? ' class="fg-eventail"' : ''}>${P.f('M58 236 L24 196 C34 176 60 166 82 172 Z', 'accent')}${P.l('M58 236 L30 190 M58 236 L42 178 M58 236 L58 172 M58 236 L72 172', 'trait', 1)}</g>`,
  miroir: (P) => P.e(52, 200, 14, 17, 'metal') + P.e(52, 200, 10, 13, 'blanc') + P.l('M45 192 L56 204', 'trait', 1, '', 'opacity=".4"') + P.l('M55 216 L58 240', 'metal', 4),
  cocktail: (P) => P.f('M30 184 H74 L52 210 Z', 'blanc') + P.f('M37 192 H67 L52 208 Z', 'accent') + P.l('M52 210 V236 M42 238 H62', 'blanc', 2.4) + P.e(64, 184, 5, 5, 'vert'),
  coupe: (P) => P.f('M34 188 C34 206 70 206 70 188 Z', 'blanc') + P.f('M38 192 C40 202 64 202 66 192 Z', 'accent') + P.l('M52 204 V234 M42 236 H62', 'blanc', 2.4),
  cartes: (P) => [-24, 0, 24].map((a, i) => `<g transform="rotate(${a} 56 236)">${P.f('M46 186 H66 V214 H46 Z', 'blanc')}${enseigne(['H', 'S', 'D'][i], 56, 200, 12, `fill="${i === 1 ? '#151515' : '#D11E3A'}"`)}</g>`).join(''),
};
const OBJET_VALET = {
  lance: (P, a) => P.l('M62 336 L74 130', 'trait', 6.5) + P.l('M62 336 L74 130', 'bois', 4.2) + P.f('M74 134 L66 112 L74 82 L82 112 Z', 'metal') + P.f('M70 122 C56 118 50 128 52 140 C58 134 64 132 72 134 Z', 'metal') + (a >= 2 ? `<g class="fg-objet">${eclat(74, 92, 8, 'fg-eclat')}</g>` : ''),
  torche: (P, a) => P.l('M62 336 L72 158', 'bois', 6) + P.f('M64 162 H82 L80 150 H66 Z', 'metal') + `<g${a >= 2 ? ' class="fg-flamme"' : ''}>${P.f('M73 150 C58 138 62 118 72 104 C72 116 78 118 80 110 C90 122 88 142 73 150 Z', 'accent')}${P.f('M73 146 C66 138 68 128 73 120 C76 130 80 134 73 146 Z', 'blanc')}</g>`,
  plateau: (P) => P.f('M28 232 C28 226 104 226 104 232 C104 238 28 238 28 232 Z', 'metal') + P.f('M40 228 V200 H54 V228 Z', 'blanc') + P.f('M42 212 H52 V226 H42 Z', 'accent') + P.f('M70 228 L62 196 H84 L76 228 Z', 'blanc'),
  epee: (P, a) => P.f('M66 300 L70 112 L75 96 L80 112 L76 300 Z', 'metal') + P.f('M58 300 H86 V308 H58 Z', 'metal') + (a >= 2 ? `<g class="fg-objet">${eclat(75, 104, 8, 'fg-eclat')}</g>` : ''),
  drapeau: (P, a) => P.l('M62 336 L72 120', 'bois', 4) + `<g${a >= 2 ? ' class="fg-drapeau"' : ''}>${P.f('M72 124 C88 118 100 132 116 124 L114 152 C100 160 88 146 70 152 Z', 'accent')}</g>`,
  micro: (P) => P.l('M66 330 L72 196', 'trait', 4) + P.e(73, 186, 11, 13, 'metal') + P.l('M64 182 H82 M64 188 H82', 'trait', 1, '', 'opacity=".5"'),
  cartes: (P) => [-20, 0, 20].map((a, i) => `<g transform="rotate(${a} 70 244)">${P.f('M60 192 H80 V220 H60 Z', 'blanc')}${enseigne(['C', 'H', 'S'][i], 70, 206, 12, `fill="${i === 1 ? '#D11E3A' : '#151515'}"`)}</g>`).join(''),
};

// --- variantes : chaque skin tire ses personnages (visage, barbe, coiffure, nez, expression…) ---
const BARBES = {
  pleine: (P) => P.f('M95 158 C92 196 104 236 125 256 C146 236 158 196 155 158 C151 176 143 186 136 190 C130 184 120 184 114 190 C107 186 99 176 95 158 Z', 'cheveux') + P.l('M110 206 C112 220 118 232 125 240 M140 206 C138 220 132 232 125 240 M125 200 V236', 'trait', 1, '', 'opacity=".45"'),
  pointue: (P) => P.f('M101 176 C103 204 112 230 125 254 C138 230 147 204 149 176 C144 188 138 192 134 194 C128 190 122 190 116 194 C112 192 106 188 101 176 Z', 'cheveux') + P.l('M118 204 L125 238 L132 204', 'trait', 1, '', 'opacity=".45"'),
  fourchue: (P) => P.f('M96 164 C94 200 102 228 112 250 L120 232 L125 244 L130 232 L138 250 C148 228 156 200 154 164 C150 180 142 188 136 192 C130 186 120 186 114 192 C108 188 100 180 96 164 Z', 'cheveux') + P.l('M112 210 L114 238 M138 210 L136 238', 'trait', 1, '', 'opacity=".45"'),
  courte: (P) => P.f('M96 170 C96 198 108 214 125 216 C142 214 154 198 154 170 C150 182 142 188 136 192 C130 186 120 186 114 192 C108 188 100 182 96 170 Z', 'cheveux'),
  moustache: () => '',
  favoris: (P) => P.f('M95 148 C93 170 96 190 108 200 L112 186 C104 176 102 162 102 148 Z', 'cheveux') + P.f('M155 148 C157 170 154 190 142 200 L138 186 C146 176 148 162 148 148 Z', 'cheveux'),
};
const MOUSTACHES_ROI = {
  normale: 'M125 186 C118 179 106 180 98 190 C106 188 116 191 125 193 C134 191 144 188 152 190 C144 180 132 179 125 186 Z',
  guidon: 'M125 186 C116 180 104 184 98 178 C92 174 90 166 96 164 C94 172 98 178 106 180 C114 182 120 184 125 189 C130 184 136 182 144 180 C152 178 156 172 154 164 C160 166 158 174 152 178 C146 184 134 180 125 186 Z',
};
const VISAGES = { ovale: [30, 36], rond: [33, 32], long: [27, 40] };
const SOURCILS = { severe: 'M102 145 L121 149 M148 145 L129 149', doux: 'M104 148 Q112 142 120 147 M130 147 Q138 142 146 148', droits: 'M103 147 H120 M130 147 H147' };
// --- le roi ---
function roi(P, o) {
  const a = o.anim || 0, v = o.v || {}, co = COURONNE_ROI[o.coiffe] || COURONNE_ROI.couronne, ob = OBJET_ROI[o.objet] || OBJET_ROI.sceptre;
  const [rx, ry] = VISAGES[v.visage] || VISAGES.ovale, barbe = BARBES[v.barbe] ? v.barbe : 'pleine';
  const bouche = barbe === 'moustache' || barbe === 'favoris' || barbe === 'courte' ? (v.rire ? P.f('M114 196 Q125 212 136 196 Z', 'levres') : P.l('M115 198 Q125 205 135 198', 'trait', 1.8)) + (barbe !== 'courte' ? P.l('M117 214 Q125 218 133 214', 'trait', 1, '', 'opacity=".5"') : '') : P.l('M118 197 Q125 201 132 197', 'trait', 1.6);
  const taches = [[82, 268], [100, 258], [118, 254], [136, 256], [154, 260], [170, 268]].map(([x, y]) => P.f(`M${x} ${y}l2.4 6h-4.8z`, 'trait')).join('');
  const col = v.col === 'fourrure' ? P.f('M64 266 C82 240 168 240 186 266 C180 276 172 270 166 278 C158 268 150 276 142 268 C134 276 126 266 118 274 C110 266 102 276 94 268 C86 276 78 268 72 278 C66 272 60 274 64 266 Z', 'cheveux') : v.col === 'simple' ? P.f('M70 264 C88 244 162 244 180 264 L176 274 C158 258 92 258 74 274 Z', 'metal') : P.f('M64 266 C82 240 168 240 186 266 C190 276 182 284 172 279 C154 266 96 266 78 279 C68 284 60 276 64 266 Z', 'blanc') + taches;
  const brasG = P.f('M98 262 L60 288 L68 306 L106 282 Z', 'habit') + P.e(54, 300, 10, 9.5, 'peau') + (o.orbe === false ? '' : P.e(50, 276, 15, 15, 'metal') + P.l('M35 276 H65', 'trait', 1.2) + P.l('M50 261 V249 M44 255 H56', 'metal', 3) + (a >= 2 ? `<g class="fg-objet b">${eclat(44, 270, 5, 'fg-eclat b')}</g>` : ''));
  const cheveux = v.chauve ? '' : P.f('M92 132 C82 160 84 196 96 214 L108 206 C98 186 96 160 100 136 Z', 'cheveux') + miroir(P.f('M92 132 C82 160 84 196 96 214 L108 206 C98 186 96 160 100 136 Z', 'cheveux'));
  return `${P.f('M14 350 C18 298 44 262 90 248 L160 248 C206 262 232 298 236 350 Z', 'habit')}${P.om('M125 248 L160 248 C206 262 232 298 236 350 L125 350 Z')}
${P.f('M100 250 L150 250 L162 350 L88 350 Z', 'habit2')}${col}
${P.l('M98 274 Q125 302 152 274', 'metal', 3)}${P.e(125, 314, 19, 19, 'metal')}${P.e(125, 314, 14, 14, 'habit2')}${enseigne(o.ens, 125, 314, 19, `fill="${o.encre}"`)}
${brasG}
${P.f('M158 258 L176 206 L200 210 L190 266 Z', 'habit')}${P.f('M174 210 L201 214 L199 224 L172 220 Z', 'blanc')}
${ob(P, a)}${P.e(188, 202, 11, 10, 'peau')}
${cheveux}
${P.e(125 - rx, 160, 5, 8, 'peau')}${P.e(125 + rx, 160, 5, 8, 'peau')}${P.e(125, 158, rx, ry, 'peau')}${P.om(`M125 ${158 - ry} A${rx} ${ry} 0 0 1 125 ${158 + ry} Z`, .1)}
${BARBES[barbe](P)}${bouche}
${P.f(MOUSTACHES_ROI[v.moustache] || MOUSTACHES_ROI.normale, 'cheveux')}
<g${a >= 1 ? ' class="fg-yeux"' : ''}>${P.e(113, 156, 3.4, 3.8, 'oeil')}${P.e(137, 156, 3.4, 3.8, 'oeil')}</g>
${P.l(SOURCILS[v.sourcils] || SOURCILS.severe, v.sourcils === 'doux' ? 'cheveux' : 'trait', 3.2)}${P.l('M125 158 L120 176 C123 179 127 179 130 176', 'trait', 1.5)}
${v.lunettes ? P.l('M104 156 a9 8 0 1 0 18 0 a9 8 0 1 0 -18 0 M128 156 a9 8 0 1 0 18 0 a9 8 0 1 0 -18 0 M122 155 h6 M104 154 L96 150 M146 154 L154 150', 'metal', 1.8) : ''}
${co(P, a)}`;
}
// --- la dame ---
const COIFFURES_DAME = {
  longs: { dos: 'M82 152 C78 110 102 94 124 94 C150 94 170 112 168 152 C168 196 178 234 190 262 C174 272 156 262 150 248 L100 248 C94 262 76 272 60 262 C72 234 82 196 82 152 Z', devant: ['M97 146 C88 186 94 226 84 262 C78 276 90 284 96 270 C104 240 100 196 104 160 Z', 'M146 142 C156 182 150 222 164 258 C168 272 158 280 152 266 C144 236 146 196 142 160 Z'], frange: 'M96 150 C96 118 118 104 140 110 C152 114 160 126 150 138 C144 124 132 118 118 122 C106 126 100 138 96 150 Z' },
  carre: { dos: 'M84 150 C80 112 102 96 124 96 C150 96 168 114 166 150 C166 172 168 190 174 204 C160 212 146 206 140 198 L106 198 C100 206 86 212 72 204 C78 190 84 172 84 150 Z', devant: ['M97 144 C92 168 94 186 88 204 C98 202 102 188 104 160 Z', 'M146 142 C152 166 150 186 158 202 C148 202 144 188 142 160 Z'], frange: 'M95 146 C98 116 146 110 152 136 L150 142 C132 128 112 130 96 150 Z' },
  boucles: { boucles: true, frange: 'M96 148 C98 120 120 106 142 112 C154 118 158 130 150 140 C142 126 130 120 116 124 C106 128 100 138 96 148 Z' },
  tresse: { dos: 'M86 150 C82 112 104 96 124 96 C148 96 166 114 164 150 C162 168 156 178 150 184 L100 184 C94 178 88 168 86 150 Z', tresse: true, frange: 'M96 150 C96 118 118 104 140 110 C152 114 160 126 150 138 C144 124 132 118 118 122 C106 126 100 138 96 150 Z' },
  queue: { dos: 'M88 150 C84 112 104 96 124 96 C148 96 166 114 164 150 C162 166 156 176 150 180 L100 180 C94 174 90 164 88 150 Z', queue: true, frange: 'M98 150 C98 122 116 108 136 110 C122 116 108 128 98 150 Z' },
  chignon: { dos: 'M88 150 C84 112 104 96 124 96 C148 96 166 114 164 150 C160 158 154 160 150 160 L100 160 C94 160 90 156 88 150 Z', chignon: true, frange: 'M96 146 C100 120 120 108 142 112 C126 116 108 128 96 146 Z' },
};
function dame(P, o) {
  const a = o.anim || 0, v = o.v || {}, co = COIFFE_DAME[o.coiffe] || COIFFE_DAME.diademe, ob = OBJET_DAME[o.objet] || OBJET_DAME.rose;
  const cf = COIFFURES_DAME[v.coiffure] || COIFFURES_DAME.longs;
  const perles = v.collier === 'aucun' ? '' : v.collier === 'ras' ? P.l('M108 222 Q125 230 142 222', 'accent', 4) + P.e(125, 230, 3.4, 3.4, 'metal') : Array.from({ length: 9 }, (_, i) => { const t = i / 8, x = (1 - t) ** 2 * 106 + 2 * (1 - t) * t * 125 + t * t * 144, y = (1 - t) ** 2 * 240 + 2 * (1 - t) * t * 266 + t * t * 240; return P.e(n(x), n(y), 2.5, 2.5, 'blanc'); }).join('') + P.f('M125 264 l4 6 l-4 7 l-4 -7 Z', 'accent');
  const voile = o.coiffe === 'voile' ? P.f('M86 116 C92 88 152 88 160 116 C176 166 186 228 198 272 C152 252 98 252 52 272 C64 228 72 166 86 116 Z', 'blanc', '', 'fill-opacity=".45"') : '';
  const derriere = (cf.dos ? P.f(cf.dos, 'cheveux') : '') + (cf.boucles ? [[86, 120], [80, 150], [84, 180], [92, 206], [104, 104], [124, 96], [144, 102], [160, 118], [168, 146], [166, 176], [158, 204]].map(([x, y]) => P.e(x, y, 17, 17, 'cheveux')).join('') : '')
    + (cf.queue ? P.f('M150 116 C186 124 198 176 182 236 C172 206 168 176 152 152 Z', 'cheveux') : '');
  const yeux = v.yeux === 'clos' ? P.l('M103 157 Q110 162 117 157 M125 157 Q133 162 141 157 M103 157 L100 160 M141 157 L144 160', 'trait', 1.8)
    : `<g${a >= 1 ? ' class="fg-yeux"' : ''}>${v.yeux === 'clin' ? '' : P.f('M103 157 Q110 150 117 157 Q110 161 103 157 Z', 'blanc') + P.e(111, 156.5, 2.8, 2.8, 'oeil')}${P.f('M125 157 Q133 149 141 157 Q133 162 125 157 Z', 'blanc')}${P.e(134, 156.5, 3, 3, 'oeil')}</g>${P.l((v.yeux === 'clin' ? 'M103 158 Q110 162 117 158' : 'M103 157 Q110 149 117 157') + ' M125 157 Q133 148 141 157 M103 157 L99 152 M141 157 L146 151', 'trait', 1.6)}`;
  return `<g${a >= 2 ? ' class="fg-cheveux"' : ''}>${derriere}</g>${voile}
${P.f('M111 196 L109 226 L98 240 L125 280 L152 240 L141 226 L139 196 Z', 'peau')}
${P.f('M38 350 C42 290 66 252 100 240 C108 262 118 273 125 277 C132 273 142 262 150 240 C184 252 208 290 212 350 Z', 'habit')}${P.om('M125 277 C132 273 142 262 150 240 C184 252 208 290 212 350 L125 350 Z')}
${P.f('M114 300 L125 290 L136 300 L125 310 Z', 'habit2')}${P.l('M125 310 V350', 'habit2', 3)}
${P.e(176, 262, 22, 18, 'habit2')}${P.e(74, 262, 22, 18, 'habit2')}
${P.f('M66 278 L44 252 L66 243 L88 266 Z', 'habit')}${ob(P, a)}${P.e(57, 243, 9, 10, 'peau')}
${perles}
${P.e(121, 158, 25, 32, 'peau')}${P.om('M121 126 A25 32 0 0 1 121 190 Z', .08)}
<g${a >= 2 ? ' class="fg-cheveux b"' : ''}>${(cf.devant || []).map((d) => P.f(d, 'cheveux')).join('')}${cf.tresse ? [0, 1, 2, 3, 4, 5].map((k) => P.e(150 + k * 3, 192 + k * 15, 8 - k * .5, 9, 'cheveux')).join('') : ''}${cf.boucles ? [[96, 132], [92, 162], [150, 130], [154, 160]].map(([x, y]) => P.e(x, y, 10, 10, 'cheveux')).join('') : ''}</g>
${P.f(cf.frange, 'cheveux')}${cf.chignon ? P.e(122, 92, 17, 14, 'cheveux') + P.l('M110 90 Q122 82 134 92', 'trait', 1) : ''}
${yeux}${P.l('M103 146 Q110 142 117 145 M126 145 Q134 141 142 146', 'trait', 1.2)}
${P.l('M121 161 L117 174 Q120 177 124 175', 'trait', 1.3)}${v.sourire ? P.f('M114 185 Q121 196 129 185 Z', 'levres') : P.f('M114 186 Q118 182 121 185 Q124 182 128 186 Q121 193 114 186 Z', 'levres')}
${P.e(106, 174, 6, 4, 'levres')}${P.e(138, 174, 6, 4, 'levres')}${v.grain ? P.e(137, 180, 1.4, 1.4, 'trait') : ''}
${P.l('M97 172 V180', 'metal', 1.4)}${P.e(97, 184, 3.6, 4.2, 'metal')}${P.l('M146 170 V178', 'metal', 1.4)}${P.e(146, 182, 3.6, 4.2, 'metal')}
${co(P, a)}`;
}
// --- le valet ---
const NEZ = { droit: 'L86 162 L97 167', rond: 'C90 152 82 160 86 166 C88 170 94 170 97 167', retrousse: 'L91 158 L88 164 L97 167', long: 'L82 166 L97 168' };
const COIFFURES_VALET = {
  court: (P) => P.f('M118 114 C146 108 168 124 165 158 C162 178 156 190 148 194 C150 176 147 160 140 154 C133 150 130 140 131 128 C124 130 115 127 110 120 Z', 'cheveux') + P.f('M134 150 L136 174 L142 170 L140 150 Z', 'cheveux') + P.l('M160 186 C168 190 168 200 160 203', 'cheveux', 3),
  boucles: (P) => [[118, 116], [134, 112], [150, 120], [162, 136], [164, 156], [158, 176], [150, 190], [140, 128], [126, 124]].map(([x, y]) => P.e(x, y, 11, 11, 'cheveux')).join(''),
  queue: (P) => COIFFURES_VALET.court(P) + P.f('M156 178 C176 180 186 204 178 226 C172 210 166 198 152 192 Z', 'cheveux') + P.e(158, 182, 4, 4, 'accent'),
  meche: (P) => COIFFURES_VALET.court(P) + P.f('M112 118 C100 128 100 146 110 154 C110 142 116 132 126 124 Z', 'cheveux'),
  crete: (P) => P.f('M118 114 C146 108 168 124 165 158 C162 178 156 190 148 194 C150 176 147 160 140 154 C133 150 130 140 131 128 C124 130 115 127 110 120 Z', 'cheveux') + P.f('M112 118 L116 92 L124 112 L132 86 L138 110 L148 88 L150 114 L162 100 L160 126 Z', 'accent'),
};
function valet(P, o) {
  const a = o.anim || 0, v = o.v || {}, ob = OBJET_VALET[o.objet] || OBJET_VALET.lance;
  const coiffeNom = o.coiffe || 'toque', co = coiffeNom === 'aucune' ? () => '' : COIFFE_VALET[coiffeNom] || COIFFE_VALET.toque;
  const coif = (COIFFURES_VALET[v.coiffure] && (v.coiffure !== 'crete' || coiffeNom === 'aucune') ? COIFFURES_VALET[v.coiffure] : COIFFURES_VALET.court)(P);
  const bouche = v.expression === 'rire' ? P.f('M98 180 Q104 190 112 184 Z', 'levres') : v.expression === 'neutre' ? P.l('M98 181 L106 181', 'trait', 1.4) : P.l('M98 180 L104 180 M106 187 Q110 189 113 186', 'trait', 1.3);
  const moust = v.moustache === 'fine' ? P.l('M95 175 Q101 172 107 176', 'cheveux', 2.2) : v.moustache === 'guidon' ? P.f('M94 176 C98 170 106 172 108 176 C104 175 100 176 98 178 C96 180 92 180 90 176 C88 172 90 168 92 168 C92 172 92 174 94 176 Z', 'cheveux') : '';
  return `${P.f('M54 350 C58 300 80 262 110 252 L156 252 C182 262 198 300 202 350 Z', 'habit')}${P.om('M128 252 L156 252 C182 262 198 300 202 350 L128 350 Z')}
${P.f('M98 258 L90 350 L110 350 L114 255 Z', 'habit2')}${P.f('M150 256 L156 350 L174 350 L164 262 Z', 'habit2')}
${[278, 298, 318, 338].map((y, i) => P.e(131 + i * .6, y, 3, 3, 'metal')).join('')}
${P.f('M118 200 L116 248 L150 248 L144 196 Z', 'peau')}
${v.col === 'simple' ? P.f('M100 252 C112 242 148 242 160 252 L156 260 C144 252 116 252 104 260 Z', 'blanc') : P.f('M98 254 L104 242 L112 250 L120 240 L128 250 L136 240 L144 250 L152 242 L160 254 C150 262 108 262 98 254 Z', 'blanc')}
${P.f(`M163 150 C161 124 142 110 120 114 C104 117 98 130 98 144 ${NEZ[v.nez] || NEZ.droit} C95 172 97 175 99 177 C96 180 96 185 100 187 C100 196 105 204 115 208 C128 213 145 210 153 201 C163 190 165 172 163 150 Z`, 'peau')}
${P.om('M140 120 C156 128 164 140 163 150 C165 172 163 190 153 201 C145 210 136 211 130 211 C142 196 146 160 140 120 Z', .1)}
${coif}
${P.e(144, 164, 5.5, 8.5, 'peau')}${P.l('M145 159 Q141 164 145 170', 'trait', 1)}${v.boucle ? P.e(145, 175, 2.6, 2.6, 'metal') : ''}
<g${a >= 1 ? ' class="fg-yeux"' : ''}>${P.f('M104 150 Q110 145 116 150 Q110 154 104 150 Z', 'blanc')}${P.e(107.5, 150, 2.3, 2.3, 'oeil')}</g>
${P.l('M102 141 Q109 137 117 141', 'trait', 2)}${P.l('M92 166 Q95 165 97 167', 'trait', 1.2)}${bouche}${moust}
${P.f('M104 262 L62 262 L66 244 L104 248 Z', 'habit')}${ob(P, a)}${P.e(68, 252, 9, 10, 'peau')}
${co(P, a)}`;
}

const DESSINS = { R: roi, D: dame, V: valet };
// figure(rang, contexte de la carte c, réglages du skin t) : t = { style, pal, coiffes: {R, D, V}, objets: {R, D, V}, anim, peaux, cheveux }
export function figure(rang, c, t) {
  const pal = Object.assign({}, t.pal, (t.parRang || {})[rang] || {});
  const P = peintre(t.style, pal, c.u);
  const o = { anim: t.anim || 0, ens: c.ens, encre: c.encre, coiffe: (t.coiffes || {})[rang], objet: (t.objets || {})[rang], orbe: t.orbe, v: (t.variantes || {})[rang] };
  return `${P.defs}<g class="fg${o.anim >= 2 ? ' fg-souffle' : ''}">${DESSINS[rang](P, o)}</g>`;
}
// les animations des figures (une seule feuille pour toute la collection)
export const CSS_FIGURES = `
.fg-souffle { transform-origin: 125px 350px; animation: fg-souffle 4.6s ease-in-out infinite; }
@keyframes fg-souffle { 0%, 100% { transform: translateY(0) scale(1); } 50% { transform: translateY(-2.5px) scale(1.008); } }
.fg-yeux { transform-box: fill-box; transform-origin: center; animation: fg-cligne 5.3s linear infinite; }
@keyframes fg-cligne { 0%, 93%, 100% { transform: scaleY(1); } 95.5% { transform: scaleY(.08); } }
.fg-cheveux { transform-origin: 124px 110px; animation: fg-cheveux 4.2s ease-in-out infinite alternate; }
.fg-cheveux.b { animation-delay: -2.1s; }
@keyframes fg-cheveux { from { transform: rotate(-1.3deg); } to { transform: rotate(1.5deg); } }
.fg-plume { transform-origin: 160px 108px; animation: fg-plume 2.4s ease-in-out infinite alternate; }
@keyframes fg-plume { from { transform: rotate(-6deg); } to { transform: rotate(7deg); } }
.fg-objet { animation: fg-objet 3s ease-in-out infinite alternate; }
.fg-objet.b { animation-delay: -1.5s; }
@keyframes fg-objet { from { opacity: .35; } to { opacity: 1; } }
.fg-eclat { transform-box: fill-box; transform-origin: center; animation: fg-eclat 2.6s ease-in-out infinite; }
.fg-eclat.b { animation-delay: -1.3s; }
@keyframes fg-eclat { 0%, 100% { transform: scale(.2) rotate(0deg); opacity: 0; } 50% { transform: scale(1) rotate(45deg); opacity: 1; } }
.fg-eventail { transform-origin: 58px 236px; animation: fg-eventail 1.6s ease-in-out infinite alternate; }
@keyframes fg-eventail { from { transform: rotate(-7deg); } to { transform: rotate(6deg); } }
.fg-drapeau { transform-origin: 72px 136px; animation: fg-drapeau 1.4s ease-in-out infinite alternate; }
@keyframes fg-drapeau { from { transform: skewY(-4deg) scaleX(.95); } to { transform: skewY(4deg) scaleX(1.03); } }
.fg-flamme { transform-box: fill-box; transform-origin: 50% 100%; animation: fg-flamme .9s ease-in-out infinite alternate; }
@keyframes fg-flamme { from { transform: scale(.92, .86) skewX(-4deg); } to { transform: scale(1.05, 1.1) skewX(4deg); } }
`;
