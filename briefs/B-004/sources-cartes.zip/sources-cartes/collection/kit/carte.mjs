// Fabrique d'un skin à partir d'une fiche courte, et rendu des cartes (dos, rectos, coins).
// Les coins (valeur + enseigne) sont posés ici, à la place et à la taille des cartes de l'appli, pour rester lisibles.
import { L, H, R, ENSEIGNES, ROUGE, NOM_ENSEIGNE, enseigne, cadre, semisEnseignes, n, texte, largeurTexte, clair, sombre, melange, lum, hasard, miroir } from './base.mjs';
import { figure } from './figures.mjs';
import { lustre } from './dessin.mjs';
import G from './glyphes.json' with { type: 'json' };
import { aplatir } from './aplat.mjs';
import { CSS_EFFETS } from './effets.mjs';
export const NIVEAU = { 'Commune': 0, 'Rare': 1, 'Épique': 2, 'Légendaire': 3 };
export const NOMS_RANGS = { A: 'As', R: 'Roi', D: 'Dame', V: 'Valet' };

// --- la valeur en contours (pour pouvoir s'en servir comme masque) ---
function glyphesBruts(s, x, y, taille, espace) {
  const k = taille / G.upm, w = largeurTexte(s, taille, espace); let x0 = x - w / 2; const out = [];
  for (const ch of s) { const g = G.g[ch]; out.push(`<path transform="translate(${n(x0, 2)} ${y}) scale(${n(k, 4)} ${n(-k, 4)})" d="${g.d}"/>`); x0 += g.a * k + espace; }
  return out.join('');
}
// --- palette des figures, déduite des couleurs du skin si la fiche ne la donne pas ---
const PEAUX = ['#F2C9A0', '#E3AE84', '#C98D62', '#9A6544', '#F6D8C0', '#B07A52'];
const CHEVEUX = ['#3B2416', '#6B3E1E', '#1C1714', '#B5652B', '#D9B26A', '#2E2A3A', '#8A3B1E'];
const CHEVEUX_ROI = ['#3B2416', '#6B3E1E', '#1C1714', '#9A9A9A', '#D8D2C4', '#B5652B'];
// chaque figure a sa peau et ses cheveux (sauf si la fiche les impose) : les trois ne se ressemblent pas
function variantes(def, graine) {
  const imp = (def.fig || {}).pal || {}; const out = {};
  ['R', 'D', 'V'].forEach((r, k) => { const h = hasard(graine * 13 + k * 101 + 7); h(); const o = {};
    if (!imp.peau) o.peau = PEAUX[Math.floor(h() * PEAUX.length)];
    if (!imp.cheveux) o.cheveux = (r === 'R' ? CHEVEUX_ROI : CHEVEUX)[Math.floor(h() * (r === 'R' ? CHEVEUX_ROI.length : CHEVEUX.length))];
    out[r] = Object.assign(o, ((def.fig || {}).parRang || {})[r] || {}); });
  return out;
}
export function paletteFigures(def, graine) {
  const [c1, c2, c3] = def.couleurs; const h = hasard(graine);
  const pal = { peau: PEAUX[Math.floor(h() * PEAUX.length)], cheveux: CHEVEUX[Math.floor(h() * CHEVEUX.length)], habit: c1, habit2: c2, metal: '#E6B73A', blanc: '#FBF7EE', accent: c3, levres: '#C8384F', oeil: '#1b1b1b', bois: '#8A5A2B', vert: '#2F8A4A', trait: '#24180F',
    silhouette: '#17131d', ombreTrait: clair(c1, .4), neonTrait: '#FFF1C2', neonPeau: '#FFC9A8', papierFig: '#F6EFE2' };
  // éviter un habit de la couleur du papier
  return Object.assign(pal, (def.fig || {}).pal || {});
}
// --- tirage des personnages : chaque skin a les siens (la fiche peut tout imposer) ---
const pioche = (h, l) => l[Math.floor(h() * l.length)];
export function tirerPersonnages(def, graine) {
  const h = hasard(graine * 31 + 17); for (let i = 0; i < 3; i++) h(); const f = def.fig || {};
  const coiffes = Object.assign({ R: pioche(h, ['couronne', 'couronne', 'haute', 'laurier', 'couronne', 'haute']), D: pioche(h, ['diademe', 'couronne', 'fleurs', 'diademe', 'plumes', 'voile']), V: pioche(h, ['toque', 'casquette', 'bonnet', 'melon', 'aucune', 'toque', 'capuche']) }, f.coiffes || {});
  const objets = Object.assign({ R: pioche(h, ['sceptre', 'epee', 'sceptre', 'trident', 'baguette', 'chope']), D: pioche(h, ['rose', 'eventail', 'miroir', 'rose', 'coupe', 'cartes']), V: pioche(h, ['lance', 'torche', 'epee', 'drapeau', 'cartes', 'lance', 'micro']) }, f.objets || {});
  const vR = { visage: pioche(h, ['ovale', 'rond', 'long']), barbe: pioche(h, ['pleine', 'pointue', 'fourchue', 'courte', 'moustache', 'favoris']), moustache: pioche(h, ['normale', 'normale', 'guidon']), sourcils: pioche(h, ['severe', 'doux', 'droits']), col: pioche(h, ['hermine', 'hermine', 'fourrure', 'simple']), lunettes: h() < .16, rire: h() < .3, chauve: h() < .12 };
  const vD = { coiffure: pioche(h, ['longs', 'carre', 'boucles', 'tresse', 'queue', 'chignon']), yeux: pioche(h, ['ouverts', 'ouverts', 'clos', 'clin']), collier: pioche(h, ['perles', 'ras', 'perles', 'aucun']), sourire: h() < .4, grain: h() < .3 };
  const vV = { coiffure: pioche(h, ['court', 'boucles', 'queue', 'meche', 'crete']), nez: pioche(h, ['droit', 'rond', 'retrousse', 'long']), moustache: pioche(h, ['aucune', 'aucune', 'fine', 'guidon']), expression: pioche(h, ['sourire', 'neutre', 'rire']), boucle: h() < .3, col: pioche(h, ['fraise', 'simple']) };
  const imp = f.variantes || {};
  return { coiffes, objets, variantes: { R: Object.assign(vR, imp.R || {}), D: Object.assign(vD, imp.D || {}), V: Object.assign(vV, imp.V || {}) } };
}
// --- enseignes des cartes à chiffres, selon le style ---
const tourne = (p) => (p.bas ? ` rotate(180)` : '');
export const PIPS = {
  simple: (c, p) => `<g transform="translate(${p.x} ${p.y})${tourne(p)}">${enseigne(c.ens, 0, 0, p.t, `fill="${c.encre}"`)}</g>`,
  contour: (c, p, i, s) => `<g transform="translate(${p.x} ${p.y})${tourne(p)}">${enseigne(c.ens, 0, 0, p.t, `fill="${c.encre}" stroke="${s.accentPip}" stroke-width="${n(48 / p.t, 2)}" paint-order="stroke"`)}</g>`,
  ombre: (c, p, i, s) => `<g transform="translate(${p.x} ${p.y})${tourne(p)}">${enseigne(c.ens, 2.4, 3, p.t, `fill="${s.accentPip}" opacity=".45"`)}${enseigne(c.ens, 0, 0, p.t, `fill="${c.encre}"`)}</g>`,
  pastille: (c, p, i, s) => `<g transform="translate(${p.x} ${p.y})${tourne(p)}"><circle r="${n(p.t * .62)}" fill="${s.fondPip}" stroke="${s.accentPip}" stroke-width="1.4"/>${enseigne(c.ens, 0, 0, n(p.t * .74), `fill="${c.encre}"`)}</g>`,
  losange: (c, p, i, s) => `<g transform="translate(${p.x} ${p.y})${tourne(p)}"><path d="M0 ${n(-p.t * .72)} L${n(p.t * .6)} 0 L0 ${n(p.t * .72)} L${n(-p.t * .6)} 0 Z" fill="${s.fondPip}" stroke="${s.accentPip}" stroke-width="1.4"/>${enseigne(c.ens, 0, 0, n(p.t * .62), `fill="${c.encre}"`)}</g>`,
  double: (c, p, i, s) => `<g transform="translate(${p.x} ${p.y})${tourne(p)}">${enseigne(c.ens, 0, 0, n(p.t * 1.28), `fill="none" stroke="${s.accentPip}" stroke-width="${n(40 / p.t, 2)}"`)}${enseigne(c.ens, 0, 0, p.t, `fill="${c.encre}"`)}</g>`,
  neon: (c, p) => { const k = p.t / 24, sw = n(2.6 / k, 2); return `<g transform="translate(${p.x} ${p.y})${tourne(p)} translate(${n(-p.t / 2)} ${n(-p.t / 2)}) scale(${n(k, 3)})"><path d="${ENSEIGNES[c.ens]}" fill="${c.encre}" opacity=".2"/><path d="${ENSEIGNES[c.ens]}" fill="none" stroke="${c.encre}" stroke-width="${n(sw * 3, 2)}" opacity=".25" stroke-linejoin="round"/><path d="${ENSEIGNES[c.ens]}" fill="none" stroke="${c.encre}" stroke-width="${sw}" stroke-linejoin="round"/><path d="${ENSEIGNES[c.ens]}" fill="none" stroke="#fff" stroke-width="${n(sw * .3, 2)}" opacity=".8" stroke-linejoin="round"/></g>`; },
  tampon: (c, p) => `<g transform="translate(${p.x} ${p.y})${tourne(p)} rotate(${(p.x * 7 + p.y * 3) % 17 - 8})">${enseigne(c.ens, 0, 0, p.t, `fill="${c.encre}" stroke="${c.encre}" stroke-width="1.2" stroke-dasharray="2 1.5" opacity=".9"`)}</g>`,
};
// --- l'as ---
export const AS = {
  simple: (c) => enseigne(c.ens, 125, 176, 112, `fill="${c.encre}"`),
  cadre: (c, s) => `<rect x="62" y="84" width="126" height="184" rx="14" fill="none" stroke="${s.accentPip}" stroke-width="2.4"/><rect x="70" y="92" width="110" height="168" rx="10" fill="none" stroke="${s.accentPip}" stroke-width=".9"/>${[[62, 84], [188, 84], [62, 268], [188, 268]].map(([x, y]) => `<circle cx="${x}" cy="${y}" r="5" fill="${s.accentPip}"/>`).join('')}${enseigne(c.ens, 125, 176, 100, `fill="${c.encre}"`)}`,
  medaillon: (c, s) => `<circle cx="125" cy="176" r="74" fill="${s.fondPip}" stroke="${s.accentPip}" stroke-width="3"/><circle cx="125" cy="176" r="66" fill="none" stroke="${s.accentPip}" stroke-width="1" stroke-dasharray="2 5"/>${enseigne(c.ens, 125, 176, 96, `fill="${c.encre}"`)}`,
  rayons: (c, s) => `<g opacity=".55">${Array.from({ length: 24 }, (_, i) => `<path transform="rotate(${i * 15} 125 176)" d="M125 176 L119 70 H131 Z" fill="${s.accentPip}"/>`).join('')}</g><circle cx="125" cy="176" r="60" fill="${s.papier}"/>${enseigne(c.ens, 125, 176, 100, `fill="${c.encre}"`)}`,
  double: (c, s) => `${enseigne(c.ens, 125, 176, 150, `fill="none" stroke="${s.accentPip}" stroke-width="1.6"`)}${enseigne(c.ens, 125, 176, 128, `fill="none" stroke="${s.accentPip}" stroke-width=".8" stroke-dasharray="3 3"`)}${enseigne(c.ens, 125, 176, 100, `fill="${c.encre}"`)}`,
  neon: (c, s) => `<circle cx="125" cy="176" r="70" fill="none" stroke="${s.accentPip}" stroke-width="7" opacity=".2"/><circle cx="125" cy="176" r="70" fill="none" stroke="${s.accentPip}" stroke-width="2"/>${PIPS.neon(c, { x: 125, y: 176, t: 92 })}`,
};
// --- fond des figures ---
const FONDS_FIG = {
  arche: (c, s) => `<path d="M38 350 V128 C38 56 212 56 212 128 V350 Z" fill="${s.teinte}"/><path d="M46 350 V130 C46 66 204 66 204 130 V350" fill="none" stroke="${s.cadreRecto}" stroke-width="1.4" opacity=".7"/>`,
  halo: (c, s) => `<circle cx="125" cy="168" r="96" fill="${s.teinte}"/><circle cx="125" cy="168" r="104" fill="none" stroke="${s.cadreRecto}" stroke-width="1.2" stroke-dasharray="3 5" opacity=".8"/>`,
  bandes: (c, s) => `<g opacity=".9">${Array.from({ length: 9 }, (_, i) => `<rect x="${i * 30 - 10}" y="0" width="15" height="350" fill="${s.teinte}"/>`).join('')}</g>`,
  aucun: () => '',
};

// réglages des personnages pour un skin fait main (mêmes tirages que la fabrique)
export function personnages(def, niveau = 3) {
  const graine = def.cle.length * 131 + def.cle.charCodeAt(1) * 7 + def.cle.charCodeAt(5); const tir = tirerPersonnages(def, graine);
  return { style: (def.fig || {}).style || 'plat', pal: paletteFigures(def, graine), coiffes: tir.coiffes, objets: tir.objets, variantes: tir.variantes, anim: niveau, parRang: variantes(def, graine), orbe: (def.fig || {}).orbe };
}
// enseignes animées des épiques et légendaires : on enveloppe le dessin dans un groupe qui bouge
export const anime = (cls, i, dedans) => `<g class="${cls}" style="--i:${i}">${dedans}</g>`;
export const CSS_ANIME = `
.ep-flotte { animation: ep-flotte 3s ease-in-out infinite alternate; animation-delay: calc(var(--i) * -.37s); }
@keyframes ep-flotte { from { transform: translateY(2.5px); } to { transform: translateY(-3.5px); } }
.ep-pulse { transform-box: fill-box; transform-origin: center; animation: ep-pulse 2.6s ease-in-out infinite; animation-delay: calc(var(--i) * -.29s); }
@keyframes ep-pulse { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.1); } }
.ep-tourne { transform-box: fill-box; transform-origin: center; animation: ep-tourne 3.6s ease-in-out infinite alternate; animation-delay: calc(var(--i) * -.41s); }
@keyframes ep-tourne { from { transform: rotate(-9deg); } to { transform: rotate(9deg); } }
.ep-lueur { animation: ep-lueur 2.4s ease-in-out infinite alternate; animation-delay: calc(var(--i) * -.33s); }
@keyframes ep-lueur { from { opacity: .25; } to { opacity: .95; } }
.ep-gresille { animation: ep-gresille 3.1s steps(1) infinite; animation-delay: calc(var(--i) * -.53s); }
@keyframes ep-gresille { 0%, 100% { opacity: 1; } 40% { opacity: .3; } 43% { opacity: 1; } 47% { opacity: .4; } 50% { opacity: 1; } }
.ra-as { transform-box: fill-box; transform-origin: center; animation: ra-as 4s ease-in-out infinite alternate; }
@keyframes ra-as { from { transform: scale(.97); } to { transform: scale(1.03); } }
` + CSS_EFFETS;
// --- fabrique ---
export function creerSkin(def) {
  const niveau = NIVEAU[def.rarete]; const [c1, c2, c3] = def.couleurs; const graine = def.cle.length * 131 + def.cle.charCodeAt(1) * 7 + def.cle.charCodeAt(5);
  const face = Object.assign({ papier: '#FBF7EF', encre: '#16130F', rouge: '#C8102E' }, def.face || {});
  // lisibilité : un cartouche couleur papier sous chaque coin, pour que la valeur ne se perde jamais sur une figure ou un décor
  if (!face.onglet && !face.contour && def.sansOnglet !== true) Object.assign(face, { onglet: face.papier, ongletOp: 1 });
  const sombreRecto = lum(face.papier) < .35;
  const reglages = { teinte: def.teinte || (sombreRecto ? clair(face.papier, .12) : melange(face.papier, c1, .2)), cadreRecto: def.cadreRecto || (lum(c1) > .8 ? c2 : c1),
    accentPip: def.accentPip || (lum(c1) > .8 ? c2 : c1), fondPip: def.fondPip || (sombreRecto ? clair(face.papier, .1) : melange(face.papier, c1, .14)), papier: face.papier };
  const tir = tirerPersonnages(def, graine);
  const t = { style: (def.fig || {}).style || 'plat', pal: paletteFigures(def, graine), coiffes: tir.coiffes, objets: tir.objets, variantes: tir.variantes, anim: Math.min(niveau, 3), parRang: variantes(def, graine), orbe: (def.fig || {}).orbe };
  const pip = typeof def.pip === 'function' ? def.pip : PIPS[def.pip || 'simple'];
  const as = typeof def.as === 'function' ? def.as : AS[def.as || 'simple'];
  const fondFig = typeof def.fondFigure === 'function' ? def.fondFigure : FONDS_FIG[def.fondFigure || 'arche'];
  return {
    id: def.id, cle: def.cle, nom: def.nom, rarete: def.rarete, famille: def.famille, ancien: def.ancien, couleurs: def.couleurs, descDos: def.descDos, descRecto: def.descRecto,
    fx: def.fx || ['co', 'ra', 'ep', 'le'][niveau], aura: def.aura || [c1, c3], gerbe: def.gerbe ?? [0, 8, 14, 22][niveau],
    bouge: def.bouge, retournement: def.retournement || ['La carte rebondit.', 'Petite gerbe d’éclats et une onde.', 'Gerbe d’éclats, deux ondes et des rayons.', 'Grande gerbe, rayons et onde.'][niveau],
    face, reglages, figures: t, css: def.css || '',
    dos: (u) => def.dos(u, def) + (niveau === 0 && def.lustre !== false ? lustre(u, -((graine % 70) / 10)) : ''),
    recto: (c) => ({ fond: (def.fondRecto ? def.fondRecto(c, reglages) : cadre(`fill="${face.papier}"`)) + (def.decorRecto ? def.decorRecto(c, reglages) : ''),
      bord: def.bordRecto ? def.bordRecto(c, reglages) : `<rect x="8" y="8" width="${L - 16}" height="${H - 16}" rx="15" fill="none" stroke="${reglages.cadreRecto}" stroke-width="1.8"/>`,
      devant: def.devantRecto ? def.devantRecto(c, reglages) : '',
      dessus: def.embleme && c.num ? `<g transform="translate(214 36)">${def.embleme(c.u)}</g><g transform="translate(36 314) rotate(180)">${def.embleme(c.u + 'b')}</g>` : '' }),
    figure: (c) => def.figure ? def.figure(c, reglages, t) : fondFig(c, reglages) + figure(c.rang, c, t) + (def.surFigure ? def.surFigure(c, reglages) : ''),
    pip: (c, p, i) => pip(c, p, i, reglages),
    liens: def.liens,
    as: (c) => (def.sousAs ? def.sousAs(c, reglages) : '') + (niveau === 1 ? `<g class="ra-as">${as(c, reglages)}</g>` : as(c, reglages)),
  };
}

// --- rendu d'une face ---
let compteur = 0;
export const remiseAZero = () => { compteur = 0; };
export const uid = (p = 'k') => p + (++compteur).toString(36);
export const enveloppe = (dedans, titre, u, autonome = false, css = '') => `<svg${autonome ? ' xmlns="http://www.w3.org/2000/svg"' : ''} viewBox="0 0 ${L} ${H}"${autonome ? ` width="${L}" height="${H}"` : ''} role="img" aria-label="${titre}">${css ? `<style>${css}</style>` : ''}<clipPath id="c${u}"><rect width="${L}" height="${H}" rx="${R}"/></clipPath><g clip-path="url(#c${u})">${aplatir(dedans)}</g></svg>`;
export function dos(s, autonome = false, css = '') { const u = uid(); return enveloppe(s.dos(u), `Dos du skin ${s.nom}`, u, autonome, css); }
export function recto(s, rang, ens, autonome = false, css = '') {
  const u = uid(); const f = s.face; const rouge = ROUGE[ens]; const encre = rouge ? f.rouge : f.encre;
  const c = { u, rang, ens, encre, rouge, face: f, num: Number(rang) || 0 };
  const r = s.recto ? s.recto(c, ens) || {} : {};
  let centre;
  if (rang === 'A' && s.as) centre = s.as(c);
  else if ('VDR'.includes(rang) && s.figure) centre = s.figure(c);
  else if (c.num && s.pip) { const ps = semisEnseignes(c.num); centre = (s.liens ? s.liens(c, ps) : '') + ps.map((p, i) => s.pip(c, p, i)).join(''); }
  else centre = (r.centre || '') + enseigne(ens, 125, 180, 112, `fill="${encre}"`);
  const large = rang.length > 1;
  const glyphes = (k) => glyphesBruts(rang, large ? 44 : 41, 66, large ? 50 : 60, large ? -3 : 0) + enseigne(ens, 41, 98, 36);
  const coin = (k) => (f.onglet ? `<path d="M10 10 H${large ? 78 : 70} V108 Q${large ? 78 : 70} 122 ${large ? 64 : 56} 122 H10 Z" fill="${f.onglet}" opacity="${Math.min(1, (f.ongletOp ?? .82) + .25)}"/>` : '')
    + (f.ombre ? `<g transform="translate(2 2.6)" fill="${f.ombre}">${glyphes(k)}</g>` : '')
    + `<g fill="${encre}"${f.contour ? ` stroke="${f.contour}" stroke-width="${f.contourEp ?? 1.8}" paint-order="stroke" stroke-linejoin="round"` : ''}>${glyphes(k)}</g>`
    + (f.reflet ? `<clipPath id="ci${k}${u}">${glyphes(k)}</clipPath><g clip-path="url(#ci${k}${u})"><g transform="skewX(-20)"><rect class="reflet-indice" x="-6" y="6" width="20" height="124" fill="${f.reflet}"/></g></g>` : '');
  const dedans = (r.fond || cadre(`fill="${f.papier}"`)) + (r.bord || '') + centre + (r.devant || '') + coin('a') + `<g transform="rotate(180 125 175)">${coin('b')}</g>` + (r.dessus || '');
  return enveloppe(dedans, `${NOMS_RANGS[rang] || rang} de ${NOM_ENSEIGNE[ens]}, skin ${s.nom}`, u, autonome, css);
}
export const CSS_CARTE = `
.reflet-indice { animation: reflet-indice 4.6s ease-in-out infinite; }
@keyframes reflet-indice { 0%, 58% { transform: translateX(0); } 88%, 100% { transform: translateX(150px); } }
`;
