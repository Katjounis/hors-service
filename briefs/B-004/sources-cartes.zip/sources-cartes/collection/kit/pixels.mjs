// Dessin en pixels : une liste de lignes de caractères, chaque caractère renvoie à une couleur (« . » = vide).
export function pixels(lignes, x0, y0, taille, couleurs, attrs = '') {
  const out = [];
  lignes.forEach((l, j) => { let i = 0; while (i < l.length) { const ch = l[i]; if (ch === '.' || !couleurs[ch]) { i++; continue; } let k = i; while (k < l.length && l[k] === ch) k++; out.push(`<rect x="${x0 + i * taille}" y="${y0 + j * taille}" width="${(k - i) * taille}" height="${taille}" fill="${couleurs[ch]}"/>`); i = k; } });
  return `<g ${attrs} shape-rendering="crispEdges">${out.join('')}</g>`;
}
