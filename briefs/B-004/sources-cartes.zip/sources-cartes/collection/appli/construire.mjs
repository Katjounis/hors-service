// Construit cartes-skins.js (pour l'appli) à partir du kit et des 100 skins.
// node appli/construire.mjs [sortie]   (esbuild doit être installé : npm i -g esbuild)
import { execFileSync } from 'node:child_process';
import { readFileSync, writeFileSync, statSync } from 'node:fs';
const ICI = new URL('./', import.meta.url).pathname;
const sortie = process.argv[2] || ICI + 'cartes-skins.js';
execFileSync('esbuild', [ICI + 'cartes-skins.src.mjs', '--bundle', '--format=iife', '--minify', '--target=es2019', '--charset=utf8', '--legal-comments=none', '--outfile=' + sortie], { stdio: 'inherit' });
const tete = `// Hors Service : cartes custom (100 skins de cartes). Fichier construit par « node appli/construire.mjs » à partir des sources du kit\n// (dossier sources-cartes de B-004) : ne pas le modifier à la main. Chargé à la demande par compte.js.\n`;
writeFileSync(sortie, tete + readFileSync(sortie, 'utf8'));
console.log(sortie, Math.round(statSync(sortie).size / 1024) + ' Ko');
