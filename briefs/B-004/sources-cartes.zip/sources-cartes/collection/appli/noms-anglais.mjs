// Noms anglais des 100 skins et des familles (toute chaîne affichée a sa traduction anglaise).
export const NOMS_EN = {
  'L-001': 'King of Chaos', 'L-002': 'God of Purple', 'L-003': 'Infinite Jackpot', 'L-004': 'Black Hole', 'L-005': 'Ultimate Hors Service',
  'E-001': 'Fire Dragon', 'E-002': 'Electric Storm', 'E-003': 'Dimensional Portal', 'E-004': 'Abyssal Ocean', 'E-005': 'Cosmos', 'E-006': 'Kraken', 'E-007': 'Phoenix', 'E-008': 'Cyberpunk', 'E-009': 'Card Tornado', 'E-010': 'Abduction',
  'R-001': 'Bar Neon', 'R-002': 'Karaoke', 'R-003': 'Disco Ball', 'R-004': 'Lasers', 'R-005': 'Northern Lights', 'R-006': 'Graffiti', 'R-007': 'Stencil', 'R-008': 'Stickers', 'R-009': 'Skateboard', 'R-010': 'Stage Curtain',
  'R-011': 'Stained Glass', 'R-012': 'Flames', 'R-013': 'Great Wave', 'R-014': 'Jungle', 'R-015': 'Milky Way', 'R-016': 'Holographic', 'R-017': 'Circuit Board', 'R-018': 'Chrome', 'R-019': 'Retro Sun', 'R-020': 'Radar',
  'R-021': 'Magic Crystal', 'R-022': 'Lava Flow', 'R-023': 'Enchanted Forest', 'R-024': 'Cursed Tomb', 'R-025': 'Carnival', 'R-026': 'Infernal Machine', 'R-027': 'Glacier', 'R-028': 'Zombie Hand', 'R-029': 'Ghost Ship', 'R-030': 'Drinks in Orbit',
  'C-001': 'Original Deck', 'C-002': 'Bistro Red', 'C-003': 'Midnight Blue', 'C-004': 'Gingham Tablecloth', 'C-005': 'Breton Stripes', 'C-006': 'Polka Dots', 'C-007': 'Chevrons', 'C-008': 'Checkerboard', 'C-009': 'Tartan', 'C-010': 'Beer Mat',
  'C-011': 'Bottle Caps', 'C-012': 'Peanuts', 'C-013': 'Morning-After Pizza', 'C-014': 'Lime', 'C-015': 'Ice Cubes', 'C-016': 'Straws', 'C-017': 'Pickles', 'C-018': 'Party Cups', 'C-019': 'Hazard Tape', 'C-020': 'Out of Order',
  'C-021': 'Receipt', 'C-022': 'Fragile Box', 'C-023': 'Sticky Notes', 'C-024': 'Barcode', 'C-025': 'Error 96', 'C-026': 'Low Battery', 'C-027': 'Loading', 'C-028': 'Pixel Heart', 'C-029': '8-bit Drinks', 'C-030': 'Test Card',
  'C-031': 'Cassette', 'C-032': '70s Wallpaper', 'C-033': 'Grandma’s Table', 'C-034': 'Arcade Token', 'C-035': 'Minitel Breakdown', 'C-036': 'Floppy Disk', 'C-037': 'Smileys', 'C-038': 'Odd Socks', 'C-039': 'Rubber Duck', 'C-040': 'Pigeon',
  'C-041': 'Moustaches', 'C-042': 'Confetti', 'C-043': 'Failed Camo', 'C-044': 'Leopard', 'C-045': 'Plasters', 'C-046': 'Midnight', 'C-047': 'Torn Posters', 'C-048': 'Subway Tiles', 'C-049': 'Marble', 'C-050': 'Malachite',
  'C-051': 'Bar Counter Wood', 'C-052': 'Studded Leather', 'C-053': 'Frost', 'C-054': 'Blueprint', 'C-055': 'Desert',
};
export const FAMILLES_EN = {
  'Légendaires': 'Legendaries', 'Créatures': 'Creatures', 'Phénomènes': 'Phenomena', 'Mondes': 'Worlds', 'Néon et nuit': 'Neon and night', 'Street art': 'Street art', 'Matières': 'Materials',
  'Éléments': 'Elements', 'Futur': 'Future', 'Classiques': 'Classics', 'Apéro et soirée': 'Drinks and parties', 'Panne et maintenance': 'Breakdowns and repairs', 'Rétro et pixels': 'Retro and pixels', 'Drôles et absurdes': 'Funny and absurd',
};
