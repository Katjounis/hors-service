// Hors Service : cartes custom (skins de cartes), version pour l'appli.
// Construit par appli/construire.mjs à partir du kit de dessin et des 100 skins : cartes-skins.js n'est pas à modifier à la main.
// Habille les cartes de l'appli (.pc) avec le skin choisi dans « Mon compte ». Rien ne change dans les règles :
// - la valeur et l'enseigne sont redessinées à la place et à la taille des coins de l'appli ;
//   sous 44 px de large, c'est la face de l'appli qui reste visible (plus lisible), seul le dos est habillé ;
// - le dos ne dépend jamais de la carte : tous les dos d'un même écran sont identiques ;
// - les animations ont un budget : les plus grandes cartes à l'écran s'animent d'abord, 6 au plus, et pas plus
//   d'une quarantaine d'éléments animés en même temps ; si l'écran ralentit (mesuré), le budget baisse tout seul ;
//   rien ne bouge si l'appareil demande moins d'animations ou si le joueur les coupe dans « Mon compte ».
import { SKINS } from '../skins/index.mjs';
import { dos as dessinerDos, recto as dessinerRecto, NIVEAU, CSS_CARTE, CSS_ANIME } from '../kit/carte.mjs';
import { CSS_FIGURES } from '../kit/figures.mjs';
import { CSS_DESSIN } from '../kit/dessin.mjs';
import { NOMS_EN, FAMILLES_EN } from './noms-anglais.mjs';

const MAX_ANIMEES = 6, LARGEUR_MINI = 44;
const faible = (navigator.deviceMemory && navigator.deviceMemory <= 2) || (navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 4);
let budget = faible ? 16 : 40;                    // éléments animés en même temps sur l'écran
const poids = new Map();                          // carte (skin + dos ou face) → nombre d'animations mesuré
const ESTIME = [2, 10, 25, 45];                   // avant mesure, selon la rareté
const PAR_ID = new Map(SKINS.map((s) => [s.id, s]));
const RARETES_EN = { Commune: 'Common', Rare: 'Rare', 'Épique': 'Epic', 'Légendaire': 'Legendary' };
const liste = SKINS.map((s) => ({ id: s.id, nom: s.nom, nomEn: NOMS_EN[s.id] || s.nom, rarete: s.rarete, rareteEn: RARETES_EN[s.rarete], niveau: NIVEAU[s.rarete], famille: s.famille, familleEn: FAMILLES_EN[s.famille] || s.famille }));

// --- styles : ceux du kit, ceux des skins, et l'habillage des cartes de l'appli ---
// (les anciennes règles de la page du premier jet, .effet et .joue, ne servent pas ici)
const sansPage = (css) => css.split('\n').filter((l) => !/^\s*(\.effet|\.joue|@keyframes fx-)/.test(l)).join('\n');
const CSS_KIT = sansPage(CSS_CARTE + CSS_ANIME + CSS_FIGURES + CSS_DESSIN);
const CSS_SKIN = (s) => sansPage(s.css || '');
const CSS_APPLI = `
.hsc-fige, .hsc-fige * { animation: none !important; }
.pc[data-skin] { container-type: inline-size; isolation: isolate; }
.pc[data-skin] > .pc-corner, .pc[data-skin] > .pc-mid, .pc[data-skin] > .pc-pattern { visibility: hidden; }
.pc-skin { position: absolute; inset: 0; z-index: -1; display: block; overflow: hidden; border-radius: inherit; pointer-events: none; contain: strict; }
.pc-skin > svg { display: block; width: 100%; height: 100%; }
@container (max-width: ${LARGEUR_MINI}px) {
  .pc-skin.hsc-face { display: none; }
  .pc[data-skin] > .pc-corner, .pc[data-skin] > .pc-mid { visibility: visible; }
}
/* pendant le retournement (anim.js), la carte montre son dos : celui du skin, remis à l'endroit (la carte est vue de dos) */
.pc[data-skin].hs-flip::after { background: var(--hs-dos-fixe, var(--kraft)) center / 100% 100% no-repeat; box-shadow: none; transform: scaleX(-1); }
`;
let stylesPoses = false;
function poserStyles() {
  if (stylesPoses) return; stylesPoses = true;
  const st = document.createElement('style'); st.id = 'hs-cartes-skins';
  st.textContent = CSS_KIT + SKINS.map(CSS_SKIN).join('\n') + CSS_APPLI;
  document.head.appendChild(st);
}
// le dos en image fixe, pour la demi-seconde où la carte se retourne (anim.js montre un dos par-dessus)
function dosFixe(s) {
  const svg = dessinerDos(s, true, CSS_KIT + CSS_SKIN(s) + '*{animation:none!important}');
  return `url("data:image/svg+xml,${encodeURIComponent(svg)}")`;
}

// --- lecture d'une carte de l'appli : « R ♠ », « 10 ♥ », ou un dos ---
const ENS = { '♠': 'S', '♥': 'H', '♦': 'D', '♣': 'C' };
const RANG = { K: 'R', Q: 'D', J: 'V', T: '10' };
function lireCarte(pc) {
  if (pc.classList.contains('pc-back')) return { dos: true };
  const m = /^\s*(10|[2-9AKQJTRDV])\s*([♠♥♦♣])/.exec(pc.getAttribute('aria-label') || '');
  return m ? { rang: RANG[m[1]] || m[1], ens: ENS[m[2]] } : null;
}

// --- état ---
let actif = null, animations = true, observe = false;
const reduit = typeof matchMedia === 'function' ? matchMedia('(prefers-reduced-motion: reduce)') : { matches: false };

// --- animations : seulement les plus grandes cartes visibles, 6 au plus ---
const visibles = new Set();
const io = typeof IntersectionObserver === 'function' ? new IntersectionObserver((entrees) => {
  for (const e of entrees) {
    if (!e.target.isConnected) { io.unobserve(e.target); visibles.delete(e.target); continue; }
    if (e.isIntersecting) visibles.add(e.target); else visibles.delete(e.target);
  }
  planifier();
}) : null;
let attente = 0;
function planifier() { if (!attente) attente = requestAnimationFrame(repartir); }
function repartir() {
  attente = 0;
  const peut = actif && animations && budget > 0 && !reduit.matches && !document.hidden;
  const candidates = [];
  if (peut) for (const o of visibles) {
    if (!o.isConnected) { visibles.delete(o); if (io) io.unobserve(o); continue; }
    const r = o.getBoundingClientRect();
    if (r.width >= LARGEUR_MINI) candidates.push([r.width * r.height, o]);
  }
  candidates.sort((a, b) => b[0] - a[0]);
  // les plus grandes d'abord, tant que le budget le permet (la première passe toujours)
  const choisies = new Set(); let reste = budget;
  for (const [, o] of candidates) {
    if (choisies.size >= MAX_ANIMEES) break;
    const w = poids.get(o.getAttribute('data-sig')) ?? ESTIME[NIVEAU[actif.rarete]];
    if (!choisies.size || w <= reste) { choisies.add(o); reste -= w; }
  }
  document.querySelectorAll('.pc-skin').forEach((o) => { const fige = !choisies.has(o); if (o.classList.contains('hsc-fige') !== fige) o.classList.toggle('hsc-fige', fige); });
  if (choisies.size) requestAnimationFrame(() => {
    let change = false;
    choisies.forEach((o) => { const sig = o.getAttribute('data-sig'); if (o.isConnected && !poids.has(sig)) { poids.set(sig, Math.max(1, o.getAnimations({ subtree: true }).length)); change = true; } });
    if (change) planifier(); else controler();
  });
}
// garde-fou : on mesure la fluidité un instant ; si l'écran ralentit, moins de cartes s'animent (jusqu'à aucune)
let mesure = false, dernierControle = 0;
function controler() {
  if (mesure || budget <= 0 || document.hidden || !document.querySelector('.pc-skin:not(.hsc-fige)')) return;
  const t0 = performance.now(); if (t0 - dernierControle < 4000) return;
  dernierControle = t0; mesure = true; let nb = 0, lentes = 0, av = t0;
  const image = (t) => {
    nb++; if (t - av > 50) lentes++; av = t;
    if (t - t0 < 1500) { requestAnimationFrame(image); return; }
    mesure = false;
    const ips = nb / ((t - t0) / 1000);
    if (ips < 48 || lentes > 3) { budget = budget > 12 ? Math.floor(budget / 2) : 0; dernierControle = 0; planifier(); }
  };
  requestAnimationFrame(image);
}

// --- habillage d'une carte ---
function calque(pc) { for (const e of pc.children) if (e.classList.contains('pc-skin')) return e; return null; }
function retirer(pc) {
  const o = calque(pc); if (o) { visibles.delete(o); if (io) io.unobserve(o); o.remove(); }
  if (pc.hasAttribute('data-skin')) pc.removeAttribute('data-skin');
}
function habiller(pc) {
  if (!actif) { retirer(pc); return; }
  const c = lireCarte(pc); if (!c) { retirer(pc); return; }
  const sig = actif.id + (c.dos ? '|dos' : '|' + c.rang + c.ens);
  let o = calque(pc);
  if (o && o.getAttribute('data-sig') === sig) { if (pc.getAttribute('data-skin') !== actif.id) pc.setAttribute('data-skin', actif.id); return; }
  if (!o) { o = document.createElement('span'); o.setAttribute('aria-hidden', 'true'); pc.insertBefore(o, pc.firstChild); if (io) io.observe(o); }
  o.className = 'pc-skin hsc-fige' + (c.dos ? ' hsc-dos' : ' hsc-face');
  o.setAttribute('data-sig', sig);
  o.innerHTML = c.dos ? dessinerDos(actif) : dessinerRecto(actif, c.rang, c.ens);
  pc.setAttribute('data-skin', actif.id);
  planifier();
}
const toutes = () => document.querySelectorAll('.pc');

// --- suivi de l'écran : cartes qui arrivent, qui se retournent ou qui changent ---
const aFaire = new Set();
const mo = typeof MutationObserver === 'function' ? new MutationObserver((recs) => {
  if (!actif) return;
  for (const r of recs) {
    const t = r.target;
    if (t.nodeType !== 1 || (t.closest && t.closest('.pc-skin'))) continue;
    if (r.type === 'attributes') { if (t.classList.contains('pc')) aFaire.add(t); continue; }
    if (t.classList.contains('pc')) aFaire.add(t);
    for (const n of r.addedNodes) {
      if (n.nodeType !== 1 || n.classList.contains('pc-skin')) continue;
      if (n.classList.contains('pc')) aFaire.add(n);
      if (n.firstElementChild) n.querySelectorAll('.pc').forEach((x) => aFaire.add(x));
    }
  }
  aFaire.forEach((pc) => { if (pc.isConnected) habiller(pc); });
  aFaire.clear();
}) : null;
function suivre(oui) {
  if (!mo || oui === observe) return; observe = oui;
  if (oui) mo.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['aria-label'] });
  else { mo.disconnect(); aFaire.clear(); }
}

// --- ce que voit le reste de l'appli (compte.js) ---
function activer(id) {
  const s = (id && PAR_ID.get(id)) || null;
  if ((s && s.id) === (actif && actif.id)) return !!s;
  actif = s;
  if (s) {
    poserStyles();
    document.documentElement.style.setProperty('--hs-dos-fixe', dosFixe(s));
    toutes().forEach(habiller); suivre(true); planifier();
  } else {
    suivre(false); toutes().forEach(retirer);
    document.documentElement.style.removeProperty('--hs-dos-fixe');
  }
  return !!s;
}
if (reduit.addEventListener) reduit.addEventListener('change', planifier);
document.addEventListener('visibilitychange', planifier);
window.addEventListener('resize', planifier, { passive: true });

window.HS_CARTES = {
  liste,
  // un dessin à poser dans une page : dos ou face (rang : A, 2 à 10, V, D, R ; enseigne : S, H, D, C)
  dos: (id) => { poserStyles(); const s = PAR_ID.get(id); return s ? dessinerDos(s) : ''; },
  recto: (id, rang, ens) => { poserStyles(); const s = PAR_ID.get(id); return s ? dessinerRecto(s, rang, ens) : ''; },
  activer,
  actif: () => (actif ? actif.id : null),
  animer: (oui) => { animations = !!oui; planifier(); },
  budget: () => budget,
};
window.dispatchEvent(new Event('hs-cartes-pret'));
