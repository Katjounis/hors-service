// Planches de comparaison pour le dossier APERCUS : pour chaque skin, dos, roi, dame, valet, as, 10 et 7.
import { writeFileSync, mkdirSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { SKINS } from './skins/index.mjs';
import { dos, recto, CSS_CARTE, CSS_ANIME } from './kit/carte.mjs';
import { CSS_FIGURES } from './kit/figures.mjs';
import { CSS_DESSIN } from './kit/dessin.mjs';
const OUT = new URL('./apercus/', import.meta.url).pathname; mkdirSync(OUT, { recursive: true });
const groupes = [['legendaires', 'Légendaire', 0, 5], ['epiques', 'Épique', 0, 10], ['rares-1', 'Rare', 0, 15], ['rares-2', 'Rare', 15, 30], ['communes-1', 'Commune', 0, 14], ['communes-2', 'Commune', 14, 28], ['communes-3', 'Commune', 28, 42], ['communes-4', 'Commune', 42, 55]];
const css = `body{margin:0;background:#1B4332;color:#f2eadb;font:13px system-ui;padding:14px 14px 4px}h1{font:700 20px system-ui;margin:0 0 10px}.l{display:grid;grid-template-columns:150px repeat(7,120px);gap:8px;align-items:center;margin-bottom:10px}.l svg{width:120px;height:168px;display:block;border-radius:10px;box-shadow:0 0 0 1px #000}.t b{display:block;font-size:14px}.t i{color:#a99f8c;font-style:normal}${CSS_CARTE}${CSS_ANIME}${CSS_FIGURES}${CSS_DESSIN}${SKINS.map((s) => s.css || '').join('\n')}`;
for (const [nom, r, a, b] of groupes) {
  const l = SKINS.filter((s) => s.rarete === r).slice(a, b);
  const html = `<!doctype html><meta charset="utf-8"><style>${css}</style><h1>Hors Service · skins ${r.toLowerCase()}s ${a + 1} à ${Math.min(b, a + l.length)} · dos, roi, dame, valet, as, 10, 7</h1>${l.map((s) => `<div class="l"><div class="t"><b>${s.id} ${s.nom}</b><i>${s.famille}${s.ancien !== s.id ? ' · ex ' + s.ancien : ''}</i></div>${dos(s)}${recto(s, 'R', 'S')}${recto(s, 'D', 'H')}${recto(s, 'V', 'C')}${recto(s, 'A', 'D')}${recto(s, '10', 'H')}${recto(s, '7', 'S')}</div>`).join('')}`;
  writeFileSync('planche-tmp.html', html);
  execFileSync('node', ['capture.mjs', 'planche-tmp.html', OUT + nom + '.png', '1200', '2300', '1.5'], { stdio: 'ignore' });
  execFileSync('python3', ['-c', `from PIL import Image\nim = Image.open(${JSON.stringify(OUT + nom + '.png')}).convert('RGB')\nim.save(${JSON.stringify(OUT + 'planche-' + nom + '.jpg')}, 'JPEG', quality=84, optimize=True, progressive=True)`]);
}
console.log('planches faites');
