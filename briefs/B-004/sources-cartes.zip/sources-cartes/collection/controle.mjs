// Contrôles de la collection : 100 skins, 5/10/30/55, identifiants, clés, noms et palettes uniques, pas de tiret long, pas d'erreur de dessin.
import { SKINS } from './skins/index.mjs';
import { dos, recto } from './kit/carte.mjs';
import { COMMUNES, RARES, EPIQUES, LEGENDAIRES } from '../catalogue/concepts.mjs';
const par = (r) => SKINS.filter((s) => s.rarete === r).length;
const doublons = (f) => { const vus = new Map(); for (const s of SKINS) { const k = f(s); vus.set(k, (vus.get(k) || 0) + 1); } return [...vus].filter(([, v]) => v > 1).map(([k]) => k); };
const erreurs = [];
if (SKINS.length !== 100) erreurs.push('nombre ' + SKINS.length);
const att = { 'Légendaire': 5, 'Épique': 10, 'Rare': 30, 'Commune': 55 }; for (const [r, v] of Object.entries(att)) if (par(r) !== v) erreurs.push(`${r} ${par(r)} au lieu de ${v}`);
for (const [nom, f] of [['id', (s) => s.id], ['clé', (s) => s.cle], ['nom', (s) => s.nom], ['palette', (s) => (s.couleurs || []).join(',')], ['ancien', (s) => s.ancien]]) { const d = doublons(f); if (d.length) erreurs.push(`${nom} en double : ${d.join(', ')}`); }
for (const s of SKINS) { const pre = { 'Légendaire': 'L', 'Épique': 'E', 'Rare': 'R', 'Commune': 'C' }[s.rarete]; if (!s.id.startsWith(pre + '-')) erreurs.push(`${s.id} ne correspond pas à ${s.rarete}`); if (!s.cle.startsWith(s.id.toLowerCase().replace('-', ''))) erreurs.push(`clé ${s.cle} / ${s.id}`); if (!s.couleurs || s.couleurs.length !== 3) erreurs.push(`${s.id} couleurs`); }
const anciens = new Set([...COMMUNES, ...RARES, ...EPIQUES, ...LEGENDAIRES].map((c) => c[0])); for (const s of SKINS) if (!anciens.has(s.ancien)) erreurs.push(`${s.id} : ancien ${s.ancien} absent des concepts`);
let taille = 0; for (const s of SKINS) { try { const t = dos(s) + recto(s, 'R', 'S') + recto(s, 'D', 'H') + recto(s, 'V', 'C') + recto(s, 'A', 'D') + recto(s, '10', 'H') + recto(s, '7', 'S') + recto(s, '2', 'C') + recto(s, '9', 'D'); taille += t.length; if (/undefined|NaN/.test(t)) erreurs.push(`${s.id} : « undefined » ou « NaN » dans le dessin`); if (t.includes('—') || (s.bouge || '').includes('—') || s.nom.includes('—')) erreurs.push(`${s.id} : tiret long`); } catch (e) { erreurs.push(`${s.id} : ${e.message}`); } }
// charte du Drive : pas de dégradés (ni dans les dessins ni dans les styles), pas de filtres (lourds pour les téléphones)
const RANGS = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'V', 'D', 'R'], ENS = ['S', 'H', 'D', 'C'];
for (const s of SKINS) {
  const tout = [dos(s), ...RANGS.flatMap((r) => ENS.map((e) => recto(s, r, e)))].join('');
  if (/<(linear|radial)Gradient|url\(#[^)]*\)/.test(tout.replace(/(clip-path|mask)="url\(#[^)]*\)"/g, '').replace(/fill="url\(#[^)]*\)"/g, (m) => m))) {
    const g = (tout.match(/<(linear|radial)Gradient/g) || []).length; if (g) erreurs.push(`${s.id} : ${g} dégradé(s) dans le dessin`);
  }
  if (/\bfilter="/.test(tout) || /<filter\b/.test(tout)) erreurs.push(`${s.id} : filtre SVG`);
  for (const svg of [dos(s), ...RANGS.flatMap((r) => ENS.map((e) => recto(s, r, e)))]) { const ids = new Set([...svg.matchAll(/id="([^"]+)"/g)].map((m) => m[1])); const perdue = [...svg.matchAll(/url\(#([^)]+)\)/g)].find((m) => !ids.has(m[1])); if (perdue) { erreurs.push(`${s.id} : référence sans cible ${perdue[1]}`); break; } }
  if (/gradient\(/.test(s.css || '')) erreurs.push(`${s.id} : dégradé dans le style`);
}
console.log(`${SKINS.length} skins : ${Object.keys(att).map((r) => `${par(r)} ${r.toLowerCase()}s`).join(', ')} ; ${Math.round(taille / 1024)} Ko de SVG pour 9 cartes par skin`);
console.log(erreurs.length ? 'ERREURS\n' + erreurs.join('\n') : 'tout est conforme');
