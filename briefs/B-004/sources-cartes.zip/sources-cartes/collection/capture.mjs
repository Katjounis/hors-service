// node capture.mjs <page.html> <sortie.png> [largeur] [ms figé] [dpr]
import { createRequire } from 'node:module';
const { chromium } = createRequire(import.meta.url)('playwright');
const [page, sortie, largeur = '1000', ms = '1200', dpr = '1.5'] = process.argv.slice(2);
const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: Number(largeur), height: 600 }, deviceScaleFactor: Number(dpr) }); const p = await c.newPage();
const errs = []; p.on('pageerror', (e) => errs.push(e.message)); p.on('console', (m) => { if (m.type() === 'error') errs.push(m.text()); });
await p.goto('file://' + new URL(page, 'file://' + process.cwd() + '/').pathname); await p.waitForTimeout(400);
await p.evaluate((t) => { for (const a of document.getAnimations()) { try { a.pause(); a.currentTime = t; } catch (e) {} } }, Number(ms));
await p.waitForTimeout(150); await p.screenshot({ path: sortie, fullPage: true });
console.log(sortie, errs.length ? errs.slice(0, 3) : 'aucune erreur'); await b.close();
