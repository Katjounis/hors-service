// Films pour le dossier ANIMATIONS : pour chaque skin, une bande dos + roi + dame + valet + as, 5 secondes, image par image (fluide quelle que soit la machine).
import { tmpdir } from 'node:os';
// node film-collection.mjs <rareté> <sortie.mp4> [secondes par skin]
import { mkdirSync, rmSync, writeFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { createRequire } from 'node:module';
import { SKINS } from './skins/index.mjs';
import { dos, recto, CSS_CARTE, CSS_ANIME } from './kit/carte.mjs';
import { CSS_FIGURES } from './kit/figures.mjs';
import { CSS_DESSIN } from './kit/dessin.mjs';
const { chromium } = createRequire(import.meta.url)('playwright');
const [rarete, sortie, sec = '5'] = process.argv.slice(2);
const IPS = 20, N = Math.round(Number(sec) * IPS), TMP = tmpdir() + '/hs-film-' + rarete.normalize('NFD').replace(/[̀-ͯ]/g, '');
rmSync(TMP, { recursive: true, force: true }); mkdirSync(TMP, { recursive: true });
const liste = SKINS.filter((s) => s.rarete === rarete);
const css = `body{margin:0;background:#1B4332;color:#f2eadb;font:600 15px system-ui}#z{width:960px;padding:12px 16px 16px}#t{height:26px;display:flex;gap:10px;align-items:baseline}#t b{font:400 19px 'Georgia',serif}#t i{color:#a99f8c;font-style:normal;font-size:13px}#c{display:flex;gap:12px}#c svg{width:176px;height:246px;display:block;border-radius:12px;box-shadow:0 0 0 1px #000,0 6px 14px rgba(0,0,0,.5)}${CSS_CARTE}${CSS_ANIME}${CSS_FIGURES}${CSS_DESSIN}${liste.map((s) => s.css || '').join('\n')}`;
const b = await chromium.launch(); const p = await (await b.newContext({ viewport: { width: 960, height: 310 }, deviceScaleFactor: 1 })).newPage();
await p.setContent(`<!doctype html><meta charset="utf-8"><style>${css}</style><div id="z"><div id="t"></div><div id="c"></div></div>`);
let k = 0;
for (const s of liste) {
  await p.evaluate(([t, h]) => { document.getElementById('t').innerHTML = t; document.getElementById('c').innerHTML = h; }, [`<b>${s.id} · ${s.nom}</b><i>${s.rarete} · ${s.famille}</i>`, dos(s) + recto(s, 'R', 'S') + recto(s, 'D', 'H') + recto(s, 'V', 'C') + recto(s, 'A', 'D')]);
  await p.waitForTimeout(80);
  for (let f = 0; f < N; f++) {
    await p.evaluate((t) => { for (const a of document.getAnimations()) { try { a.pause(); a.currentTime = t; } catch (e) {} } }, 400 + f * (1000 / IPS));
    await p.screenshot({ path: `${TMP}/i${String(k++).padStart(5, '0')}.jpg`, type: 'jpeg', quality: 90 });
  }
}
await b.close();
execFileSync('ffmpeg', ['-y', '-loglevel', 'error', '-framerate', String(IPS), '-i', `${TMP}/i%05d.jpg`, '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-crf', '27', '-preset', 'slow', '-movflags', '+faststart', sortie]);
rmSync(TMP, { recursive: true, force: true });
console.log(sortie, liste.length, 'skins,', k, 'images');
