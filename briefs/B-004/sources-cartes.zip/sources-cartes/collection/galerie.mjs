// Construit la galerie des 100 skins : un seul fichier HTML, le code de dessin est embarqué et dessine les cartes à la demande.
import { readFileSync, writeFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
const ICI = new URL('./', import.meta.url).pathname;
const sortie = process.argv[2] || ICI + 'galerie-100-skins.html';
execFileSync('esbuild', [ICI + 'client.mjs', '--bundle', '--format=iife', '--minify', '--target=es2020', '--outfile=' + ICI + 'client.bundle.js'], { stdio: 'inherit' });
const js = readFileSync(ICI + 'client.bundle.js', 'utf8');
const police = readFileSync(ICI + '../premier-jet/police-alfa.css', 'utf8');
const css = `${police}
:root { color-scheme: dark; --fond: #1B4332; --carte: #163829; --bord: #2D6A4F; --texte: #F2EADB; --doux: #B5C7B3; }
* { box-sizing: border-box; }
html { background: var(--fond); overflow-x: clip; }
body { margin: 0; background: var(--fond); color: var(--texte); font: 16px/1.5 system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif; -webkit-font-smoothing: antialiased; }
body.ouverte { overflow: hidden; }
main { max-width: 1180px; margin: 0 auto; padding: 22px 16px 60px; }
h1 { font: 400 clamp(1.7rem, 6vw, 2.6rem)/1.05 'Alfa Slab One', Georgia, serif; margin: 0 0 8px; text-wrap: balance; }
.chapo { margin: 0 0 12px; color: #CFC4AE; max-width: 70ch; }
.echelle { display: grid; grid-template-columns: repeat(auto-fit, minmax(210px, 1fr)); gap: 8px; margin: 0 0 16px; padding: 0; list-style: none; }
.echelle li { padding: 10px 12px; border-radius: 10px; background: var(--carte); border: 1px solid var(--bord); font-size: .88rem; color: #CFC4AE; }
.echelle b { display: block; font-size: .74rem; letter-spacing: .1em; text-transform: uppercase; }
.barre { position: sticky; top: 0; z-index: 5; display: flex; flex-wrap: wrap; gap: 8px; padding: 10px 0; background: var(--fond); border-bottom: 1px solid var(--bord); }
.barre button { min-height: 44px; padding: 0 14px; border: 1px solid #4A453E; border-radius: 22px; background: #1F1B18; color: inherit; font: 600 .92rem system-ui, sans-serif; cursor: pointer; }
.barre button b { font-weight: 700; margin-left: 4px; color: var(--doux); }
.barre button[aria-pressed="true"] { background: #F2EADB; color: #1C1915; border-color: #F2EADB; } .barre button[aria-pressed="true"] b { color: #6b6253; }
#calme { margin-left: auto; }
.r-3 { --rc: #E8C24A; } .r-2 { --rc: #C99BFF; } .r-1 { --rc: #8DBBFF; } .r-0 { --rc: #B9B1A3; }
#grille { display: grid; grid-template-columns: repeat(auto-fill, minmax(148px, 1fr)); gap: 16px 12px; }
.vignette { display: grid; gap: 4px; padding: 8px; border: 1px solid var(--bord); border-radius: 12px; background: var(--carte); color: inherit; text-align: left; cursor: pointer; font: inherit; -webkit-tap-highlight-color: transparent; }
.vignette:hover, .vignette:focus-visible { border-color: var(--rc); outline: none; box-shadow: 0 0 0 2px var(--rc); }
.vignette.r-3 { background: #2B3B1E; border-color: rgba(232, 194, 74, .7); }
.vignette.r-2 { background: #22303A; border-color: rgba(201, 155, 255, .6); }
.vignette.r-1 { border-color: rgba(141, 187, 255, .35); }
.v-carte { display: block; aspect-ratio: 5 / 7; border-radius: 8.8% / 6.3%; overflow: hidden; background: #26211c; box-shadow: 0 6px 16px rgba(0, 0, 0, .45); }
.v-carte svg { display: block; width: 100%; height: 100%; }
.v-nom { font-weight: 700; font-size: .92rem; line-height: 1.2; margin-top: 4px; }
.v-id { font: 500 .74rem ui-monospace, Menlo, monospace; color: var(--rc); } .v-id i { color: var(--doux); font-style: normal; }
/* visionneuse */
#visionneuse { width: min(1100px, 100vw); max-width: 100vw; max-height: 100dvh; height: 100dvh; margin: 0 auto; padding: 0; border: 0; background: transparent; color: var(--texte); }
#visionneuse::backdrop { background: rgba(8, 7, 6, .86); }
.v-cadre { position: relative; min-height: 100%; padding: 56px 16px 32px; background: #181512; border-left: 1px solid var(--bord); border-right: 1px solid var(--bord); overflow-y: auto; height: 100%; }
.v-nav { position: absolute; top: 8px; left: 8px; right: 8px; display: flex; gap: 8px; z-index: 3; }
.v-nav button { min-width: 44px; min-height: 44px; padding: 0 12px; border-radius: 22px; border: 1px solid #4A453E; background: #1F1B18; color: inherit; font: 600 .9rem system-ui, sans-serif; cursor: pointer; }
#v-fermer { margin-left: auto; }
#v-contenu { display: grid; grid-template-columns: 340px minmax(0, 1fr); gap: 26px; }
.v-scene { display: grid; justify-items: center; align-content: start; gap: 14px; padding-top: 18px; }
.touche { margin: 0; font-size: .8rem; color: #8F8676; text-align: center; }
@media (hover: none) { .souris { display: none; } }
.v-rarete { margin: 0; font: 700 .76rem/1 system-ui, sans-serif; letter-spacing: .12em; text-transform: uppercase; color: var(--rc); }
#v-titre { font: 400 1.7rem/1.1 'Alfa Slab One', Georgia, serif; margin: 6px 0 2px; }
.v-ident { margin: 0 0 12px; font: 500 .8rem ui-monospace, Menlo, monospace; color: #8F8676; }
.v-minis { display: flex; flex-wrap: wrap; gap: 8px; margin: 0 0 12px; }
.mini { width: 78px; padding: 0; border: 0; background: none; color: inherit; cursor: pointer; display: grid; gap: 3px; justify-items: center; -webkit-tap-highlight-color: transparent; }
.mini .face, .petite .face { position: relative; display: block; width: 100%; aspect-ratio: 5 / 7; border-radius: 8.8% / 6.3%; overflow: hidden; box-shadow: 0 3px 8px rgba(0, 0, 0, .45), 0 0 0 1px rgba(0, 0, 0, .6); }
.mini svg, .petite svg { display: block; width: 100%; height: 100%; }
.mini-nom { font: 600 .72rem/1 system-ui, sans-serif; color: var(--doux); }
.mini[aria-pressed="true"] .face { box-shadow: 0 0 0 2px #F2EADB, 0 3px 8px rgba(0, 0, 0, .45); } .mini[aria-pressed="true"] .mini-nom { color: #F2EADB; }
dl { margin: 0 0 12px; } dt { font-weight: 700; font-size: .8rem; color: #CFC4AE; margin-top: 8px; } dd { margin: 0; font-size: .93rem; }
.couleurs { display: flex; flex-wrap: wrap; align-items: center; gap: 6px; } .pastille { width: 18px; height: 18px; border-radius: 5px; box-shadow: 0 0 0 1px rgba(255, 255, 255, .25); } .couleurs code { font-size: .78rem; color: var(--doux); margin-right: 6px; }
.reel { display: flex; flex-wrap: wrap; align-items: flex-end; gap: 10px; margin-top: 10px; padding-top: 10px; border-top: 1px dashed #3A342E; }
.reel-t { flex-basis: 100%; font: 700 .7rem/1.3 system-ui, sans-serif; letter-spacing: .06em; text-transform: uppercase; color: #8F8676; }
.petite { display: block; width: var(--l); }
/* la grande carte */
.bascule { position: relative; z-index: 0; display: block; width: min(300px, 72vw); aspect-ratio: 5 / 7; padding: 0; border: 0; background: none; perspective: 1100px; cursor: pointer; -webkit-tap-highlight-color: transparent; touch-action: manipulation; }
.bascule:focus-visible { outline: 3px solid #FFD23F; outline-offset: 8px; border-radius: 12px; }
.r-3 .bascule::before, .r-2 .bascule::before { content: ''; position: absolute; z-index: -1; inset: -12% -22%; background: var(--c1); clip-path: polygon(50.0% 0.0%, 56.6% 16.7%, 69.1% 3.8%, 68.9% 21.7%, 85.4% 14.6%, 78.3% 31.1%, 96.2% 30.9%, 83.3% 43.4%, 100.0% 50.0%, 83.3% 56.6%, 96.2% 69.1%, 78.3% 68.9%, 85.4% 85.4%, 68.9% 78.3%, 69.1% 96.2%, 56.6% 83.3%, 50.0% 100.0%, 43.4% 83.3%, 30.9% 96.2%, 31.1% 78.3%, 14.6% 85.4%, 21.7% 68.9%, 3.8% 69.1%, 16.7% 56.6%, 0.0% 50.0%, 16.7% 43.4%, 3.8% 30.9%, 21.7% 31.1%, 14.6% 14.6%, 31.1% 21.7%, 30.9% 3.8%, 43.4% 16.7%); opacity: .32; }
.r-3 .bascule::before { animation: aura 40s linear infinite; } .r-2 .bascule::before { opacity: .2; }
@keyframes aura { to { transform: rotate(360deg); } }
.flotte { position: absolute; inset: 0; display: block; transform-style: preserve-3d; }
.flottante .flotte { animation: flotte 7s ease-in-out infinite; }
@keyframes flotte { 0%, 100% { transform: translateY(0) rotateY(-6deg) rotateX(2deg); } 50% { transform: translateY(-7px) rotateY(6deg) rotateX(-2deg); } }
.bascule.penche .flotte { animation-play-state: paused; }
.carte { position: absolute; inset: 0; display: block; transform-style: preserve-3d; transform: rotateX(var(--rx, 0deg)) rotateY(calc(var(--ry, 0deg) + var(--tour, 0deg))); transition: transform .7s cubic-bezier(.3, .75, .3, 1); }
.bascule.vue { --tour: 180deg; } .bascule.penche .carte { transition: transform .12s linear; } .bascule.tourne .carte { transition: transform .7s cubic-bezier(.3, .75, .3, 1); }
.bascule .face { position: absolute; inset: 0; display: block; border-radius: 8.8% / 6.3%; overflow: hidden; backface-visibility: hidden; -webkit-backface-visibility: hidden; box-shadow: 0 10px 24px rgba(0, 0, 0, .5), 0 0 0 1px rgba(0, 0, 0, .6); }
.bascule .face svg { display: block; width: 100%; height: 100%; }
.bascule .recto { transform: rotateY(180deg); }
.penche .eclat { position: absolute; inset: 0; display: block; pointer-events: none; }
.eclat i { position: absolute; left: 50%; top: 50%; width: 11px; height: 11px; margin: -5.5px; opacity: 0; background: var(--c1); border-radius: 2px; }
.eclat i:nth-child(odd) { background: var(--c2); }
.joue .eclat i { animation: ec-part var(--t, .9s) cubic-bezier(.12, .7, .3, 1) both; animation-delay: var(--r, 0s); }
@keyframes ec-part { 0% { opacity: 0; transform: rotate(var(--a)) translateY(0) scale(.3); } 12% { opacity: 1; } 70% { opacity: 1; } 100% { opacity: 0; transform: rotate(var(--a)) translateY(calc(var(--d) * -1)) scale(var(--e, 1)) rotate(200deg); } }
.eclat .onde { position: absolute; left: 50%; top: 50%; width: 70%; aspect-ratio: 1; margin: -35% 0 0 -35%; border-radius: 50%; border: 3px solid var(--c1); opacity: 0; }
.eclat .onde.b { border-color: var(--c2); border-width: 2px; }
.joue .eclat .onde { animation: ec-onde .85s ease-out both; } .joue .eclat .onde.b { animation-delay: .14s; animation-duration: 1.05s; }
@keyframes ec-onde { 0% { opacity: .95; transform: scale(.15); } 100% { opacity: 0; transform: scale(2.7); } }
.eclat .rayons { position: absolute; inset: -30% -55%; opacity: 0; background: var(--c1); clip-path: polygon(50.0% 0.0%, 51.6% 38.1%, 62.9% 1.7%, 54.6% 38.9%, 75.0% 6.7%, 57.3% 40.5%, 85.4% 14.6%, 59.5% 42.7%, 93.3% 25.0%, 61.1% 45.4%, 98.3% 37.1%, 61.9% 48.4%, 100.0% 50.0%, 61.9% 51.6%, 98.3% 62.9%, 61.1% 54.6%, 93.3% 75.0%, 59.5% 57.3%, 85.4% 85.4%, 57.3% 59.5%, 75.0% 93.3%, 54.6% 61.1%, 62.9% 98.3%, 51.6% 61.9%, 50.0% 100.0%, 48.4% 61.9%, 37.1% 98.3%, 45.4% 61.1%, 25.0% 93.3%, 42.7% 59.5%, 14.6% 85.4%, 40.5% 57.3%, 6.7% 75.0%, 38.9% 54.6%, 1.7% 62.9%, 38.1% 51.6%, 0.0% 50.0%, 38.1% 48.4%, 1.7% 37.1%, 38.9% 45.4%, 6.7% 25.0%, 40.5% 42.7%, 14.6% 14.6%, 42.7% 40.5%, 25.0% 6.7%, 45.4% 38.9%, 37.1% 1.7%, 48.4% 38.1%); }
.joue .eclat .rayons { position: absolute; inset: -30% -55%; opacity: 0; background: var(--c1); clip-path: polygon(50.0% 0.0%, 51.6% 38.1%, 62.9% 1.7%, 54.6% 38.9%, 75.0% 6.7%, 57.3% 40.5%, 85.4% 14.6%, 59.5% 42.7%, 93.3% 25.0%, 61.1% 45.4%, 98.3% 37.1%, 61.9% 48.4%, 100.0% 50.0%, 61.9% 51.6%, 98.3% 62.9%, 61.1% 54.6%, 93.3% 75.0%, 59.5% 57.3%, 85.4% 85.4%, 57.3% 59.5%, 75.0% 93.3%, 54.6% 61.1%, 62.9% 98.3%, 51.6% 61.9%, 50.0% 100.0%, 48.4% 61.9%, 37.1% 98.3%, 45.4% 61.1%, 25.0% 93.3%, 42.7% 59.5%, 14.6% 85.4%, 40.5% 57.3%, 6.7% 75.0%, 38.9% 54.6%, 1.7% 62.9%, 38.1% 51.6%, 0.0% 50.0%, 38.1% 48.4%, 1.7% 37.1%, 38.9% 45.4%, 6.7% 25.0%, 40.5% 42.7%, 14.6% 14.6%, 42.7% 40.5%, 25.0% 6.7%, 45.4% 38.9%, 37.1% 1.7%, 48.4% 38.1%); }
@keyframes ec-rayons { 0% { opacity: 0; transform: scale(.4) rotate(0deg); } 22% { opacity: .85; } 100% { opacity: 0; transform: scale(1.15) rotate(50deg); } }
.r-0 .joue .carte, .r-1 .joue .carte { animation: rebond .45s cubic-bezier(.3, 1.6, .5, 1); }
@keyframes rebond { 0% { scale: .92; } 100% { scale: 1; } }
@keyframes fx-flash { 0% { opacity: 0; transform: scale(.5); } 35% { opacity: 1; } 100% { opacity: 0; transform: scale(1.25); } }
@keyframes fx-secousse { 0%, 100% { transform: translate(0, 0); } 15% { transform: translate(-6px, 2px) rotate(-1.4deg); } 30% { transform: translate(6px, -2px) rotate(1.4deg); } 45% { transform: translate(-5px, -1px); } 60% { transform: translate(5px, 1px); } 80% { transform: translate(-2px, 0); } }
.effet { position: absolute; inset: -14%; display: block; border-radius: 50%; opacity: 0; pointer-events: none; }
@media (max-width: 760px) { #v-contenu { grid-template-columns: minmax(0, 1fr); } #grille { grid-template-columns: repeat(2, minmax(0, 1fr)); } .mini { width: calc((100% - 24px) / 4); } }
/* économie : ce qu'on ne voit pas ne s'anime pas */
.dort svg *, .ouverte #grille svg * { animation: none !important; }
/* dans la grille, les épiques et légendaires s'animent deux par deux, à tour de rôle (ou sous la souris) ; tout s'anime dans la visionneuse */
.vignette.r-3:not(:hover):not(:focus-visible):not(.vedette) svg *, .vignette.r-2:not(:hover):not(:focus-visible):not(.vedette) svg * { animation: none !important; }
.bascule:not(.vue) .recto svg *, .bascule.vue .dos svg * { animation: none !important; }
.mini:not(.tourne):not(:hover) svg *, .petite:not(:hover) svg * { animation: none !important; }
.calme svg *, .calme .eclat *, .calme .bascule, .calme .flotte, .calme .bascule::before { animation: none !important; }
@media (prefers-reduced-motion: reduce) { svg *, .eclat *, .bascule, .flotte, .bascule::before { animation: none !important; } .carte { transition: none; } }
`;
const html = `<!doctype html>
<html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Hors Service, les 100 skins de cartes</title>
<style>${css}</style></head>
<body><main>
<h1>Les 100 skins de cartes</h1>
<p class="chapo">5 légendaires, 10 épiques, 30 rares, 55 communes. Touche un skin pour le voir en grand, le retourner et passer d'une carte à l'autre : roi, dame, valet, as et chiffres. Les valeurs et les enseignes restent à la place et à la taille de l'appli. Version à la charte du Drive : aplats, encre et trames, sans dégradés. Dans B-004, ces cartes se choisissent dans l'appli (Mon compte, Ma collection) ; rien n'est publié tant que Bit et Samuel ne l'ont pas décidé.</p>
<ul class="echelle"><li class="r-3"><b style="color:#B9B1A3">Commune</b>Dos dessiné, un reflet passe de temps en temps. Recto fixe, personnages propres au skin.</li><li class="r-2"><b style="color:#8DBBFF">Rare</b>Le dos s'anime (une ou deux choses). Les figures clignent des yeux, l'as respire. Petite gerbe au retournement.</li><li class="r-1"><b style="color:#C99BFF">Épique</b>Dos animé en plusieurs couches. Figures qui respirent et bougent, enseignes animées. Gerbe et rayons.</li><li class="r-0"><b style="color:#E8C24A">Légendaire</b>Tout bouge, recto compris, décor animé derrière les figures, carte qui flotte. Grande gerbe.</li></ul>
<div class="barre" role="toolbar" aria-label="Filtrer par rareté"><button type="button" class="filtre" aria-pressed="true">Tous <b>100</b></button><button type="button" class="filtre" data-r="Légendaire" aria-pressed="false">Légendaires <b></b></button><button type="button" class="filtre" data-r="Épique" aria-pressed="false">Épiques <b></b></button><button type="button" class="filtre" data-r="Rare" aria-pressed="false">Rares <b></b></button><button type="button" class="filtre" data-r="Commune" aria-pressed="false">Communes <b></b></button><button type="button" id="calme" aria-pressed="false">Animations réduites</button></div>
<div id="grille"></div>
</main>
<dialog id="visionneuse" aria-labelledby="v-titre"><div class="v-cadre"><div class="v-nav"><button type="button" id="v-avant" aria-label="Skin précédent">‹ Précédent</button><button type="button" id="v-apres" aria-label="Skin suivant">Suivant ›</button><button type="button" id="v-fermer" aria-label="Fermer">Fermer ✕</button></div><div id="v-contenu"></div></div></dialog>
<script>${js}</script></body></html>`;
writeFileSync(sortie, html);
console.log(`${Buffer.byteLength(html)} octets → ${sortie}`);
