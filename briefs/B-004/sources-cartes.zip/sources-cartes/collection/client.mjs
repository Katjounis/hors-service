// La galerie dans le navigateur : les cartes sont dessinées à la demande (seulement celles qu'on voit), à partir du même code que les SVG livrés.
import { SKINS } from './skins/index.mjs';
import { dos, recto, NOMS_RANGS, NIVEAU, CSS_CARTE, CSS_ANIME } from './kit/carte.mjs';
import { CSS_FIGURES } from './kit/figures.mjs';
import { CSS_DESSIN } from './kit/dessin.mjs';
import { NOM_ENSEIGNE } from './kit/base.mjs';
const st = document.createElement('style'); st.textContent = CSS_CARTE + CSS_ANIME + CSS_FIGURES + CSS_DESSIN + SKINS.map((s) => s.css || '').join('\n'); document.head.append(st);
const $ = (q, r = document) => r.querySelector(q), $$ = (q, r = document) => [...r.querySelectorAll(q)];
const echap = (t) => String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;');
const NIV = (s) => NIVEAU[s.rarete];
const COMPTE = { 'Légendaire': 0, 'Épique': 0, 'Rare': 0, 'Commune': 0 }; SKINS.forEach((s) => COMPTE[s.rarete]++);
// --- la grille ---
const grille = $('#grille');
grille.innerHTML = SKINS.map((s, i) => `<button type="button" class="vignette r-${NIV(s)}" data-i="${i}" data-rarete="${s.rarete}" aria-label="${echap(s.nom)}, ${s.rarete}, ${s.id}"><span class="v-carte"></span><span class="v-nom">${echap(s.nom)}</span><span class="v-id">${s.id}${s.ancien && s.ancien !== s.id ? ` <i>ex ${s.ancien}</i>` : ''}</span></button>`).join('');
$$('.filtre').forEach((b) => { const r = b.dataset.r; if (r) b.querySelector('b').textContent = COMPTE[r]; b.addEventListener('click', () => { $$('.filtre').forEach((x) => x.setAttribute('aria-pressed', x === b ? 'true' : 'false')); grille.dataset.filtre = r || ''; $$('.vignette', grille).forEach((v) => { v.hidden = !!r && v.dataset.rarete !== r; }); }); });
const io = 'IntersectionObserver' in window ? new IntersectionObserver((es) => es.forEach((e) => { const v = e.target; if (e.isIntersecting && !v.dataset.pret) { v.querySelector('.v-carte').innerHTML = dos(SKINS[v.dataset.i]); v.dataset.pret = '1'; } v.classList.toggle('dort', !e.isIntersecting); }), { rootMargin: '300px 0px' }) : null;
$$('.vignette', grille).forEach((v) => { if (io) io.observe(v); else { v.querySelector('.v-carte').innerHTML = dos(SKINS[v.dataset.i]); } v.addEventListener('click', () => ouvrir(Number(v.dataset.i))); });
// les vignettes riches s'animent deux à la fois, à tour de rôle, parmi celles qu'on voit
let rang = 0; setInterval(() => { const l = $$('.vignette.r-3:not(.dort):not([hidden]), .vignette.r-2:not(.dort):not([hidden])', grille); $$('.vedette', grille).forEach((v) => v.classList.remove('vedette')); if (!l.length || document.body.classList.contains('calme')) return; for (let k = 0; k < Math.min(2, l.length); k++) l[(rang + k) % l.length].classList.add('vedette'); rang = (rang + 2) % l.length; }, 2600);
// --- la visionneuse ---
const vis = $('#visionneuse'); let courant = 0;
const FAMILLE = [['R', 'S'], ['D', 'H'], ['V', 'C'], ['A', 'D'], ['10', 'H'], ['7', 'S'], ['5', 'C'], ['2', 'D']];
function gerbe(s) {
  const nb = s.gerbe ?? [0, 8, 14, 22][NIV(s)]; let x = 7; const h = () => { x = (x * 16807) % 2147483647; return x / 2147483647; };
  return `<span class="eclat">${nb ? `${NIV(s) >= 2 ? '<span class="rayons"></span>' : ''}<span class="onde"></span>${NIV(s) >= 2 ? '<span class="onde b"></span>' : ''}` : ''}${Array.from({ length: nb }, (_, i) => `<i style="--a:${Math.round((i / nb) * 360 + h() * 14)}deg;--d:${Math.round(100 + h() * 120)}px;--t:${(.8 + h() * .7).toFixed(2)}s;--r:${(h() * .18).toFixed(2)}s;--e:${(.5 + h() * .9).toFixed(2)}"></i>`).join('')}</span>`;
}
function ouvrir(i) {
  courant = (i + SKINS.length) % SKINS.length; const s = SKINS[courant], niv = NIV(s);
  const sw = (s.couleurs || []).map((c) => `<span class="pastille" style="background:${c}" title="${c}"></span><code>${c}</code>`).join('');
  $('#v-contenu').innerHTML = `<div class="v-scene r-${niv}" style="--c1:${(s.aura || s.couleurs)[0]};--c2:${(s.aura || s.couleurs)[1]}">
    <button type="button" class="bascule${niv === 3 ? ' flottante' : ''}" aria-label="Retourner la carte"><span class="flotte"><span class="carte"><span class="face dos">${dos(s)}</span><span class="face recto">${recto(s, 'R', 'S')}</span></span></span>${gerbe(s)}</button>
    <p class="touche">Touche la carte pour la retourner<span class="souris">, passe la souris pour l'incliner</span>.</p></div>
  <div class="v-infos"><p class="v-rarete r-${niv}">${s.rarete}</p><h2 id="v-titre">${echap(s.nom)}</h2><p class="v-ident">${s.id} · ${s.cle}${s.ancien && s.ancien !== s.id ? ` · ancien ${s.ancien}` : ''} · ${echap(s.famille || '')}</p>
    <div class="v-minis">${FAMILLE.map(([r, e], k) => `<button type="button" class="mini" data-r="${r}" data-e="${e}" aria-pressed="${k ? 'false' : 'true'}" aria-label="Voir en grand : ${NOMS_RANGS[r] || r} de ${NOM_ENSEIGNE[e]}"><span class="face">${recto(s, r, e)}</span><span class="mini-nom">${NOMS_RANGS[r] || r}</span></button>`).join('')}</div>
    <dl><dt>Ce qui bouge</dt><dd>${echap(s.bouge || '')}</dd><dt>Au retournement</dt><dd>${echap(s.retournement || '')}</dd>${s.descDos ? `<dt>Le dos</dt><dd>${echap(s.descDos)}</dd>` : ''}${s.descRecto ? `<dt>Le recto</dt><dd>${echap(s.descRecto)}</dd>` : ''}<dt>Couleurs</dt><dd class="couleurs">${sw}</dd><dt>Animations</dt><dd id="v-anims">…</dd></dl>
    <div class="reel"><span class="reel-t">Taille réelle en jeu : 64 px et 34 px de large (à 34 px les animations sont coupées)</span>${['dos', 'R S', '10 H'].map((q) => `<span class="petite" style="--l:64px"><span class="face">${q === 'dos' ? dos(s) : recto(s, ...q.split(' '))}</span></span>`).join('')}<span class="petite fige" style="--l:34px"><span class="face">${dos(s)}</span></span><span class="petite fige" style="--l:34px"><span class="face">${recto(s, '7', 'S')}</span></span></div></div>`;
  brancher(s); if (!vis.open) { vis.showModal ? vis.showModal() : vis.setAttribute('open', ''); document.body.classList.add('ouverte'); }
  history.replaceState(null, '', '#' + s.cle);
  requestAnimationFrame(() => setTimeout(() => { const n1 = $('.v-scene .dos svg').getAnimations({ subtree: true }).length; $('#v-anims').textContent = `${n1} animation${n1 > 1 ? 's' : ''} sur le dos, ${s.figures ? `figures au niveau ${s.figures.anim} sur 3` : 'figures faites main'}.`; }, 60));
}
function brancher(s) {
  const b = $('.bascule', vis); let t1, t2;
  b.montrer = (vue) => { b.classList.toggle('vue', vue); b.classList.add('tourne'); clearTimeout(t1); t1 = setTimeout(() => b.classList.remove('tourne'), 720); b.classList.remove('joue'); if (vue) { void b.offsetWidth; b.classList.add('joue'); clearTimeout(t2); t2 = setTimeout(() => b.classList.remove('joue'), 2000); } };
  b.addEventListener('click', () => b.montrer(!b.classList.contains('vue')));
  b.addEventListener('pointermove', (e) => { if (e.pointerType === 'touch' || document.body.classList.contains('calme')) return; const r = b.getBoundingClientRect(), x = (e.clientX - r.left) / r.width, y = (e.clientY - r.top) / r.height; b.style.setProperty('--ry', ((x - .5) * 26).toFixed(1) + 'deg'); b.style.setProperty('--rx', ((.5 - y) * 20).toFixed(1) + 'deg'); b.style.setProperty('--gx', Math.round(x * 100) + '%'); b.style.setProperty('--gy', Math.round(y * 100) + '%'); b.classList.add('penche'); });
  b.addEventListener('pointerleave', () => { b.classList.remove('penche'); b.style.removeProperty('--rx'); b.style.removeProperty('--ry'); });
  $$('.mini', vis).forEach((m) => m.addEventListener('click', () => { $('.recto', b).firstElementChild.outerHTML = recto(s, m.dataset.r, m.dataset.e); $$('.mini', vis).forEach((x) => x.setAttribute('aria-pressed', x === m ? 'true' : 'false')); b.montrer(true); }));
}
const fermer = () => { if (vis.close) vis.close(); else vis.removeAttribute('open'); };
vis.addEventListener('close', () => { document.body.classList.remove('ouverte'); $('#v-contenu').innerHTML = ''; history.replaceState(null, '', location.pathname); });
$('#v-fermer').addEventListener('click', fermer); $('#v-avant').addEventListener('click', () => ouvrir(courant - 1)); $('#v-apres').addEventListener('click', () => ouvrir(courant + 1));
vis.addEventListener('click', (e) => { if (e.target === vis) fermer(); });
document.addEventListener('keydown', (e) => { if (!vis.open) return; if (e.key === 'ArrowRight') ouvrir(courant + 1); if (e.key === 'ArrowLeft') ouvrir(courant - 1); });
// petites cartes : une seule s'anime à la fois
let tour = 0; setInterval(() => { const ms = $$('.mini', vis); ms.forEach((m) => m.classList.remove('tourne')); if (!ms.length || document.body.classList.contains('calme')) return; tour = (tour + 1) % ms.length; ms[tour].classList.add('tourne'); }, 2400);
const calme = $('#calme'); calme.addEventListener('click', () => { const on = document.body.classList.toggle('calme'); calme.setAttribute('aria-pressed', on ? 'true' : 'false'); });
const h = decodeURIComponent(location.hash.slice(1)); if (h) { const i = SKINS.findIndex((s) => s.cle === h); if (i >= 0) ouvrir(i); }
