// Planche d'essai des effets (flammes, braises, éclairs, fumée, étincelles, bulles, pièces, pluie, vent).
import { writeFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { flammes, braises, eclair, fumee, etincelles, bulles, pieces, pluie, vent, CSS_EFFETS } from './kit/effets.mjs';
const carte = (fond, dedans) => `<svg viewBox="0 0 250 350" width="200" height="280"><rect width="250" height="350" rx="22" fill="${fond}"/>${dedans}</svg>`;
const cartes = [
  carte('#1d0b06', flammes({ graine: 1 }) + braises({ graine: 1 })),
  carte('#1a0b2e', flammes({ graine: 2, couleurs: ['#12051f', '#7C3AED', '#C084FC', '#F5D0FE'], h: 120, nb: 6 }) + braises({ couleurs: ['#F0ABFC', '#fff'], graine: 3 })),
  carte('#14102a', eclair({ x0: 120, y0: -5, x1: 90, y1: 330, graine: 2, d: 1, r: -.88, eclaire: '#FFF6C8' }) + pluie({})),
  carte('#170b2b', fumee({ graine: 3, nb: 6, y: 290 }) + etincelles({ graine: 2 })),
  carte('#062033', bulles({ graine: 4, nb: 10 })),
  carte('#4a0d18', pieces({ graine: 5 }) + etincelles({ couleurs: ['#FFE27A', '#fff'], encre: '#5a3a00', graine: 6 })),
  carte('#2b2f3a', vent({ graine: 3 })),
  carte('#2a0d05', flammes({ graine: 7, couleurs: ['#3a1500', '#F59E0B', '#FCD34D', '#FFF7D6'], x0: 0, x1: 250, h: 70, nb: 9 }) + braises({ graine: 8, nb: 14 })),
];
const html = `<!doctype html><meta charset="utf-8"><style>body{margin:0;padding:10px;background:#222;display:flex;flex-wrap:wrap;gap:10px}${CSS_EFFETS}</style>${cartes.join('')}`;
writeFileSync('essai-effets.html', html);
const ms = process.argv[2] || '900';
execFileSync('node', ['capture.mjs', 'essai-effets.html', 'vues/essai-effets.png', '880', ms, '1'], { stdio: 'inherit' });
