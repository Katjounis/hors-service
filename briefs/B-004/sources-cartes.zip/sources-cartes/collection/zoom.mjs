// Vue rapprochée : quelques cartes en grand. node zoom.mjs <sortie.png> <ms> <id:carte,id:carte,...>  (carte = dos, R-S, D-H, A-D, 10-H…)
import { writeFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { SKINS } from './skins/index.mjs';
import { dos, recto, CSS_CARTE, CSS_ANIME } from './kit/carte.mjs';
import { CSS_FIGURES } from './kit/figures.mjs';
import { CSS_DESSIN } from './kit/dessin.mjs';
const [sortie, ms = '1200', liste] = process.argv.slice(2);
const cartes = liste.split(',').map((x) => { const [id, q] = x.split(':'); const s = SKINS.find((k) => k.id === id); return q === 'dos' ? dos(s) : recto(s, ...q.split('-')); });
const css = `body{margin:0;background:#1a1714;padding:8px;display:flex;flex-wrap:wrap;gap:8px}svg{width:230px;height:322px;display:block;border-radius:14px}${CSS_CARTE}${CSS_ANIME}${CSS_FIGURES}${CSS_DESSIN}${SKINS.map((s) => s.css || '').join('\n')}`;
writeFileSync('zoom-tmp.html', `<!doctype html><meta charset="utf-8"><style>${css}</style>${cartes.join('')}`);
execFileSync('node', ['capture.mjs', 'zoom-tmp.html', sortie, String(Math.min(4, cartes.length) * 238 + 16), ms, '1'], { stdio: 'inherit' });
