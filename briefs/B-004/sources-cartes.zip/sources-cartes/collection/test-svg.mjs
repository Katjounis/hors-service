// Ouvre des SVG livrés tout seuls (sans la galerie) : s'affichent-ils, et s'animent-ils ?
import { createRequire } from 'node:module';
import { readdirSync } from 'node:fs';
const { chromium } = createRequire(import.meta.url)('playwright');
const b = await chromium.launch(); const p = await (await b.newContext({ viewport: { width: 250, height: 350 } })).newPage(); const out = [];
for (const f of ['04_LEGENDAIRES/L-003 l003-jackpot-infini/dos.svg', '04_LEGENDAIRES/L-001 l001-roi-du-chaos/roi-pique.svg', '03_EPIQUES/E-002 e002-tempete-electrique/dame-coeur.svg', '02_RARES/R-020 r020-radar/dos.svg', '01_COMMUNES/C-010 c010-sous-bock/valet-trefle.svg']) {
  const errs = []; p.removeAllListeners('pageerror'); p.on('pageerror', (e) => errs.push(e.message));
  await p.goto('file://' + new URL('./export/' + f, import.meta.url).pathname); await p.waitForTimeout(500);
  const n = await p.evaluate(() => document.getAnimations().length);
  out.push(`${f} : ${n} animations ${errs.length ? 'ERREUR ' + errs[0] : ''}`);
}
await p.goto('file://' + new URL('./export/04_LEGENDAIRES/L-001 l001-roi-du-chaos/roi-pique.svg', import.meta.url).pathname); await p.waitForTimeout(700); await p.screenshot({ path: 'vues/svg-autonome.png' });
await b.close(); console.log(out.join('\n'));
