// S-003 : les épiques et les légendaires poussés plus loin. Chaque thème ajoute des calques dessinés et animés
// (flammes, foudre, fumée, pièces, bulles, étoiles, pluie, vent) au dos et aux rectos.
// Les coins restent lisibles : les effets évitent les coins, ou la carte reçoit un cartouche sous la valeur (onglet).
import { cadre } from '../kit/base.mjs';
import { flammes, braises, eclair, fumee, etincelles, bulles, pieces, pluie, vent, nuages } from '../kit/effets.mjs';

const fig = (c) => 'VDR'.includes(c.rang);
const as = (c) => c.rang === 'A';
const g = (c) => [...(c.rang + c.ens)].reduce((a, ch) => a * 31 + ch.charCodeAt(0), 7) % 997;
// zones libres des rectos : les deux côtés (entre les coins) et la bande haute à droite du coin
const COTES = [[16, 140, 56, 212], [194, 140, 234, 212]];
const HAUT = [[96, 20, 232, 72]];

const FEU_CHAOS = ['#0b0612', '#6D28D9', '#F5C518', '#FFF3B0'];
const FEU_VIOLET = ['#12061f', '#7C3AED', '#C084FC', '#F5D0FE'];
const FEU_OR = ['#3a1500', '#EA580C', '#FBBF24', '#FFF7D6'];

export const THEMES = {
  // Roi du Chaos : flammes violet et or au pied du dos, braises ; aux rectos, la foudre et les flammes sont derrière les figures
  'L-001': {
    dos: () => flammes({ y: 358, h: 66, nb: 7, couleurs: FEU_CHAOS, graine: 11 }) + braises({ couleurs: ['#F5C518', '#C084FC'], graine: 12, nb: 10, monte: 170 }),
    devant: (c) => (fig(c) ? braises({ couleurs: ['#F5C518', '#C084FC'], graine: g(c), nb: 6, y: 330 }) : ''),
  },
  // Dieu du Purple : la fumée violette monte du trône, des étincelles s'allument
  'L-002': {
    dos: () => fumee({ x: 125, y: 350, nb: 5, couleurs: ['#12061f', '#6D28D9', '#E9D5FF'], taille: 17, largeur: 210, monte: 170, graine: 21 }) + etincelles({ couleurs: ['#F0ABFC', '#FFFFFF'], encre: '#12061f', graine: 22, nb: 8 }),
    devant: (c) => (fig(c) ? fumee({ x: 70, y: 340, nb: 3, couleurs: ['#12061f', '#7C3AED', '#E9D5FF'], taille: 16, largeur: 90, monte: 110, graine: g(c) }) : etincelles({ zones: COTES, couleurs: ['#F0ABFC'], encre: '#12061f', graine: g(c), nb: 3, taille: [5, 9] })),
  },
  // Jackpot Infini : pluie de pièces qui tournent, étincelles d'or
  'L-003': {
    dos: () => pieces({ nb: 8, graine: 31 }) + etincelles({ couleurs: ['#FFE27A', '#FFFFFF'], encre: '#5a3a00', graine: 32, nb: 8 }),
    devant: (c) => (fig(c) ? pieces({ nb: 4, graine: g(c), x0: 90, x1: 230 }) : etincelles({ zones: COTES, couleurs: ['#F5B301'], encre: '#5a3a00', graine: g(c), nb: 3, taille: [5, 9] })),
  },
  // Trou Noir : des étoiles scintillent, de petits arcs crépitent au bord du disque
  'L-004': {
    dos: () => etincelles({ couleurs: ['#FFE7B0', '#FFFFFF'], encre: '#000000', graine: 41, nb: 10 })
      + eclair({ x0: 30, y0: 186, x1: 78, y1: 168, ecart: 18, ep: 3.4, couleurs: ['#2a0a4a', '#FFE7B0'], graine: 43, d: 3.2, r: -1 })
      + eclair({ x0: 222, y0: 160, x1: 176, y1: 182, ecart: 18, ep: 3.4, couleurs: ['#2a0a4a', '#FF9F1C'], graine: 44, d: 4.1, r: -2.6 }),
    devant: (c) => etincelles({ zones: fig(c) ? HAUT : COTES, couleurs: ['#FFE7B0'], encre: '#000000', graine: g(c), nb: 3, taille: [5, 9] }),
  },
  // Hors Service Ultime : l'enseigne grésille, des étincelles électriques sautent, la panne fume
  'L-005': {
    dos: () => fumee({ x: 125, y: 104, nb: 4, couleurs: ['#0b0b0b', '#4b4b4b', '#bdbdbd'], taille: 15, monte: 80, largeur: 130, graine: 51 })
      + eclair({ x0: 36, y0: 116, x1: 66, y1: 158, ecart: 16, ep: 3.4, couleurs: ['#1a0a00', '#FFD76A'], graine: 52, d: 2.6, r: -.4 })
      + eclair({ x0: 214, y0: 222, x1: 184, y1: 262, ecart: 16, ep: 3.4, couleurs: ['#1a0a00', '#FF2E63'], graine: 53, d: 3.4, r: -1.9 }),
    devant: (c) => (fig(c) ? eclair({ x0: 228, y0: 40, x1: 196, y1: 84, ecart: 14, ep: 3, couleurs: ['#1a0a00', '#FFD76A'], graine: g(c), d: 2.8, r: -(g(c) % 3) }) : ''),
  },
  // Tempête électrique : deux éclairs à l'encre avec un flash, la pluie ; aux rectos, la foudre tombe du nuage
  'E-002': {
    onglet: true,
    derriere: (c) => (fig(c) ? '' : nuages({ y: 26, nb: 5, couleur: '#E4E7FA', taille: 24, graine: g(c) }) + pluie({ couleur: '#DCE1F8', graine: g(c), nb: 12 }).replace(/class="fx-goutte"/g, 'class="fx-goutte-fixe"')),
    dos: () => eclair({ x0: 150, y0: 46, x1: 112, y1: 338, ecart: 72, ep: 7, couleurs: ['#120c2e', '#FFF6C8'], graine: 61, d: 3.4, r: -2.9, eclaire: '#FFF6C8' })
      + eclair({ x0: 62, y0: 60, x1: 34, y1: 262, ecart: 46, ep: 5, couleurs: ['#120c2e', '#FDE047'], graine: 62, d: 4.6, r: -1.2 }) + pluie({ couleur: '#A5B4FC', graine: 63, nb: 18 }),
    devant: (c) => (fig(c) ? eclair({ x0: 206, y0: 34, x1: 176, y1: 170, ecart: 40, ep: 4.4, couleurs: ['#120c2e', '#FDE047'], graine: g(c), d: 3.8, r: -(g(c) % 3) })
      : as(c) ? eclair({ x0: 186, y0: 70, x1: 150, y1: 150, ecart: 26, ep: 3.6, couleurs: ['#120c2e', '#FDE047'], graine: g(c), d: 3.2, r: -1 }) : ''),
  },
  // Portail dimensionnel : énergie qui s'échappe en volutes, étincelles cyan et rose
  'E-003': {
    derriere: (c) => (fig(c) ? '' : `<g fill="none" stroke="#DDF4FA" stroke-linecap="round">${[44, 76, 108].map((r, i) => `<circle cx="125" cy="176" r="${r}" stroke-width="${7 - i * 2}" stroke-dasharray="${[60, 18, 24, 30][i % 4]} ${12 + i * 6}"/>`).join('')}</g>`),
    dos: () => fumee({ x: 125, y: 336, nb: 4, couleurs: ['#0F172A', '#22D3EE', '#A5F3FC'], taille: 13, monte: 90, largeur: 150, graine: 72 }) + etincelles({ couleurs: ['#22D3EE', '#F0ABFC', '#FFFFFF'], encre: '#0F172A', graine: 71, nb: 12 }),
    devant: (c) => etincelles({ zones: fig(c) ? HAUT : COTES, couleurs: ['#22D3EE', '#F0ABFC'], encre: '#0F172A', graine: g(c), nb: 3, taille: [5, 9] }),
  },
  // Océan abyssal : des bulles montent
  'E-004': {
    dos: () => bulles({ graine: 81, nb: 10 }),
    devant: (c) => bulles({ x0: 18, x1: 54, y: 330, nb: 2, monte: 190, graine: g(c) }) + bulles({ x0: 196, x1: 232, y: 214, nb: 2, monte: 160, graine: g(c) + 1 }),
  },
  // Cosmos : étoiles qui scintillent et étoiles filantes
  'E-005': {
    dos: () => etincelles({ couleurs: ['#FDE68A', '#FFFFFF', '#F0ABFC'], encre: '#0b1021', graine: 91, nb: 12 }) + vent({ nb: 2, couleur: '#FDE68A', encre: '#0b1021', zone: [10, 30, 200, 150], graine: 92 }),
    devant: (c) => etincelles({ zones: fig(c) ? HAUT : COTES, couleurs: ['#FDE68A', '#FFFFFF'], encre: '#0b1021', graine: g(c), nb: 3, taille: [5, 9] }),
  },
  // Kraken : bulles qui remontent des profondeurs
  'E-006': {
    derriere: (c) => (fig(c) ? '' : `<path d="M0 312 C30 300 50 324 80 312 C110 300 130 324 160 312 C190 300 210 324 250 310 V350 H0 Z" fill="#E9EFE4"/><path d="M0 330 C30 318 50 342 80 330 C110 318 130 342 160 330 C190 318 210 342 250 328 V350 H0 Z" fill="#DFE8DA"/>`),
    dos: () => bulles({ graine: 101, nb: 9, couleurs: ['#E6FFFB', '#134E4A'] }),
    devant: (c) => bulles({ x0: 18, x1: 54, y: 330, nb: 2, monte: 190, graine: g(c), couleurs: ['#134E4A', '#99F6E4'] }),
  },
  // Phénix : flammes d'or au pied de la carte, braises qui s'envolent
  'E-007': {
    onglet: true,
    derriere: (c) => (fig(c) ? '' : flammes({ y: 362, h: 46, nb: 9, couleurs: ['#F6E3CC', '#FAE6D0', '#FCEEDD', '#FFF6EA'], graine: g(c), ep: 0 }).replace(/class="fx-fl(-c)?"/g, 'class="fx-fixe"')),
    dos: () => flammes({ y: 358, h: 72, nb: 7, couleurs: FEU_OR, graine: 111 }) + braises({ couleurs: ['#FDE68A', '#F97316'], graine: 112, nb: 12, monte: 190 }),
    devant: (c) => (fig(c) ? flammes({ y: 360, h: 50, nb: 6, couleurs: FEU_OR, graine: g(c) }) + braises({ couleurs: ['#FDE68A', '#F97316'], graine: g(c), nb: 6, y: 320 })
      : braises({ couleurs: ['#F97316', '#FDE68A'], graine: g(c), nb: as(c) ? 7 : 4, y: 330, monte: 140 })),
  },
  // Cyberpunk : pluie néon et étincelles
  'E-008': {
    dos: () => pluie({ couleur: '#22D3EE', graine: 121, nb: 20 }) + etincelles({ couleurs: ['#F472B6', '#22D3EE'], encre: '#000000', graine: 122, nb: 6 }),
    derriere: (c) => pluie({ couleur: '#1f5f6a', graine: g(c), nb: 14 }),
  },
  // Tornade de cartes : le vent file autour
  'E-009': {
    derriere: (c) => (fig(c) ? '' : vent({ nb: 6, couleur: '#E8ECF2', encre: '#EEF1F5', graine: g(c), zone: [14, 60, 236, 300] }).replace(/class="fx-vent"/g, 'class="fx-vent-fixe"')),
    dos: () => vent({ graine: 131, nb: 8, couleur: '#F8FAFC', encre: '#1E293B' }),
    devant: (c) => (fig(c) ? vent({ nb: 3, zone: [100, 40, 236, 130], couleur: '#F8FAFC', encre: '#1E293B', graine: g(c) }) : ''),
  },
  // Enlèvement : des étincelles montent dans le rayon de la soucoupe
  'E-010': {
    derriere: (c) => (fig(c) ? '' : '<path d="M104 0 H146 L214 350 H36 Z" fill="#EEF6DC"/>'),
    dos: () => etincelles({ couleurs: ['#A3E635', '#FFFFFF'], encre: '#111827', graine: 141, nb: 10, zones: [[80, 130, 170, 330]] }),
    devant: (c) => (fig(c) ? etincelles({ couleurs: ['#A3E635', '#FFFFFF'], encre: '#111827', graine: g(c), nb: 4, zones: [[96, 150, 160, 300]], taille: [5, 9] }) : ''),
  },
};

// habille un skin avec son thème (le reste du skin ne change pas)
export function orner(s) {
  const th = THEMES[s.id]; if (!th) return s;
  const face = th.onglet && !s.face.onglet ? { ...s.face, onglet: s.face.papier, ongletOp: 1 } : s.face;
  const dos0 = s.dos, recto0 = s.recto;
  return Object.assign(s, {
    face,
    dos: (u) => dos0(u) + (th.dos ? th.dos(u) : ''),
    recto: (c, ens) => {
      const r = (recto0 ? recto0(c, ens) : null) || {};
      return { ...r, fond: (r.fond || cadre(`fill="${face.papier}"`)) + (th.derriere ? th.derriere(c) : ''), devant: (r.devant || '') + (th.devant ? th.devant(c) : '') };
    },
  });
}
