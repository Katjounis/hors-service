// La collection complète : 5 légendaires, 10 épiques, 30 rares, 55 communes. Chaque fiche devient un skin prêt à dessiner.
import { creerSkin } from '../kit/carte.mjs';
import { COMMUNES_A } from './communes-a.mjs';
import { COMMUNES_B } from './communes-b.mjs';
import { RARES_A } from './rares-a.mjs';
import { RARES_B } from './rares-b.mjs';
import { EPIQUES } from './epiques.mjs';
import { LEGENDAIRES } from './legendaires.mjs';
import { orner } from './themes.mjs';
import { COMMUNES, RARES, EPIQUES as E0, LEGENDAIRES as L0 } from '../../catalogue/concepts.mjs';
const CONCEPTS = new Map([...COMMUNES, ...RARES, ...E0, ...L0].map((c) => [c[0], c]));
// le texte des concepts validés suit chaque skin (dos, recto, effet prévu), avec son ancien numéro
const prets = (l) => l.map((d) => { const s = typeof d.recto === 'function' ? d : creerSkin(d); const c = CONCEPTS.get(s.ancien) || []; return orner(Object.assign(s, { descDos: c[4] || '', descRecto: c[5] || '', famille: s.famille || c[3] })); });
export const SKINS = [...prets(LEGENDAIRES), ...prets(EPIQUES), ...prets(RARES_A), ...prets(RARES_B), ...prets(COMMUNES_A), ...prets(COMMUNES_B)];
export default SKINS;
