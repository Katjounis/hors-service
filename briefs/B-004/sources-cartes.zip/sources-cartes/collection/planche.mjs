// Planche de contrôle : pour chaque skin, le dos puis Roi, Dame, Valet, As, 10. node planche.mjs <module:export> <sortie.png> [début] [fin] [ms]
import { writeFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { creerSkin, dos, recto, CSS_CARTE, CSS_ANIME } from './kit/carte.mjs';
import { CSS_FIGURES } from './kit/figures.mjs';
import { CSS_DESSIN } from './kit/dessin.mjs';
const [source, sortie, debut = '0', fin = '999', ms = '2600'] = process.argv.slice(2);
const [fichier, nom] = source.split(':');
const mod = await import('./' + fichier);
const liste = (nom ? mod[nom] : mod.default).slice(Number(debut), Number(fin)).map((d) => (typeof d.recto === 'function' ? d : creerSkin(d)));
const lignes = liste.map((s) => `<div class="l"><div class="t"><b>${s.id}</b> ${s.nom}<br><i>${s.rarete}${s.ancien && s.ancien !== s.id ? ' (ex ' + s.ancien + ')' : ''}</i></div>${dos(s)}${recto(s, 'R', 'S')}${recto(s, 'D', 'H')}${recto(s, 'V', 'C')}${recto(s, 'A', 'D')}${recto(s, '10', 'H')}${recto(s, '7', 'S')}</div>`).join('');
const css = `body{margin:0;background:#1a1714;color:#eee;font:12px system-ui;padding:8px}.l{display:grid;grid-template-columns:120px repeat(7,112px);gap:6px;align-items:center;margin-bottom:8px}.l svg{width:112px;height:157px;display:block;border-radius:9px;box-shadow:0 0 0 1px #000}.t b{font-size:13px}.t i{color:#aaa}${CSS_CARTE}${CSS_ANIME}${CSS_FIGURES}${CSS_DESSIN}${liste.map((s) => s.css || '').join('\n')}`;
writeFileSync('planche-tmp.html', `<!doctype html><meta charset="utf-8"><style>${css}</style>${lignes}`);
execFileSync('node', ['capture.mjs', 'planche-tmp.html', sortie, '940', ms, '1'], { stdio: 'inherit' });
