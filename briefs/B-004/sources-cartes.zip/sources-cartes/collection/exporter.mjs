// Exporte la collection : un dossier par skin (SVG autonomes + fiche), vignettes, planches par rareté, catalogue JSON et CSV.
import { writeFileSync, mkdirSync, rmSync, readFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { createRequire } from 'node:module';
import { SKINS } from './skins/index.mjs';
import { dos, recto, NIVEAU, NOMS_RANGS, CSS_CARTE, CSS_ANIME, remiseAZero } from './kit/carte.mjs';
import { CSS_FIGURES } from './kit/figures.mjs';
import { CSS_DESSIN } from './kit/dessin.mjs';
import { NOM_ENSEIGNE } from './kit/base.mjs';
const { chromium } = createRequire(import.meta.url)('playwright');
const OUT = new URL('./export/', import.meta.url).pathname; rmSync(OUT, { recursive: true, force: true });
const DOSSIER = { 'Commune': '01_COMMUNES', 'Rare': '02_RARES', 'Épique': '03_EPIQUES', 'Légendaire': '04_LEGENDAIRES' };
const CSS_BASE = CSS_CARTE + CSS_ANIME + CSS_FIGURES + CSS_DESSIN + '@media (prefers-reduced-motion: reduce) { * { animation: none !important; } }';
const FACES = [['R', 'S'], ['D', 'H'], ['V', 'C'], ['A', 'D'], ['10', 'H'], ['7', 'S'], ['2', 'C']];
const nomFichier = (r, e) => `${(NOMS_RANGS[r] || r).toLowerCase()}-${NOM_ENSEIGNE[e]}.svg`.replace('œ', 'oe').replace('è', 'e');
const sansAccent = (t) => t.normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[’']/g, '-');
const catalogue = [];
for (const s of SKINS) {
  const dossier = `${OUT}${DOSSIER[s.rarete]}/${s.id} ${s.cle}/`; mkdirSync(dossier, { recursive: true }); remiseAZero();
  const css = CSS_BASE + (s.css || '');
  writeFileSync(dossier + 'dos.svg', dos(s, true, css));
  for (const [r, e] of FACES) writeFileSync(dossier + nomFichier(r, e), recto(s, r, e, true, css));
  const fiche = { id: s.id, cle: s.cle, nom: s.nom, rarete: s.rarete, famille: s.famille, ancien_identifiant: s.ancien, couleurs: s.couleurs, dos: s.descDos, recto: s.descRecto, ce_qui_bouge: s.bouge, au_retournement: s.retournement,
    figures: s.figures ? { style: s.figures.style, niveau_animation: s.figures.anim, coiffes: s.figures.coiffes, objets: s.figures.objets, variantes: s.figures.variantes } : 'faites main',
    fichiers: ['dos.svg', ...FACES.map(([r, e]) => nomFichier(r, e)), 'vignette-dos.webp', 'vignette-roi.webp'] };
  writeFileSync(dossier + 'fiche.json', JSON.stringify(fiche, null, 2));
  catalogue.push({ ...fiche, dossier: `${DOSSIER[s.rarete]}/${s.id} ${s.cle}` });
}
// vignettes et mesure des animations, dans Chromium
const b = await chromium.launch(); const ctx = await b.newContext({ viewport: { width: 600, height: 400 }, deviceScaleFactor: 1 }); const p = await ctx.newPage();
await p.setContent(`<!doctype html><meta charset="utf-8"><style>body{margin:0;background:transparent}#z{display:flex;gap:0}#z svg{width:250px;height:350px;display:block}${CSS_BASE}${SKINS.map((s) => s.css || '').join('\n')}</style><div id="z"></div>`);
for (const [k, s] of SKINS.entries()) {
  const dossier = `${OUT}${DOSSIER[s.rarete]}/${s.id} ${s.cle}/`; remiseAZero();
  await p.evaluate((h) => { document.getElementById('z').innerHTML = h; }, dos(s) + recto(s, 'R', 'S'));
  await p.waitForTimeout(60);
  const mesure = await p.evaluate(() => { const [d, r] = document.querySelectorAll('#z svg'); const lire = (el) => { const l = el.getAnimations({ subtree: true }); const noms = {}; for (const a of l) { const n = a.animationName || 'transition'; const t = a.effect.getTiming(); noms[n] = Math.round(Number(t.duration) || 0); } return { nombre: l.length, boucles: Object.entries(noms).map(([nom, ms]) => ({ nom, duree_ms: ms })) }; }; return { dos: lire(d), roi: lire(r) }; });
  await p.evaluate(() => { for (const a of document.getAnimations()) { try { a.pause(); a.currentTime = 1800; } catch (e) {} } });
  await p.locator('#z svg').nth(0).screenshot({ path: dossier + 'vignette-dos.png', omitBackground: true });
  await p.locator('#z svg').nth(1).screenshot({ path: dossier + 'vignette-roi.png', omitBackground: true });
  Object.assign(catalogue[k], { animations: { dos: mesure.dos, recto_roi: mesure.roi } });
  const f = JSON.parse(readFileSync(dossier + 'fiche.json', 'utf8')); f.animations = catalogue[k].animations; writeFileSync(dossier + 'fiche.json', JSON.stringify(f, null, 2));
}
await b.close();
execFileSync('python3', ['-c', `
import glob, os
from PIL import Image
for f in glob.glob(${JSON.stringify(OUT)} + '*/*/vignette-*.png'):
    Image.open(f).save(f[:-4] + '.webp', 'WEBP', quality=82, method=6); os.remove(f)
`]);
writeFileSync(OUT + 'catalogue-100-skins.json', JSON.stringify({ titre: 'Hors Service : les 100 skins de cartes', repartition: { 'Légendaire': 5, 'Épique': 10, 'Rare': 30, 'Commune': 55 }, skins: catalogue }, null, 2));
const cel = (v) => `"${String(v ?? '').replace(/"/g, '""')}"`;
const lignes = [['Identifiant', 'Ancien identifiant', 'Rareté', 'Nom', 'Famille', 'Clé technique', 'Couleur 1', 'Couleur 2', 'Couleur 3', 'Le dos', 'Le recto', 'Ce qui bouge', 'Au retournement', 'Animations sur le dos', 'Animations sur le roi', 'Style des figures', 'Dossier'].map(cel).join(',')]
  .concat(catalogue.map((c) => [c.id, c.ancien_identifiant, c.rarete, c.nom, c.famille, c.cle, ...c.couleurs, c.dos, c.recto, c.ce_qui_bouge, c.au_retournement, c.animations.dos.nombre, c.animations.recto_roi.nombre, typeof c.figures === 'string' ? c.figures : c.figures.style, c.dossier].map(cel).join(',')));
writeFileSync(OUT + 'catalogue-100-skins.csv', '﻿' + lignes.join('\n'));
console.log('export :', catalogue.length, 'skins');
