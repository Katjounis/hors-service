// L-002 Dieu du Purple : silhouette en capuche sur un trône de cristaux violets, aura qui monte, signes en orbite.
import { L, H, cadre, hasard, n, enseigne } from '../outils.mjs';
const CX = 125;
// un cristal : pointe en haut, posé en (x, y), incliné de a degrés
const cristal = (x, y, larg, haut, a, i, u) => `<g transform="translate(${x} ${y}) rotate(${a})">
  <path d="M${-larg / 2} 0 L${-larg / 2} ${-haut * .78} L0 ${-haut} L${larg / 2} ${-haut * .78} L${larg / 2} 0 Z" fill="url(#dp-cristal-${u})" stroke="#3b0f6b" stroke-width="1.2" stroke-linejoin="round"/>
  <path d="M0 0 L0 ${-haut} L${larg / 2} ${-haut * .78} L${larg / 2} 0 Z" fill="#581c87" opacity=".55"/>
  <path d="M${-larg / 2} ${-haut * .78} L0 ${-haut * .68} L${larg / 2} ${-haut * .78} M0 ${-haut * .68} L0 0" fill="none" stroke="#F0ABFC" stroke-width=".9" opacity=".7"/>
  <path class="dp-allume" style="--i:${i}" d="M${-larg / 2} 0 L${-larg / 2} ${-haut * .78} L0 ${-haut} L${larg / 2} ${-haut * .78} L${larg / 2} 0 Z" fill="#F5D0FE"/>
</g>`;
const SIGNES = ['M-4 0 L0 -5 L4 0 L0 5 Z', 'M-4 4 L0 -4 L4 4 Z', 'M-4 0 A4 4 0 1 0 4 0 A4 4 0 1 0 -4 0', 'M-4 -4 L4 4 M4 -4 L-4 4', 'M-4 0 H4 M0 -4 V4', 'M3 -4 A5 5 0 1 0 3 4 A3.6 3.6 0 1 1 3 -4', 'M-4 3 L0 -4 L4 3 M-2.4 .4 H2.4', 'M-4 -3 H4 M-4 0 H4 M-4 3 H4'];

export default {
  id: 'L-002', cle: 'l002-dieu-du-purple', nom: 'Dieu du Purple', rarete: 'Légendaire', fx: 'dp',
  bouge: 'L’aura violette respire, les cristaux du trône s’allument l’un après l’autre, les signes tournent autour de la capuche, des volutes et des poussières montent, les yeux luisent.',
  retournement: 'Une bouffée de fumée violette enveloppe la carte.',
  face: { papier: '#1B0A33', encre: '#F7F2FF', rouge: '#FF6B88', sombre: true },
  css: `
.dp-aura { transform-origin: ${CX}px 190px; animation: dp-aura 4.2s ease-in-out infinite alternate; }
@keyframes dp-aura { from { transform: scale(.9, .94); opacity: .7; } to { transform: scale(1.1, 1.08); opacity: 1; } }
.dp-allume { opacity: 0; animation: dp-allume 4.4s ease-in-out infinite; animation-delay: calc(var(--i) * .34s); }
@keyframes dp-allume { 0%, 100% { opacity: 0; } 12% { opacity: .85; } 30% { opacity: 0; } }
.dp-signes { transform-origin: ${CX}px 150px; animation: dp-tourne 32s linear infinite; }
@keyframes dp-tourne { to { transform: rotate(360deg); } }
.dp-volute { animation: dp-volute 3.6s linear infinite; }
@keyframes dp-volute { to { stroke-dashoffset: -88; } }
.dp-grain { opacity: 0; animation: dp-grain var(--t) linear infinite; animation-delay: var(--d); }
@keyframes dp-grain { 0% { transform: translateY(0); opacity: 0; } 15% { opacity: .9; } 80% { opacity: .7; } 100% { transform: translateY(-230px); opacity: 0; } }
.dp-oeil { animation: dp-oeil 3.1s ease-in-out infinite; }
@keyframes dp-oeil { 0%, 100% { opacity: .75; } 45% { opacity: 1; } 50% { opacity: .2; } 55% { opacity: 1; } }
`,
  dos(u) {
    const h = hasard(5);
    const arriere = [[-58, 96, 20], [-40, 124, 22], [-21, 150, 24], [0, 170, 26], [21, 150, 24], [40, 124, 22], [58, 96, 20]].map(([a, haut, larg], i) => cristal(CX, 300, larg, haut, a, i, u)).join('');
    const devant = [[70, 318, 18, 46, -24], [96, 322, 16, 34, -8], [154, 322, 16, 34, 8], [180, 318, 18, 46, 24], [48, 322, 14, 28, -38], [202, 322, 14, 28, 38]].map(([x, y, larg, haut, a], i) => cristal(x, y, larg, haut, a, i + 7, u)).join('');
    const signes = SIGNES.concat(SIGNES.slice(0, 4)).map((d, i, t) => { const a = (i / t.length) * Math.PI * 2; return `<path transform="translate(${n(CX + Math.cos(a) * 66)} ${n(150 + Math.sin(a) * 66)}) rotate(${n((a * 180) / Math.PI + 90)})" d="${d}" fill="none" stroke="#F0ABFC" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>`; }).join('');
    const grains = Array.from({ length: 18 }, (_, i) => `<circle class="dp-grain" style="--t:${n(4.5 + h() * 4)}s;--d:${n(-h() * 8)}s" cx="${n(18 + h() * 214)}" cy="${n(250 + h() * 80)}" r="${n(.9 + h() * 1.5)}" fill="${i % 3 ? '#F0ABFC' : '#FFFFFF'}"/>`).join('');
    const volute = (x, s) => `<path class="dp-volute" d="M${x} 330 C${x + 16 * s} 290 ${x - 16 * s} 250 ${x} 210 C${x + 16 * s} 170 ${x - 16 * s} 130 ${x} 90 C${x + 12 * s} 60 ${x - 8 * s} 40 ${x} 20" fill="none" stroke="#E9D5FF" stroke-width="2.2" stroke-linecap="round" stroke-dasharray="10 34" opacity=".5"/>`;
    return `
<defs>
  <linearGradient id="dp-fond-${u}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0b0416"/><stop offset=".55" stop-color="#2E1065"/><stop offset="1" stop-color="#12061f"/></linearGradient>
  <radialGradient id="dp-aura-${u}"><stop offset="0" stop-color="#E9D5FF" stop-opacity=".85"/><stop offset=".4" stop-color="#C084FC" stop-opacity=".5"/><stop offset="1" stop-color="#7E22CE" stop-opacity="0"/></radialGradient>
  <linearGradient id="dp-cristal-${u}" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#6b21a8"/><stop offset=".6" stop-color="#a855f7"/><stop offset="1" stop-color="#e9d5ff"/></linearGradient>
  <linearGradient id="dp-robe-${u}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#241040"/><stop offset="1" stop-color="#0a0414"/></linearGradient>
</defs>
${cadre(`fill="url(#dp-fond-${u})"`)}
<ellipse class="dp-aura" cx="${CX}" cy="190" rx="112" ry="150" fill="url(#dp-aura-${u})"/>
${volute(34, 1)}${volute(216, -1)}
${arriere}
<g class="dp-signes"><circle cx="${CX}" cy="150" r="66" fill="none" stroke="#C084FC" stroke-width=".8" opacity=".45"/>${signes}</g>
<path d="M88 300 L96 214 Q125 188 154 214 L162 300 Z" fill="url(#dp-robe-${u})" stroke="#3b1d6b" stroke-width="1.4" stroke-linejoin="round"/>
<path d="M108 230 L104 298 M125 222 V298 M142 230 L146 298" stroke="#3b1d6b" stroke-width="1.2" opacity=".8"/>
<path d="M96 222 Q70 236 62 262 L84 268 Q92 250 104 242 Z" fill="url(#dp-robe-${u})" stroke="#3b1d6b" stroke-width="1.2" stroke-linejoin="round"/>
<path d="M154 222 Q180 236 188 262 L166 268 Q158 250 146 242 Z" fill="url(#dp-robe-${u})" stroke="#3b1d6b" stroke-width="1.2" stroke-linejoin="round"/>
<g transform="translate(72 258) rotate(-18)"><rect x="-9" y="-13" width="18" height="26" rx="2.5" fill="#F7F2FF" stroke="#3b1d6b" stroke-width="1"/>${enseigne('H', 0, 0, 12, 'fill="#E11D48"')}</g>
<g transform="translate(178 258) rotate(18)"><rect x="-9" y="-13" width="18" height="26" rx="2.5" fill="#F7F2FF" stroke="#3b1d6b" stroke-width="1"/>${enseigne('S', 0, 0, 12, 'fill="#17120A"')}</g>
<path d="M125 112 C153 112 166 140 163 172 C161 192 150 204 125 208 C100 204 89 192 87 172 C84 140 97 112 125 112 Z" fill="#1b0d30" stroke="#4c1d95" stroke-width="1.6"/>
<path d="M125 126 C143 126 151 146 149 168 C148 184 140 194 125 196 C110 194 102 184 101 168 C99 146 107 126 125 126 Z" fill="#05020a"/>
<g class="dp-oeil"><ellipse cx="115" cy="162" rx="5.2" ry="2.6" fill="#F0ABFC"/><ellipse cx="135" cy="162" rx="5.2" ry="2.6" fill="#F0ABFC"/><ellipse cx="115" cy="162" rx="2" ry="1.2" fill="#fff"/><ellipse cx="135" cy="162" rx="2" ry="1.2" fill="#fff"/><ellipse cx="115" cy="162" rx="10" ry="6" fill="#F0ABFC" opacity=".18"/><ellipse cx="135" cy="162" rx="10" ry="6" fill="#F0ABFC" opacity=".18"/></g>
${devant}
${grains}
<rect x="7" y="7" width="${L - 14}" height="${H - 14}" rx="16" fill="none" stroke="#C084FC" stroke-width="2"/>
<rect x="12.5" y="12.5" width="${L - 25}" height="${H - 25}" rx="12" fill="none" stroke="#F0ABFC" stroke-width=".8" opacity=".7"/>
<path d="M18 30 L26 18 L34 30 L26 42 Z M${L - 18} 30 L${L - 26} 18 L${L - 34} 30 L${L - 26} 42 Z M18 ${H - 30} L26 ${H - 18} L34 ${H - 30} L26 ${H - 42} Z M${L - 18} ${H - 30} L${L - 26} ${H - 18} L${L - 34} ${H - 30} L${L - 26} ${H - 42} Z" fill="#a855f7" stroke="#F0ABFC" stroke-width="1"/>`;
  },
  recto(u) {
    const c = (x, y, a) => `<g transform="translate(${x} ${y}) rotate(${a})"><path d="M-7 0 L-7 -18 L0 -27 L7 -18 L7 0 Z" fill="#a855f7" stroke="#F0ABFC" stroke-width="1"/><path d="M0 0 V-27" stroke="#F0ABFC" stroke-width=".8" opacity=".7"/></g>`;
    return { fond: `<defs><radialGradient id="dpf-${u}" cx="50%" cy="50%" r="72%"><stop offset="0" stop-color="#3b1675"/><stop offset="1" stop-color="#12061f"/></radialGradient></defs>${cadre(`fill="url(#dpf-${u})"`)}`,
      bord: `<rect x="7" y="7" width="${L - 14}" height="${H - 14}" rx="16" fill="none" stroke="#C084FC" stroke-width="2"/>`,
      dessus: c(204, 46, 20) + c(220, 50, 42) + c(46, 304, 200) + c(30, 300, 222) };
  },
};
