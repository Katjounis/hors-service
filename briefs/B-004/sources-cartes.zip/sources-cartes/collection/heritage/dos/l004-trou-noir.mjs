// L-004 Trou Noir : disque de matière en spirale autour d'un centre noir, étoiles aspirées.
import { L, H, cadre, semis, n } from '../outils.mjs';
const CX = 125, CY = 170;
// anneaux du disque, du plus large au plus serré : [rx, ry, épaisseur, couleur, pointillé, durée d'un tour]
const ANNEAUX = [[108, 31, 5, '#7B2FF7', '70 22 30 14', 9], [96, 27, 5, '#B5179E', '50 16 18 10', 7.5], [84, 23, 5, '#FF7A1A', '44 12 20 8', 6], [72, 19, 4.5, '#FF9F1C', '36 10 14 8', 5], [61, 15.5, 4, '#FFC766', '30 8 12 6', 4], [51, 12.5, 3, '#FFF3D6', '24 7 9 5', 3.2]];
const spirale = (depart, tours, r0, r1) => { const pts = []; for (let i = 0; i <= 60; i++) { const k = i / 60, a = depart + k * tours * Math.PI * 2, r = r0 + (r1 - r0) * k; pts.push(`${n(CX + Math.cos(a) * r)},${n(CY + Math.sin(a) * r * .86)}`); } return pts.join(' '); };

export default {
  id: 'L-004', cle: 'l004-trou-noir', nom: 'Trou Noir', rarete: 'Légendaire', fx: 'tn',
  bouge: 'Le disque de matière tourne, chaque anneau à sa vitesse. Neuf étoiles sont aspirées en spirale, l’anneau de lumière palpite, le ciel tourne lentement.',
  retournement: 'La carte est avalée en tournant, puis recrachée de l’autre côté.',
  face: { papier: '#000000', encre: '#F5F2EA', rouge: '#FF5964', sombre: true },
  css: `
.l04-ciel { transform-origin: ${CX}px ${CY}px; animation: l04-tourne 160s linear infinite; }
.l04-bras { transform-origin: ${CX}px ${CY}px; animation: l04-tourne 46s linear infinite; }
@keyframes l04-tourne { to { transform: rotate(360deg); } }
.l04-anneau { animation: l04-file var(--t) linear infinite; }
@keyframes l04-file { to { stroke-dashoffset: var(--fin); } }
.l04-scintille { animation: l04-scintille var(--t) ease-in-out infinite alternate; animation-delay: var(--d); }
@keyframes l04-scintille { from { opacity: .25; } to { opacity: 1; } }
.l04-photon { transform-origin: ${CX}px ${CY}px; animation: l04-photon 2.6s ease-in-out infinite alternate; }
@keyframes l04-photon { from { transform: scale(1); opacity: .8; } to { transform: scale(1.045); opacity: 1; } }
.l04-chute { transform-origin: ${CX}px ${CY}px; opacity: 0; animation: l04-chute 5.6s cubic-bezier(.5, 0, .9, .4) infinite; animation-delay: calc(var(--i) * -.62s); }
@keyframes l04-chute { 0% { transform: rotate(var(--a)) scale(1); opacity: 0; } 12% { opacity: 1; } 85% { opacity: 1; } 100% { transform: rotate(calc(var(--a) + 420deg)) scale(.16); opacity: 0; } }
.l04-arc { animation: l04-arc 3.4s ease-in-out infinite alternate; }
@keyframes l04-arc { from { opacity: .78; } to { opacity: 1; } }
`,
  dos(u) {
    const etoiles = semis(70, 7, { r0: .5, r1: 1.5, duree: [1.6, 4.5] }).map((e, i) => `<circle${i % 3 === 0 ? ` class="l04-scintille" style="--t:${e.t}s;--d:${e.d}s"` : ''} cx="${e.x}" cy="${e.y}" r="${e.r}" fill="${i % 7 === 0 ? '#C4B5FD' : i % 5 === 0 ? '#FFD9A8' : '#FFFFFF'}" opacity="${i % 3 === 0 ? 1 : .55}"/>`).join('');
    const moitie = (clip) => ANNEAUX.map(([rx, ry, ep, coul, tirets, t]) => { const fin = -tirets.split(' ').map(Number).reduce((a, b) => a + b, 0) * 4; return `<ellipse class="l04-anneau" style="--t:${t * 4}s;--fin:${fin}" cx="${CX}" cy="${CY}" rx="${rx}" ry="${ry}" fill="none" stroke="${coul}" stroke-width="${ep}" stroke-dasharray="${tirets}" stroke-linecap="round" clip-path="url(#l04-${clip}-${u})"/>`; }).join('');
    const chutes = Array.from({ length: 9 }, (_, i) => `<circle class="l04-chute" style="--i:${i};--a:${i * 40}deg" cx="${CX + 118}" cy="${CY}" r="${i % 3 === 0 ? 2.6 : 1.8}" fill="${i % 2 ? '#FFE7B0' : '#FFFFFF'}"/>`).join('');
    return `
<defs>
  <radialGradient id="l04-fond-${u}" cx="50%" cy="48%" r="72%"><stop offset="0" stop-color="#1c0b3a"/><stop offset=".5" stop-color="#090414"/><stop offset="1" stop-color="#000"/></radialGradient>
  <radialGradient id="l04-lueur-${u}"><stop offset="0" stop-color="#FF9F1C" stop-opacity=".55"/><stop offset=".6" stop-color="#7B2FF7" stop-opacity=".2"/><stop offset="1" stop-color="#7B2FF7" stop-opacity="0"/></radialGradient>
  <linearGradient id="l04-arc-${u}" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#FF7A1A"/><stop offset=".5" stop-color="#FFF3D6"/><stop offset="1" stop-color="#FF7A1A"/></linearGradient>
  <linearGradient id="l04-bras-${u}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#7B2FF7" stop-opacity=".55"/><stop offset="1" stop-color="#7B2FF7" stop-opacity="0"/></linearGradient>
  <clipPath id="l04-haut-${u}"><rect x="0" y="0" width="${L}" height="${CY}"/></clipPath>
  <clipPath id="l04-bas-${u}"><rect x="0" y="${CY}" width="${L}" height="${H - CY}"/></clipPath>
</defs>
${cadre(`fill="url(#l04-fond-${u})"`)}
<g class="l04-ciel">${etoiles}</g>
<g class="l04-bras"><polyline points="${spirale(.3, 1.15, 46, 190)}" fill="none" stroke="url(#l04-bras-${u})" stroke-width="18" stroke-linecap="round" opacity=".5"/><polyline points="${spirale(.3 + Math.PI, 1.15, 46, 190)}" fill="none" stroke="url(#l04-bras-${u})" stroke-width="18" stroke-linecap="round" opacity=".5"/></g>
<ellipse cx="${CX}" cy="${CY}" rx="122" ry="60" fill="url(#l04-lueur-${u})"/>
${moitie('haut')}
<g class="l04-arc">
  <path d="M${CX - 47} ${CY} A47 47 0 0 1 ${CX + 47} ${CY}" fill="none" stroke="#FF7A1A" stroke-width="13" opacity=".3"/>
  <path d="M${CX - 44} ${CY} A44 44 0 0 1 ${CX + 44} ${CY}" fill="none" stroke="url(#l04-arc-${u})" stroke-width="6"/>
  <path d="M${CX - 41} ${CY} A41 44 0 0 0 ${CX + 41} ${CY}" fill="none" stroke="url(#l04-arc-${u})" stroke-width="2.4" opacity=".7"/>
</g>
<circle cx="${CX}" cy="${CY}" r="35" fill="#000"/>
<circle class="l04-photon" cx="${CX}" cy="${CY}" r="36.2" fill="none" stroke="#FFE7B0" stroke-width="1.7"/>
${moitie('bas')}
${chutes}
<rect x="7" y="7" width="${L - 14}" height="${H - 14}" rx="16" fill="none" stroke="url(#l04-arc-${u})" stroke-width="1.6" opacity=".85"/>
<rect x="12" y="12" width="${L - 24}" height="${H - 24}" rx="12" fill="none" stroke="#7B2FF7" stroke-width=".8" opacity=".6"/>`;
  },
  recto(u) {
    return { fond: cadre('fill="#000"') + semis(26, 3, { r0: .5, r1: 1.2 }).map((e) => `<circle cx="${e.x}" cy="${e.y}" r="${e.r}" fill="#fff" opacity=".5"/>`).join(''),
      bord: `<defs><linearGradient id="tnf-${u}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#FF9F1C"/><stop offset=".5" stop-color="#FFF3D6"/><stop offset="1" stop-color="#7B2FF7"/></linearGradient></defs><rect x="7" y="7" width="${L - 14}" height="${H - 14}" rx="16" fill="none" stroke="url(#tnf-${u})" stroke-width="1.8"/>`,
      centre: `<ellipse cx="125" cy="180" rx="88" ry="26" fill="none" stroke="url(#tnf-${u})" stroke-width="2" opacity=".75" transform="rotate(-14 125 180)"/>` };
  },
};
