// L-003 Jackpot Infini : machine à sous de fantaisie, trois « 7 », pluie de pièces, diamants, signe infini en néon.
import { L, H, cadre, hasard, n } from '../outils.mjs';
const PAS = 46; // hauteur d'un symbole sur un rouleau
const sept = (y) => `<text x="0" y="${y + 15}" text-anchor="middle" font-family="'Alfa Slab One', Georgia, serif" font-size="38" fill="#D81E3A" stroke="#7a0b1c" stroke-width="1">7</text>`;
const diamant = (y, t = 1) => `<g transform="translate(0 ${y}) scale(${t})"><path d="M-13 -5 L-7 -13 H7 L13 -5 L0 14 Z" fill="#7DE3F4" stroke="#0E7490" stroke-width="1.2" stroke-linejoin="round"/><path d="M-13 -5 H13 M-7 -13 L-4 -5 L0 14 L4 -5 L7 -13" fill="none" stroke="#E0FBFF" stroke-width=".9"/></g>`;
const etoile = (y) => `<path transform="translate(0 ${y})" d="M0 -14 L4 -4.5 L14 -4 L6.2 2.4 L9 12.4 L0 6.6 L-9 12.4 L-6.2 2.4 L-14 -4 L-4 -4.5 Z" fill="#F5B301" stroke="#9a6f0f" stroke-width="1" stroke-linejoin="round"/>`;
// un rouleau : 13 symboles, il part d'un 7 et s'arrête sur un 7
const rouleau = () => { const s = []; for (let i = 0; i < 13; i++) { const y = i * PAS; s.push(i % 4 === 0 ? sept(y) : i % 4 === 2 ? etoile(y) : diamant(y)); } return s.join(''); };
const piece = (r) => `<circle r="${r}" fill="#F5B301" stroke="#9a6f0f" stroke-width="1.2"/><circle r="${n(r * .62)}" fill="none" stroke="#FFE27A" stroke-width="1.1"/><path d="M${n(-r * .3)} ${n(-r * .1)} q${n(r * .15)} ${n(-r * .3)} ${n(r * .3)} 0 t${n(r * .3)} 0" fill="none" stroke="#9a6f0f" stroke-width="1"/>`;

export default {
  id: 'L-003', cle: 'l003-jackpot-infini', nom: 'Jackpot Infini', rarete: 'Légendaire', fx: 'jk',
  bouge: 'Les trois rouleaux tournent et s’arrêtent l’un après l’autre sur 7, 7, 7. La manette s’abaisse, les pièces pleuvent en tournant sur elles-mêmes, les diamants étincellent, les ampoules du cadre courent, le signe infini clignote en néon.',
  retournement: 'Éclat doré et petit rebond de la carte.',
  face: { papier: '#FFF9EA', encre: '#17120A', rouge: '#C8102E', sombre: false },
  css: `
.jk-rouleau { animation: jk-tourne 5.6s cubic-bezier(.2, .7, .25, 1) infinite; animation-delay: calc(var(--i) * .45s); }
@keyframes jk-tourne { 0%, 6% { transform: translateY(0); } 62%, 100% { transform: translateY(${-12 * PAS}px); } }
.jk-manette { transform-origin: 207px 178px; animation: jk-manette 5.6s ease-in-out infinite; }
@keyframes jk-manette { 0%, 100% { transform: rotate(0deg); } 4% { transform: rotate(38deg); } 12% { transform: rotate(0deg); } }
.jk-gagne { opacity: 0; animation: jk-gagne 5.6s linear infinite; }
@keyframes jk-gagne { 0%, 74% { opacity: 0; } 77% { opacity: .7; } 81% { opacity: .1; } 85% { opacity: .7; } 89% { opacity: .1; } 93% { opacity: .6; } 100% { opacity: 0; } }
.jk-chute { animation: jk-chute var(--t) linear infinite; animation-delay: var(--d); }
@keyframes jk-chute { from { transform: translateY(-40px); } to { transform: translateY(${H + 40}px); } }
.jk-face { animation: jk-face .7s ease-in-out infinite alternate; animation-delay: var(--d); }
@keyframes jk-face { from { transform: scaleX(1); } to { transform: scaleX(.12); } }
.jk-amp { animation: jk-amp .9s steps(1) infinite; }
.jk-amp.b { animation-delay: -.45s; }
@keyframes jk-amp { 0%, 49% { opacity: 1; } 50%, 100% { opacity: .22; } }
.jk-neon { animation: jk-neon 3.2s linear infinite; }
@keyframes jk-neon { 0%, 100% { opacity: 1; } 46% { opacity: 1; } 48% { opacity: .35; } 50% { opacity: 1; } 53% { opacity: .5; } 55% { opacity: 1; } }
.jk-course { animation: jk-course 2.4s linear infinite; }
@keyframes jk-course { to { stroke-dashoffset: -300; } }
.jk-eclat { transform-box: fill-box; transform-origin: center; animation: jk-eclat 2.2s ease-in-out infinite; animation-delay: var(--d); }
@keyframes jk-eclat { 0%, 100% { transform: scale(0) rotate(0deg); opacity: 0; } 50% { transform: scale(1) rotate(45deg); opacity: 1; } }
`,
  dos(u) {
    const h = hasard(21);
    // ampoules tout autour du cadre
    const amp = []; const pas = 21.4;
    for (let x = 24; x <= L - 24; x += pas) { amp.push([x, 11]); amp.push([x, H - 11]); }
    for (let y = 32; y <= H - 32; y += pas) { amp.push([11, y]); amp.push([L - 11, y]); }
    const ampoules = amp.map(([x, y], i) => `<circle class="jk-amp${i % 2 ? ' b' : ''}" cx="${n(x)}" cy="${n(y)}" r="3.1" fill="#FFF3B0"/>`).join('');
    const pieces = Array.from({ length: 11 }, (_, i) => { const x = 22 + h() * 206, r = 6 + h() * 4, t = 2.4 + h() * 2.2, d = -h() * 5; return `<g class="jk-chute" style="--t:${n(t)}s;--d:${n(d)}s"><g transform="translate(${n(x)} 0)"><g class="jk-face" style="--d:${n(-h())}s">${piece(n(r))}</g></g></g>`; }).join('');
    const tas = [[70, 300, 9], [92, 306, 10], [118, 302, 9], [142, 307, 10], [168, 301, 9], [104, 292, 8], [152, 293, 8], [128, 289, 8]].map(([x, y, r]) => `<g transform="translate(${x} ${y})">${piece(r)}</g>`).join('');
    const eclats = [[38, 96], [214, 84], [30, 228], [222, 244], [125, 318]].map(([x, y], i) => `<path class="jk-eclat" style="--d:${-i * .45}s" d="M${x} ${y - 9} L${x + 2.2} ${y - 2.2} L${x + 9} ${y} L${x + 2.2} ${y + 2.2} L${x} ${y + 9} L${x - 2.2} ${y + 2.2} L${x - 9} ${y} L${x - 2.2} ${y - 2.2} Z" fill="#FFFFFF"/>`).join('');
    const infini = 'M125 60 C108 38 74 40 74 60 C74 80 108 82 125 60 C142 38 176 40 176 60 C176 80 142 82 125 60 Z';
    const fenetre = (i) => `<g clip-path="url(#jk-f${i}-${u})"><g transform="translate(${83 + i * 42} 174)"><g class="jk-rouleau" style="--i:${i}">${rouleau()}</g></g></g>`;
    return `
<defs>
  <radialGradient id="jk-fond-${u}" cx="50%" cy="45%" r="75%"><stop offset="0" stop-color="#7a1426"/><stop offset=".55" stop-color="#3d0a15"/><stop offset="1" stop-color="#170408"/></radialGradient>
  <linearGradient id="jk-or-${u}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFEFA6"/><stop offset=".45" stop-color="#F5B301"/><stop offset="1" stop-color="#9a6f0f"/></linearGradient>
  <linearGradient id="jk-or2-${u}" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#9a6f0f"/><stop offset=".5" stop-color="#FFE27A"/><stop offset="1" stop-color="#9a6f0f"/></linearGradient>
  ${[0, 1, 2].map((i) => `<clipPath id="jk-f${i}-${u}"><rect x="${65 + i * 42}" y="151" width="36" height="46" rx="4"/></clipPath>`).join('')}
</defs>
${cadre(`fill="url(#jk-fond-${u})"`)}
${pieces}
<path d="${infini}" fill="none" stroke="#FF4FA3" stroke-width="11" opacity=".2" class="jk-neon"/>
<path d="${infini}" fill="none" stroke="#FF4FA3" stroke-width="4.4" stroke-linejoin="round" class="jk-neon"/>
<path d="${infini}" fill="none" stroke="#FFE0EE" stroke-width="1.4" class="jk-neon"/>
<path d="${infini}" fill="none" stroke="#FFFFFF" stroke-width="3" stroke-dasharray="26 274" stroke-linecap="round" class="jk-course"/>
<g class="jk-manette"><path d="M207 178 L226 138" stroke="#C9CED6" stroke-width="5" stroke-linecap="round"/><circle cx="227" cy="135" r="9" fill="#E11D48" stroke="#7a0b1c" stroke-width="1.4"/><circle cx="224" cy="132" r="2.6" fill="#FFC2CF"/></g>
<rect x="199" y="166" width="12" height="24" rx="3" fill="#9a6f0f"/>
<path d="M52 126 Q125 92 198 126 V250 Q198 262 186 262 H64 Q52 262 52 250 Z" fill="url(#jk-or-${u})" stroke="#7a5510" stroke-width="2"/>
<path d="M62 128 Q125 102 188 128" fill="none" stroke="#FFF6CC" stroke-width="2" opacity=".8"/>
<text x="125" y="138" text-anchor="middle" font-family="'Alfa Slab One', Georgia, serif" font-size="17" fill="#B0122B" letter-spacing="1.5">JACKPOT</text>
<rect x="59" y="145" width="132" height="58" rx="8" fill="#1b0f12" stroke="#7a5510" stroke-width="2"/>
${[0, 1, 2].map((i) => `<rect x="${65 + i * 42}" y="151" width="36" height="46" rx="4" fill="#FFF8E7"/>`).join('')}
${fenetre(0)}${fenetre(1)}${fenetre(2)}
${[0, 1, 2].map((i) => `<rect x="${65 + i * 42}" y="151" width="36" height="46" rx="4" fill="none" stroke="#3a2a10" stroke-width="1.4"/><rect class="jk-gagne" x="${65 + i * 42}" y="151" width="36" height="46" rx="4" fill="#FFE27A"/>`).join('')}
<path d="M59 174 H191" stroke="#E11D48" stroke-width="1" opacity=".7"/>
<rect x="72" y="214" width="106" height="12" rx="6" fill="url(#jk-or2-${u})" stroke="#7a5510" stroke-width="1"/>
<rect x="78" y="234" width="94" height="17" rx="8.5" fill="#1b0f12" stroke="#7a5510" stroke-width="1.6"/>
${tas}
<g transform="translate(34 150)">${diamant(0, 1.25)}</g><g transform="translate(216 214)">${diamant(0, 1.1)}</g><g transform="translate(36 262)">${diamant(0, .9)}</g>
${eclats}
<rect x="4.5" y="4.5" width="${L - 9}" height="${H - 9}" rx="18" fill="none" stroke="url(#jk-or-${u})" stroke-width="13" opacity=".95"/>
<rect x="4.5" y="4.5" width="${L - 9}" height="${H - 9}" rx="18" fill="none" stroke="#7a5510" stroke-width="1"/>
${ampoules}`;
  },
  recto(u) {
    const d = (x, y) => `<g transform="translate(${x} ${y}) scale(.72)"><path d="M-13 -5 L-7 -13 H7 L13 -5 L0 14 Z" fill="#7DE3F4" stroke="#0E7490" stroke-width="1.4" stroke-linejoin="round"/><path d="M-13 -5 H13" stroke="#E0FBFF" stroke-width="1"/></g>`;
    return { fond: `<defs><linearGradient id="jkf-${u}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFEFA6"/><stop offset=".5" stop-color="#F5B301"/><stop offset="1" stop-color="#9a6f0f"/></linearGradient></defs>${cadre('fill="#FFF9EA"')}`,
      bord: `<rect x="5" y="5" width="${L - 10}" height="${H - 10}" rx="18" fill="none" stroke="url(#jkf-${u})" stroke-width="9"/><rect x="12" y="12" width="${L - 24}" height="${H - 24}" rx="12" fill="none" stroke="#9a6f0f" stroke-width="1"/>`,
      dessus: d(212, 36) + d(38, 314) };
  },
};
