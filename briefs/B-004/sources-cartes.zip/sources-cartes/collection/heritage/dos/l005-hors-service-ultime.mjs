// L-005 Hors Service Ultime : le skin emblème. Noir laqué, or, néon, le nom de l'appli qui s'allume lettre par lettre.
import { L, H, cadre } from '../outils.mjs';
const lettres = (mot, x0, pas, depart) => mot.split('').map((c, i) => `<tspan class="hu-l" style="--i:${depart + i}" x="${x0 + i * pas}">${c}</tspan>`).join('');
// le même texte posé en plusieurs épaisseurs : un tube éteint, un halo, le tube allumé, le cœur blanc
const neon = (y, taille, contenu) => `
  <text y="${y}" font-family="'Alfa Slab One', Georgia, serif" font-size="${taille}" text-anchor="middle" fill="none" stroke="#4a3c14" stroke-width="2.4" stroke-linejoin="round">${contenu.replace(/class="hu-l"/g, '')}</text>
  <text y="${y}" font-family="'Alfa Slab One', Georgia, serif" font-size="${taille}" text-anchor="middle" fill="none" stroke="#FFC93C" stroke-width="11" stroke-linejoin="round" opacity=".16">${contenu}</text>
  <text y="${y}" font-family="'Alfa Slab One', Georgia, serif" font-size="${taille}" text-anchor="middle" fill="none" stroke="#FFC93C" stroke-width="6" stroke-linejoin="round" opacity=".3">${contenu}</text>
  <text y="${y}" font-family="'Alfa Slab One', Georgia, serif" font-size="${taille}" text-anchor="middle" fill="none" stroke="#FFD76A" stroke-width="2.6" stroke-linejoin="round">${contenu}</text>
  <text y="${y}" font-family="'Alfa Slab One', Georgia, serif" font-size="${taille}" text-anchor="middle" fill="none" stroke="#FFFBEA" stroke-width=".9" stroke-linejoin="round">${contenu}</text>`;
const bande = (u, y, sens) => `
  <g clip-path="url(#hu-b${sens}-${u})"><rect class="hu-ruban${sens > 0 ? '' : ' inv'}" x="-60" y="${y}" width="${L + 120}" height="24" fill="url(#hu-ruban-${u})"/></g>
  <path d="M10 ${y} H${L - 10} M10 ${y + 24} H${L - 10}" stroke="#F3D57A" stroke-width="1.4"/>`;

export default {
  id: 'L-005', cle: 'l005-hors-service-ultime', nom: 'Hors Service Ultime', rarete: 'Légendaire', fx: 'hu',
  bouge: 'Le néon doré s’allume lettre par lettre, grésille, puis s’éteint et recommence. Les deux rubalises dorées défilent en sens contraire, le voyant rouge clignote, un reflet d’or balaie la carte.',
  retournement: 'Le néon claque : flash blanc et or.',
  face: { papier: '#0B0B0B', encre: '#F6F1E4', rouge: '#FF4D6A', sombre: true },
  css: `
.hu-l { stroke-opacity: 1; animation: hu-lettre 6.4s linear infinite; animation-delay: calc(var(--i) * .17s); }
@keyframes hu-lettre { 0% { stroke-opacity: 0; } 2% { stroke-opacity: 1; } 4% { stroke-opacity: .25; } 6%, 52% { stroke-opacity: 1; } 53% { stroke-opacity: .2; } 55% { stroke-opacity: 1; } 56.5% { stroke-opacity: .35; } 58%, 80% { stroke-opacity: 1; } 84%, 100% { stroke-opacity: 0; } }
.hu-ruban { animation: hu-defile 1.5s linear infinite; }
.hu-ruban.inv { animation-direction: reverse; }
@keyframes hu-defile { to { transform: translateX(28px); } }
.hu-voyant { animation: hu-voyant 1.2s steps(1) infinite; }
@keyframes hu-voyant { 0%, 55% { opacity: 1; } 56%, 100% { opacity: .15; } }
.hu-reflet { animation: hu-reflet 5.4s ease-in-out infinite; }
@keyframes hu-reflet { 0%, 55% { transform: translateX(-260px) skewX(-18deg); } 85%, 100% { transform: translateX(330px) skewX(-18deg); } }
.hu-cadre { animation: hu-cadre 6.4s linear infinite; }
@keyframes hu-cadre { 0%, 30% { opacity: .55; } 40%, 80% { opacity: 1; } 90%, 100% { opacity: .55; } }
`,
  dos(u) {
    return `
<defs>
  <radialGradient id="hu-fond-${u}" cx="50%" cy="46%" r="70%"><stop offset="0" stop-color="#1d1a12"/><stop offset=".55" stop-color="#0d0c09"/><stop offset="1" stop-color="#050505"/></radialGradient>
  <linearGradient id="hu-or-${u}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#FFF1B8"/><stop offset=".35" stop-color="#D4AF37"/><stop offset=".7" stop-color="#8C6B1A"/><stop offset="1" stop-color="#F3D57A"/></linearGradient>
  <pattern id="hu-ruban-${u}" width="28" height="24" patternUnits="userSpaceOnUse" patternTransform="skewX(-28)"><rect width="14" height="24" fill="#D4AF37"/><rect x="14" width="14" height="24" fill="#0b0b0b"/></pattern>
  <clipPath id="hu-b1-${u}"><rect x="10" y="26" width="${L - 20}" height="24"/></clipPath>
  <clipPath id="hu-b-1-${u}"><rect x="10" y="${H - 50}" width="${L - 20}" height="24"/></clipPath>
  <linearGradient id="hu-reflet-${u}" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#FFE9A8" stop-opacity="0"/><stop offset=".5" stop-color="#FFF6D6" stop-opacity=".34"/><stop offset="1" stop-color="#FFE9A8" stop-opacity="0"/></linearGradient>
</defs>
${cadre(`fill="url(#hu-fond-${u})"`)}
${bande(u, 26, 1)}${bande(u, H - 50, -1)}
<rect class="hu-cadre" x="26" y="92" width="${L - 52}" height="150" rx="14" fill="none" stroke="#D4AF37" stroke-width="1.4"/>
<path d="M60 50 V92 M190 50 V92" stroke="#8C6B1A" stroke-width="1.6"/>
<circle cx="60" cy="92" r="3" fill="#D4AF37"/><circle cx="190" cy="92" r="3" fill="#D4AF37"/>
${neon(158, 60, lettres('HORS', 54.5, 47, 0))}
${neon(212, 34.5, lettres('SERVICE', 48.5, 25.5, 4))}
<g transform="translate(125 268)">
  <path d="M-70 0 H-24 M24 0 H70" stroke="#D4AF37" stroke-width="1.2"/>
  <circle r="15" fill="#FF2E3D" opacity=".16" class="hu-voyant"/><circle r="8" fill="#3a0a0d" stroke="#8C6B1A" stroke-width="1.4"/><circle r="5.2" fill="#FF2E3D" class="hu-voyant"/><circle cx="-1.6" cy="-1.8" r="1.5" fill="#FFD0D0" class="hu-voyant"/>
</g>
<rect class="hu-reflet" x="0" y="-20" width="90" height="${H + 40}" fill="url(#hu-reflet-${u})"/>
<rect x="7" y="7" width="${L - 14}" height="${H - 14}" rx="16" fill="none" stroke="url(#hu-or-${u})" stroke-width="3"/>
<rect x="13.5" y="13.5" width="${L - 27}" height="${H - 27}" rx="11" fill="none" stroke="#D4AF37" stroke-width=".9" opacity=".8"/>`;
  },
  recto(u) {
    return { fond: `<defs><radialGradient id="huf-${u}" cx="50%" cy="50%" r="72%"><stop offset="0" stop-color="#1a1710"/><stop offset="1" stop-color="#060606"/></radialGradient><linearGradient id="huo-${u}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#FFF1B8"/><stop offset=".4" stop-color="#D4AF37"/><stop offset="1" stop-color="#8C6B1A"/></linearGradient></defs>${cadre(`fill="url(#huf-${u})"`)}`,
      bord: `<rect x="7" y="7" width="${L - 14}" height="${H - 14}" rx="16" fill="none" stroke="url(#huo-${u})" stroke-width="2.6"/><rect x="13.5" y="13.5" width="${L - 27}" height="${H - 27}" rx="11" fill="none" stroke="#D4AF37" stroke-width=".8" opacity=".7"/>`,
      dessus: `<g font-family="'Alfa Slab One', Georgia, serif" font-size="13" fill="#D4AF37" text-anchor="middle"><text x="206" y="34">HS</text><text x="206" y="34" transform="rotate(180 125 175)">HS</text></g>` };
  },
};
