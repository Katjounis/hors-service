// Outils communs au premier jet des skins de cartes : enseignes de l'appli, hasard rejouable, petites fabriques SVG.
export const L = 250, H = 350, R = 22; // carte en 5 × 7, coins arrondis
// Les quatre enseignes telles qu'elles sont dessinées dans l'appli (boîte de 24 × 24)
export const ENSEIGNES = {
  H: 'M12 21.6 C5 16 1.4 12.3 1.4 7.9 C1.4 4.6 3.9 2.4 6.8 2.4 C9 2.4 11 3.7 12 5.8 C13 3.7 15 2.4 17.2 2.4 C20.1 2.4 22.6 4.6 22.6 7.9 C22.6 12.3 19 16 12 21.6 Z',
  D: 'M12 1.2 C14.4 4.8 17.4 8.6 20.6 12 C17.4 15.4 14.4 19.2 12 22.8 C9.6 19.2 6.6 15.4 3.4 12 C6.6 8.6 9.6 4.8 12 1.2 Z',
  S: 'M12 1.4 C9.2 5.8 2.4 9.4 2.4 14 C2.4 16.9 4.6 18.7 7 18.7 C8.8 18.7 10.2 17.9 11 16.7 C10.8 19.1 10 20.8 8.2 22.6 L15.8 22.6 C14 20.8 13.2 19.1 13 16.7 C13.8 17.9 15.2 18.7 17 18.7 C19.4 18.7 21.6 16.9 21.6 14 C21.6 9.4 14.8 5.8 12 1.4 Z',
  C: 'M12 1.8 C14.6 1.8 16.6 3.8 16.6 6.4 C16.6 7.3 16.4 8.1 16 8.8 C16.6 8.6 17.2 8.5 17.8 8.5 C20.4 8.5 22.4 10.5 22.4 13.1 C22.4 15.7 20.4 17.7 17.8 17.7 C16.2 17.7 14.8 16.9 13.9 15.7 C14 18.5 14.9 20.6 16.6 22.6 L7.4 22.6 C9.1 20.6 10 18.5 10.1 15.7 C9.2 16.9 7.8 17.7 6.2 17.7 C3.6 17.7 1.6 15.7 1.6 13.1 C1.6 10.5 3.6 8.5 6.2 8.5 C6.8 8.5 7.4 8.6 8 8.8 C7.6 8.1 7.4 7.3 7.4 6.4 C7.4 3.8 9.4 1.8 12 1.8 Z',
};
export const ROUGE = { H: true, D: true, S: false, C: false };
export const NOM_ENSEIGNE = { H: 'cœur', D: 'carreau', S: 'pique', C: 'trèfle' };
// hasard rejouable (mêmes dessins à chaque fabrication)
export function hasard(graine) { let x = graine >>> 0 || 1; return () => { x ^= x << 13; x >>>= 0; x ^= x >>> 17; x ^= x << 5; x >>>= 0; return x / 4294967296; }; }
export const n = (v, d = 1) => Number(v.toFixed(d));
// enseigne placée et mise à l'échelle : centre (cx, cy), taille t
export const enseigne = (e, cx, cy, t, attrs = '') => `<path d="${ENSEIGNES[e]}" transform="translate(${n(cx - t / 2)} ${n(cy - t / 2)}) scale(${n(t / 24, 3)})" ${attrs}/>`;
// rectangle de la carte
export const cadre = (attrs = '') => `<rect x="0" y="0" width="${L}" height="${H}" rx="${R}" ${attrs}/>`;
// points semés au hasard (étoiles, braises, bulles) : rend une liste de { x, y, r, d, t }
export function semis(nb, graine, { x0 = 8, x1 = L - 8, y0 = 8, y1 = H - 8, r0 = 0.6, r1 = 1.8, duree = [2, 5] } = {}) {
  const h = hasard(graine); const out = [];
  for (let i = 0; i < nb; i++) out.push({ x: n(x0 + h() * (x1 - x0)), y: n(y0 + h() * (y1 - y0)), r: n(r0 + h() * (r1 - r0), 2), d: n(-h() * duree[1], 2), t: n(duree[0] + h() * (duree[1] - duree[0]), 2) });
  return out;
}
// éclair en zigzag de (x0, y0) à (x1, y1)
export function zigzag(x0, y0, x1, y1, pas, ecart, graine) {
  const h = hasard(graine); const pts = [[x0, y0]]; const dx = x1 - x0, dy = y1 - y0, long = Math.hypot(dx, dy), nx = -dy / long, ny = dx / long;
  for (let i = 1; i < pas; i++) { const k = i / pas, e = (h() - 0.5) * 2 * ecart * (i % 2 ? 1 : -0.7); pts.push([n(x0 + dx * k + nx * e), n(y0 + dy * k + ny * e)]); }
  pts.push([x1, y1]); return pts.map((p) => p.join(',')).join(' ');
}
// Places des enseignes sur les cartes à chiffres (2 à 10), calées pour ne pas toucher les deux coins de l'appli.
// Rend une liste de { x, y, t, bas } : centre, taille, et « bas » quand l'enseigne est tête en bas (moitié basse).
export function semisEnseignes(rang) {
  const t = rang <= 3 ? 54 : rang <= 6 ? 42 : rang <= 8 ? 36 : 32;
  const dx = rang <= 6 ? 26 : rang <= 8 ? 28 : 30; const G = 125 - dx, C = 125, D = 125 + dx, M = 175;
  const P = {
    2: [[C, 96], [C, 254]],
    3: [[C, 74], [C, M], [C, 276]],
    4: [[G, 92], [D, 92], [G, 258], [D, 258]],
    5: [[G, 88], [D, 88], [C, M], [G, 262], [D, 262]],
    6: [[G, 72], [D, 72], [G, M], [D, M], [G, 278], [D, 278]],
    7: [[G, 68], [D, 68], [C, 121], [G, M], [D, M], [G, 282], [D, 282]],
    8: [[G, 68], [D, 68], [C, 121], [G, M], [D, M], [C, 229], [G, 282], [D, 282]],
    9: [[G, 64], [D, 64], [G, 138], [D, 138], [C, M], [G, 212], [D, 212], [G, 286], [D, 286]],
    10: [[G, 64], [D, 64], [C, 101], [G, 138], [D, 138], [G, 212], [D, 212], [C, 249], [G, 286], [D, 286]],
  }[rang];
  return P.map(([x, y]) => ({ x, y, t, bas: y > M + 1 }));
}
// étoile à quatre branches (éclat de lumière), centrée en (0, 0)
export const eclat4 = (r, fin = .22) => `M0 ${-r} L${n(r * fin)} ${n(-r * fin)} L${r} 0 L${n(r * fin)} ${n(r * fin)} L0 ${r} L${n(-r * fin)} ${n(r * fin)} L${-r} 0 L${n(-r * fin)} ${n(-r * fin)} Z`;
// range les points en chaîne, du plus proche au plus proche (pour faire sauter un éclair d'enseigne en enseigne)
export function chaine(points) { const reste = points.slice(); const ch = [reste.shift()]; while (reste.length) { const d = ch[ch.length - 1]; reste.sort((a, b) => Math.hypot(a.x - d.x, a.y - d.y) - Math.hypot(b.x - d.x, b.y - d.y)); ch.push(reste.shift()); } return ch; }
// miroir gauche-droite autour de l'axe de la carte
export const miroir = (dedans) => `<g transform="translate(${L} 0) scale(-1 1)">${dedans}</g>`;
