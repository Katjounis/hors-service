// E-007 Océan abyssal (épique) : méduse lumineuse dans le noir des grands fonds. Au recto, le roi est une pieuvre, la dame une méduse,
// le valet un poisson ; chaque enseigne est enfermée dans une bulle qui flotte.
import { L, H, cadre, hasard, n, enseigne, miroir } from '../outils.mjs';
const CYAN = '#3CF2FF', ROSE = '#FF5DA2', PALE = '#EAFBFF', OR = '#FFD76A', ENCRE = '#052235';
const defs = (u) => `<defs><linearGradient id="oaf-${u}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0a4a6e"/><stop offset=".45" stop-color="#06304a"/><stop offset="1" stop-color="#020c18"/></linearGradient>
<linearGradient id="oar-${u}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#BDFBFF" stop-opacity=".34"/><stop offset="1" stop-color="#BDFBFF" stop-opacity="0"/></linearGradient>
<radialGradient id="oam-${u}" cx="50%" cy="35%" r="75%"><stop offset="0" stop-color="#E6FEFF" stop-opacity=".95"/><stop offset=".5" stop-color="${CYAN}" stop-opacity=".7"/><stop offset="1" stop-color="#1287A6" stop-opacity=".6"/></radialGradient>
<radialGradient id="oap-${u}" cx="45%" cy="30%" r="80%"><stop offset="0" stop-color="#FF9CCB"/><stop offset=".55" stop-color="#D23B86"/><stop offset="1" stop-color="#6B1548"/></radialGradient>
<radialGradient id="oac-${u}" cx="40%" cy="30%" r="80%"><stop offset="0" stop-color="#FFB37A"/><stop offset=".6" stop-color="#FF6B3D"/><stop offset="1" stop-color="#B5361A"/></radialGradient>
<radialGradient id="oal-${u}"><stop offset="0" stop-color="${CYAN}" stop-opacity=".6"/><stop offset="1" stop-color="${CYAN}" stop-opacity="0"/></radialGradient>
<linearGradient id="oao-${u}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFF1B8"/><stop offset="1" stop-color="#D49A1E"/></linearGradient></defs>`;
const bulles = (nb, g) => { const h = hasard(g); return Array.from({ length: nb }, () => `<circle class="oa-bulle" style="--x:${n(14 + h() * 222)}px;--t:${n(4 + h() * 4)}s;--d:${n(-h() * 8)}s" r="${n(1.6 + h() * 3)}" fill="rgba(189,251,255,.12)" stroke="${PALE}" stroke-width=".8"/>`).join(''); };
const rayons = (u) => [[40, -8], [118, 6], [186, -4]].map(([x, a], i) => `<path class="oa-rayon" style="--i:${i}" d="M${x} -10 L${x + 34} -10 L${x + 70 + a * 3} 300 L${x - 30 + a * 3} 300 Z" fill="url(#oar-${u})"/>`).join('');
const algues = [[22, 70, 0], [44, 46, 1], [206, 52, 2], [228, 78, 3], [70, 30, 4], [182, 34, 5]].map(([x, h, i]) => `<g transform="translate(${x} 350)"><path class="oa-algue" style="--i:${i}" d="M0 0 C-10 ${-h * .3} 10 ${-h * .6} 0 ${-h} C12 ${-h * .6} -6 ${-h * .3} 6 0 Z" fill="${i % 2 ? '#0f7f72' : '#0b5f6a'}"/></g>`).join('');
const fond = (u, g) => `${defs(u)}${cadre(`fill="url(#oaf-${u})"`)}${rayons(u)}${algues}${bulles(7, g)}`;
const bord = `<rect x="7" y="7" width="${L - 14}" height="${H - 14}" rx="16" fill="none" stroke="${CYAN}" stroke-width="2" opacity=".9"/><rect x="12.5" y="12.5" width="${L - 25}" height="${H - 25}" rx="12" fill="none" stroke="${ROSE}" stroke-width=".9" opacity=".7"/>`;
const couronne = (u, y = 0) => `<g transform="translate(0 ${y})"><path d="M103 110 L98 82 L111 97 L125 74 L139 97 L152 82 L147 110 Z" fill="url(#oao-${u})" stroke="#7a5200" stroke-width="1.3" stroke-linejoin="round"/><rect x="102" y="104" width="46" height="9" rx="2" fill="${OR}" stroke="#7a5200" stroke-width="1.1"/><circle cx="125" cy="108.500" r="2.6" fill="${ROSE}"/></g>`;
const diademe = (u) => `<path d="M107 114 L111 96 L119 107 L125 88 L131 107 L139 96 L143 114 Q125 105 107 114 Z" fill="url(#oao-${u})" stroke="#7a5200" stroke-width="1.2" stroke-linejoin="round"/><circle cx="125" cy="87" r="3" fill="${PALE}"/>`;
const medaillon = (c) => `<circle cx="125" cy="318" r="20" fill="#031424" stroke="${CYAN}" stroke-width="1.8"/>${enseigne(c.ens, 125, 318, 25, `fill="${c.encre}"`)}`;
// la méduse : cloche qui bat, filaments qui ondulent
const meduse = (u, visage, extra = '') => { const fil = (d, i, coul = CYAN, w = 2.6) => `<path class="oa-filament" style="--i:${i}" d="${d}" fill="none" stroke="${coul}" stroke-width="${w}" stroke-linecap="round" opacity=".85"/>`;
  return `<circle cx="125" cy="170" r="92" fill="url(#oal-${u})"/>
${fil('M86 184 C76 218 96 240 84 276 C78 296 90 310 86 326', 0)}${fil('M164 184 C174 218 154 240 166 276 C172 296 160 310 164 326', 1)}${fil('M106 186 C100 222 112 246 104 284 C100 302 108 316 106 330', 2, ROSE, 5)}${fil('M144 186 C150 222 138 246 146 284 C150 302 142 316 144 330', 3, ROSE, 5)}${fil('M125 186 C121 226 129 252 125 296', 4)}
<g class="oa-cloche"><path d="M70 176 C70 104 180 104 180 176 C170 188 160 178 150 190 C140 178 132 190 125 180 C118 190 110 178 100 190 C90 178 80 188 70 176 Z" fill="url(#oam-${u})" stroke="${PALE}" stroke-width="1.5" stroke-linejoin="round"/>
<path d="M88 150 C92 126 110 116 125 116" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round" opacity=".7"/><circle cx="150" cy="140" r="5" fill="#fff" opacity=".35"/><circle cx="160" cy="158" r="3" fill="#fff" opacity=".35"/>
${visage ? `<path d="M105 156 q7 6 14 0 M131 156 q7 6 14 0" fill="none" stroke="${ENCRE}" stroke-width="2.2" stroke-linecap="round"/><path d="M118 168 Q125 174 132 168" fill="none" stroke="${ENCRE}" stroke-width="2" stroke-linecap="round"/><circle cx="102" cy="166" r="5" fill="${ROSE}" opacity=".55"/><circle cx="148" cy="166" r="5" fill="${ROSE}" opacity=".55"/>` : ''}${extra}</g>`; };
const pieuvre = (c) => { const u = c.u; const t = (d, i) => `<g class="oa-tentacule" style="--i:${i}"><path d="${d}" fill="none" stroke="#8a1f5c" stroke-width="18" stroke-linecap="round"/><path d="${d}" fill="none" stroke="#D23B86" stroke-width="14" stroke-linecap="round"/><path d="${d}" fill="none" stroke="#FFC2DD" stroke-width="3.2" stroke-linecap="round" stroke-dasharray=".1 9" opacity=".85"/></g>`;
  const g = t('M96 198 C70 218 42 212 32 240 C26 260 44 272 54 262', 0) + t('M106 206 C92 240 60 250 56 286 C54 306 72 314 80 300', 1) + t('M118 210 C114 248 98 268 100 300', 2);
  return `<circle cx="125" cy="166" r="96" fill="url(#oal-${u})"/>${g}${miroir(g.replace(/--i:(\d)/g, (m, d) => `--i:${Number(d) + 3}`))}
<path d="M210 256 L216 100" stroke="#7a5200" stroke-width="6" stroke-linecap="round"/><path d="M210 256 L216 100" stroke="url(#oao-${u})" stroke-width="3.4" stroke-linecap="round"/><path d="M201 118 L203 90 M216 114 L217 78 M231 118 L230 90 M201 118 Q216 132 231 118" fill="none" stroke="${OR}" stroke-width="3.6" stroke-linecap="round"/>
<g class="oa-nage"><path d="M125 104 C170 104 184 150 174 188 C168 208 148 216 125 216 C102 216 82 208 76 188 C66 150 80 104 125 104 Z" fill="url(#oap-${u})" stroke="#4a0d33" stroke-width="1.6"/>
<circle cx="150" cy="130" r="6" fill="#FFC2DD" opacity=".5"/><circle cx="160" cy="148" r="3.6" fill="#FFC2DD" opacity=".5"/><circle cx="96" cy="136" r="4" fill="#FFC2DD" opacity=".4"/>
<ellipse cx="110" cy="168" rx="10" ry="12" fill="#fff" stroke="#4a0d33" stroke-width="1.1"/><ellipse cx="140" cy="168" rx="10" ry="12" fill="#fff" stroke="#4a0d33" stroke-width="1.1"/><circle cx="112" cy="170" r="5" fill="${ENCRE}"/><circle cx="142" cy="170" r="5" fill="${ENCRE}"/><circle cx="113.600" cy="168" r="1.6" fill="#fff"/><circle cx="143.600" cy="168" r="1.6" fill="#fff"/>
<path d="M98 154 L122 158 M152 154 L128 158" stroke="#4a0d33" stroke-width="2.4" stroke-linecap="round"/><path d="M116 192 Q125 199 134 192" fill="none" stroke="#4a0d33" stroke-width="2" stroke-linecap="round"/>${couronne(u, -2)}</g>`; };
const poisson = (c) => { const u = c.u;
  return `<circle cx="125" cy="172" r="92" fill="url(#oal-${u})"/>
<g class="oa-nage"><g class="oa-queue"><path d="M166 172 L206 142 L198 172 L206 202 Z" fill="url(#oac-${u})" stroke="#7a2410" stroke-width="1.4" stroke-linejoin="round"/></g>
<path d="M112 138 C120 112 150 114 156 142 Z" fill="url(#oac-${u})" stroke="#7a2410" stroke-width="1.3"/>
<ellipse cx="125" cy="174" rx="48" ry="39" fill="url(#oac-${u})" stroke="#7a2410" stroke-width="1.6"/>
<path d="M118 136 C110 160 110 190 118 212 L130 212 C122 190 122 160 130 136 Z M146 142 C140 162 140 188 146 206 L156 200 C150 186 150 164 156 148 Z" fill="#fff" stroke="#7a2410" stroke-width="1.1"/>
<g class="oa-nageoire"><path d="M126 186 L150 204 L128 208 Z" fill="#FFB37A" stroke="#7a2410" stroke-width="1.1" stroke-linejoin="round"/></g>
<circle cx="98" cy="166" r="12" fill="#fff" stroke="#7a2410" stroke-width="1.2"/><circle cx="95" cy="167" r="6" fill="${ENCRE}"/><circle cx="93" cy="165" r="1.8" fill="#fff"/><path d="M82 186 Q90 194 100 190" fill="none" stroke="#7a2410" stroke-width="2" stroke-linecap="round"/>
<path d="M92 142 C96 122 138 116 150 134 Z" fill="#1d6fb8" stroke="${ENCRE}" stroke-width="1.2"/><path d="M90 144 H152" stroke="${PALE}" stroke-width="3" stroke-linecap="round"/><circle cx="121" cy="122" r="5" fill="${PALE}" stroke="${ENCRE}" stroke-width="1"/></g>
${[[72, 176, 3.4, 0], [62, 160, 4.6, 1], [70, 140, 2.8, 2]].map(([x, y, r, i]) => `<g transform="translate(${x} ${y})"><circle class="oa-souffle" style="--i:${i}" r="${r}" fill="rgba(189,251,255,.15)" stroke="${PALE}" stroke-width="1"/></g>`).join('')}
<path d="M40 350 C52 306 86 296 110 318 C126 300 168 296 196 320 C208 330 212 342 214 350 Z" fill="#0b3a4a" stroke="#0f7f72" stroke-width="1.2"/><path d="M60 350 C58 330 70 318 66 302 M188 350 C192 330 180 322 186 306" fill="none" stroke="${ROSE}" stroke-width="4" stroke-linecap="round" opacity=".8"/>`; };

export default {
  id: 'E-007', cle: 'e007-ocean-abyssal', nom: 'Océan abyssal', rarete: 'Épique', fx: 'oa', aura: ['#3CF2FF', '#FF5DA2'],
  bouge: 'La cloche de la méduse bat, ses filaments ondulent, les bulles montent, la lumière tombe d’en haut. Au recto, le roi est une pieuvre couronnée, la dame une méduse, le valet un poisson ; chaque enseigne flotte dans sa bulle.',
  retournement: 'Une onde bleue et une volée de bulles.',
  face: { papier: '#031424', encre: '#EAFBFF', rouge: '#FF6B6B', sombre: true, contour: '#031424', contourEp: 6, onglet: '#031424', ongletOp: 0.5 },
  css: `
.oa-bulle { opacity: 0; animation: oa-bulle var(--t) linear infinite; animation-delay: var(--d); }
@keyframes oa-bulle { 0% { transform: translate(var(--x), 356px); opacity: 0; } 10% { opacity: .9; } 50% { transform: translate(calc(var(--x) + 7px), 186px); } 100% { transform: translate(calc(var(--x) - 5px), 10px); opacity: 0; } }
.oa-rayon { animation: oa-rayon 5s ease-in-out infinite alternate; animation-delay: calc(var(--i) * -1.6s); }
@keyframes oa-rayon { from { opacity: .35; } to { opacity: 1; } }
.oa-algue { animation: oa-algue 3.6s ease-in-out infinite alternate; animation-delay: calc(var(--i) * -.6s); }
@keyframes oa-algue { from { transform: skewX(-9deg); } to { transform: skewX(9deg); } }
.oa-cloche { transform-origin: 125px 178px; animation: oa-cloche 2.4s ease-in-out infinite; }
@keyframes oa-cloche { 0%, 100% { transform: translateY(2px) scale(1.04, .93); } 45% { transform: translateY(-5px) scale(.95, 1.06); } }
.oa-filament { transform-origin: 125px 186px; animation: oa-filament 2.4s ease-in-out infinite alternate; animation-delay: calc(var(--i) * -.35s); }
@keyframes oa-filament { from { transform: skewX(-5deg) scaleY(.96); } to { transform: skewX(5deg) scaleY(1.05); } }
.oa-tentacule { transform-origin: 125px 196px; animation: oa-tentacule 3s ease-in-out infinite alternate; animation-delay: calc(var(--i) * -.5s); }
@keyframes oa-tentacule { from { transform: rotate(-5deg); } to { transform: rotate(5deg); } }
.oa-nage { animation: oa-nage 4s ease-in-out infinite alternate; }
@keyframes oa-nage { from { transform: translateY(2px); } to { transform: translateY(-5px); } }
.oa-queue { transform-origin: 166px 172px; animation: oa-queue .7s ease-in-out infinite alternate; }
@keyframes oa-queue { from { transform: rotate(-12deg); } to { transform: rotate(12deg); } }
.oa-nageoire { transform-origin: 126px 190px; animation: oa-queue .5s ease-in-out infinite alternate; }
.oa-souffle { opacity: 0; animation: oa-souffle 2.4s ease-out infinite; animation-delay: calc(var(--i) * -.8s); }
@keyframes oa-souffle { 0% { transform: translate(18px, 14px) scale(.4); opacity: 0; } 20% { opacity: 1; } 100% { transform: translate(-10px, -46px) scale(1.2); opacity: 0; } }
.oa-flotte { animation: oa-nage 3.2s ease-in-out infinite alternate; animation-delay: calc(var(--i) * -.37s); }
.oa-ronde { transform-origin: 125px 176px; animation: oa-ronde 24s linear infinite; }
@keyframes oa-ronde { to { transform: rotate(360deg); } }
.oa-leurre { transform-origin: 196px 286px; animation: oa-leurre 2.2s ease-in-out infinite; }
@keyframes oa-leurre { 0%, 100% { transform: scale(.7); opacity: .5; } 50% { transform: scale(1.3); opacity: 1; } }
.oa-banc { animation: oa-banc 14s linear infinite; }
@keyframes oa-banc { from { transform: translateX(-90px); } to { transform: translateX(300px); } }
`,
  dos(u) {
    const petit = (x, y, k, i) => `<g transform="translate(${x} ${y}) scale(${k})"><g class="oa-flotte" style="--i:${i}"><path d="M-20 0 C-20 -26 20 -26 20 0 C14 5 8 0 4 6 C0 0 -4 6 -8 0 C-12 5 -16 4 -20 0 Z" fill="url(#oam-${u})" stroke="${PALE}" stroke-width="1"/><path d="M-10 4 C-14 18 -6 26 -10 40 M0 6 C-3 20 3 30 0 44 M10 4 C14 18 6 26 10 40" fill="none" stroke="${ROSE}" stroke-width="1.6" stroke-linecap="round" opacity=".8"/></g></g>`;
    const banc = Array.from({ length: 6 }, (_, i) => `<path transform="translate(${(i % 3) * 16} ${Math.floor(i / 3) * 10 + (i % 2) * 4})" d="M0 0 C4 -4 10 -4 14 0 L19 -4 V4 L14 0 C10 4 4 4 0 0 Z" fill="#0b5f6a"/>`).join('');
    return `${fond(u, 4)}<g transform="translate(0 78)"><g class="oa-banc">${banc}</g></g>
${petit(48, 92, .8, 2)}${petit(204, 250, .66, 5)}${meduse(u, false)}
<path d="M250 320 C226 300 196 304 176 322 C196 340 226 344 250 326 Z" fill="#010810"/><path d="M186 314 C186 300 192 292 196 288" fill="none" stroke="#010810" stroke-width="2.4"/><circle class="oa-leurre" cx="196" cy="286" r="6" fill="${OR}"/><circle cx="196" cy="286" r="2.6" fill="#fff"/><circle cx="198" cy="318" r="2.4" fill="${OR}"/>
${bulles(8, 9)}${bord}`;
  },
  recto(c) { return { fond: fond(c.u, 2 + c.num), bord, devant: bulles(6, 30 + c.num) }; },
  pip(c, p, i) {
    const r = n(p.t / 2 + 5);
    return `<g transform="translate(${p.x} ${p.y})"><g class="oa-flotte" style="--i:${i}"><circle r="${r}" fill="rgba(60,242,255,.13)" stroke="${PALE}" stroke-width="1.1"/><path d="M${n(-r * .62)} ${n(-r * .3)} A${n(r * .7)} ${n(r * .7)} 0 0 1 ${n(-r * .1)} ${n(-r * .68)}" fill="none" stroke="#fff" stroke-width="1.8" stroke-linecap="round" opacity=".8"/><g${p.bas ? ' transform="rotate(180)"' : ''}>${enseigne(c.ens, 0, 0, n(p.t * .8), `fill="${c.encre}"`)}</g></g></g>`;
  },
  as(c) {
    const u = c.u; const ronde = Array.from({ length: 9 }, (_, i) => { const a = (i / 9) * Math.PI * 2, r = 96; return `<circle cx="${n(125 + Math.cos(a) * r)}" cy="${n(176 + Math.sin(a) * r)}" r="${i % 3 ? 4 : 7}" fill="rgba(189,251,255,.14)" stroke="${PALE}" stroke-width="1"/>`; }).join('');
    return `<circle cx="125" cy="176" r="110" fill="url(#oal-${u})"/><g class="oa-ronde">${ronde}</g>
<g class="oa-flotte" style="--i:0"><circle cx="125" cy="176" r="76" fill="rgba(60,242,255,.14)" stroke="${PALE}" stroke-width="1.8"/><path d="M76 150 A56 56 0 0 1 112 116" fill="none" stroke="#fff" stroke-width="4" stroke-linecap="round" opacity=".8"/><circle cx="170" cy="216" r="6" fill="#fff" opacity=".3"/>${enseigne(c.ens, 125, 178, 92, `fill="${c.encre}"`)}</g>`;
  },
  figure(c) { const u = c.u; return (c.rang === 'R' ? pieuvre(c) : c.rang === 'D' ? meduse(u, true, diademe(u)) : poisson(c)) + medaillon(c); },
};
