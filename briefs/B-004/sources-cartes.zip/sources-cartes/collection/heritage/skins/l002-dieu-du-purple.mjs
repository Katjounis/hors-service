// L-002 Dieu du Purple (version 2) : le trône de cristaux au dos ; au recto, le dieu, la prêtresse et l'acolyte en capuche,
// enseignes taillées dans le cristal qui lévitent, as géant entouré d'une ronde de cristaux.
import v1 from '../dos/l002-dieu-du-purple.mjs';
import { L, H, cadre, hasard, n, enseigne, ENSEIGNES, eclat4, miroir } from '../outils.mjs';
const VIO2 = '#C084FC', LILAS = '#F0ABFC', PALE = '#E9D5FF';
const facettes = (c) => `<g clip-path="url(#dpc-${c.u})"><path d="M12 0 H24 V24 H12 Z" fill="${c.rouge ? '#9D174D' : '#7C6BB0'}" opacity=".38"/><path d="M0 8.5 L12 3.5 L24 8.5 L12 13.5 Z" fill="#fff" opacity=".3"/><path d="M12 13.5 V24 M0 8.5 L12 13.5 L24 8.5" fill="none" stroke="#fff" stroke-width=".5" opacity=".45"/></g>`;
const taille = (c, t, extra = '') => `<g transform="${extra}translate(${n(-t / 2)} ${n(-t / 2)}) scale(${n(t / 24, 3)})"><path d="${ENSEIGNES[c.ens]}" fill="${c.encre}" stroke="${PALE}" stroke-width=".7" stroke-linejoin="round"/>${facettes(c)}</g>`;
const eclatC = (u, x, y, a, l, h, i) => { const d = `M${-l / 2} 0 L${-l / 2} ${n(-h * .7)} L0 ${-h} L${l / 2} ${n(-h * .7)} L${l / 2} 0 L0 ${n(h * .2)} Z`; return `<g transform="translate(${x} ${y}) rotate(${a})"><g class="dp-levite" style="--i:${i}"><path d="${d}" fill="url(#dpx-${u})" stroke="#3b0f6b" stroke-width="1" stroke-linejoin="round"/><path d="M0 ${n(h * .2)} V${-h} M${-l / 2} ${n(-h * .7)} L0 ${n(-h * .55)} L${l / 2} ${n(-h * .7)}" fill="none" stroke="${LILAS}" stroke-width=".8" opacity=".75"/><path class="dp-allume" style="--i:${i}" d="${d}" fill="#F5D0FE"/></g></g>`; };
const SIGNES = ['M-4 0 L0 -5 L4 0 L0 5 Z', 'M-4 4 L0 -4 L4 4 Z', 'M-4 0 A4 4 0 1 0 4 0 A4 4 0 1 0 -4 0', 'M-4 -4 L4 4 M4 -4 L-4 4', 'M-4 0 H4 M0 -4 V4', 'M3 -4 A5 5 0 1 0 3 4 A3.6 3.6 0 1 1 3 -4'];
// derrière la tête : un disque de lumière et la ronde des signes
const halo = (c) => `<circle cx="125" cy="166" r="92" fill="url(#dpa-${c.u})"/><circle cx="125" cy="166" r="52" fill="${PALE}" opacity=".16"/><g class="dp-signes" style="transform-origin:125px 166px"><circle cx="125" cy="166" r="80" fill="none" stroke="${VIO2}" stroke-width="1" opacity=".7"/>${SIGNES.concat(SIGNES).map((d, i, t) => { const a = (i / t.length) * Math.PI * 2; return `<path transform="translate(${n(125 + Math.cos(a) * 80)} ${n(166 + Math.sin(a) * 80)}) rotate(${n((a * 180) / Math.PI + 90)})" d="${d}" fill="none" stroke="${LILAS}" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>`; }).join('')}</g>`;
const robe = (c) => { const u = c.u; return `<path d="M28 350 C32 296 56 262 92 250 L158 250 C194 262 218 296 222 350 Z" fill="url(#dpr-${u})" stroke="#8b5cf6" stroke-width="1.3"/>
<path d="M125 250 L158 250 C194 262 218 296 222 350 L125 350 Z" fill="#000" opacity=".2"/>
<path d="M70 300 C74 320 72 338 70 350 M180 300 C176 320 178 338 180 350 M96 270 C98 300 94 330 92 350 M154 270 C152 300 156 330 158 350" fill="none" stroke="#6d3fc0" stroke-width="1.1"/>
<path d="M117 252 L110 350 M133 252 L140 350" stroke="${PALE}" stroke-width="1.6" opacity=".9"/>
<circle class="dp-pulse" style="--i:2;transform-origin:125px 304px" cx="125" cy="304" r="32" fill="url(#dpa-${u})"/>
<circle cx="125" cy="304" r="19" fill="#0a0414" stroke="${VIO2}" stroke-width="1.5"/>${enseigne(c.ens, 125, 304, 24, `fill="${c.encre}"`)}`; };
const capuche = (pointe, u) => `<path d="${pointe ? 'M136 90 C152 104 170 136 168 180' : 'M125 106 C158 106 172 142 168 180'} C166 204 154 226 150 254 L100 254 C96 226 84 204 82 180 C78 142 ${pointe ? '98 110 136 90' : '92 106 125 106'} Z" fill="url(#dph-${u})" stroke="#E9D5FF" stroke-width="1.7" stroke-linejoin="round"/>
<path d="M${pointe ? '136 90 C152 104 170 136 168 180' : '125 106 C158 106 172 142 168 180'} C166 204 154 226 150 254 L125 254 Z" fill="#000" opacity=".22"/>
<path d="M125 128 C146 128 154 150 152 172 C150 192 140 206 125 208 C110 206 100 192 98 172 C96 150 104 128 125 128 Z" fill="#05020a" stroke="#4c1d95" stroke-width="1"/>`;
const yeux = (ry = 2.8) => `<g class="dp-oeil"><ellipse cx="115" cy="166" rx="11" ry="6.5" fill="${LILAS}" opacity=".2"/><ellipse cx="135" cy="166" rx="11" ry="6.5" fill="${LILAS}" opacity=".2"/><ellipse cx="115" cy="166" rx="5.6" ry="${ry}" fill="${LILAS}"/><ellipse cx="135" cy="166" rx="5.6" ry="${ry}" fill="${LILAS}"/><ellipse cx="115" cy="166" rx="2.2" ry="1.3" fill="#fff"/><ellipse cx="135" cy="166" rx="2.2" ry="1.3" fill="#fff"/></g>`;
const brasLeve = (u) => `<path d="M164 264 L184 204 L212 212 L206 280 Z" fill="url(#dpr-${u})" stroke="#8b5cf6" stroke-width="1.2" stroke-linejoin="round"/><ellipse cx="199" cy="200" rx="12" ry="9" fill="#1b0d30" stroke="#a78bfa" stroke-width="1.1"/>`;
const mainBasse = (u) => `<path d="M72 298 C56 288 40 296 34 316 L60 330 Z" fill="url(#dpr-${u})" stroke="#8b5cf6" stroke-width="1.2" stroke-linejoin="round"/><ellipse cx="48" cy="300" rx="12" ry="8" fill="#1b0d30" stroke="#a78bfa" stroke-width="1.1"/>`;
const roi = (c) => { const u = c.u; return `${[[62, 272, -30, 14, 34, 5], [46, 292, -50, 10, 24, 6], [188, 272, 30, 14, 34, 7], [204, 292, 50, 10, 24, 8]].map((a) => eclatC(u, ...a)).join('')}
${halo(c)}${robe(c)}${capuche(false, u)}${yeux()}
<path d="M125 138 l4.5 7 -4.5 8 -4.5 -8z" fill="${LILAS}" stroke="#fff" stroke-width=".6"/><g transform="translate(125 146)"><path class="dp-glint" style="--i:1" d="${eclat4(8)}" fill="#fff"/></g>
${[[93, 112, -34, 11, 22, 0], [108, 100, -17, 12, 28, 1], [125, 95, 0, 13, 34, 2], [142, 100, 17, 12, 28, 3], [157, 112, 34, 11, 22, 4]].map((a) => eclatC(u, ...a)).join('')}
${mainBasse(u)}<circle class="dp-pulse" style="--i:0;transform-origin:48px 256px" cx="48" cy="256" r="30" fill="url(#dpa-${u})"/>${eclatC(u, 48, 280, 0, 18, 44, 3)}
${brasLeve(u)}<g class="dp-signes" style="transform-origin:199px 164px"><circle cx="199" cy="164" r="21" fill="none" stroke="${PALE}" stroke-width="1.8" stroke-dasharray="4 5"/><circle cx="199" cy="164" r="14" fill="none" stroke="${LILAS}" stroke-width="1.6" stroke-dasharray="12 6"/></g><g transform="translate(199 164)"><path class="dp-glint" style="--i:4" d="${eclat4(13)}" fill="#fff"/></g>`; };
const dame = (c) => { const u = c.u; const voile = `<path d="M84 190 C70 222 70 262 82 300 C88 268 90 232 100 204 Z" fill="${VIO2}" opacity=".3" stroke="${LILAS}" stroke-width=".8"/>`;
  return `${halo(c)}${robe(c)}<g class="dp-voile">${voile}</g><g class="dp-voile b">${miroir(voile)}</g>${capuche(false, u)}${yeux(3.6)}
<path d="M125 134 l4 6.5 -4 7.5 -4 -7.5z" fill="${LILAS}" stroke="#fff" stroke-width=".6"/>
<path d="M107 104 A19 19 0 0 0 143 104 A21 14 0 0 1 107 104 Z" fill="${PALE}" stroke="#7c3aed" stroke-width="1"/><g transform="translate(125 86)"><path class="dp-glint" style="--i:2" d="${eclat4(9)}" fill="#fff"/></g>
<path d="M106 236 Q125 256 144 236" fill="none" stroke="${LILAS}" stroke-width="1.4"/><circle cx="125" cy="246" r="3.4" fill="${PALE}"/>
<path class="dp-volute" d="M46 226 C38 208 56 196 46 178 C38 164 54 152 48 136" fill="none" stroke="${PALE}" stroke-width="2.2" stroke-linecap="round" stroke-dasharray="10 34" opacity=".8"/>
<path class="dp-volute" d="M62 226 C72 206 54 192 66 172 C74 158 60 146 68 130" fill="none" stroke="${LILAS}" stroke-width="2" stroke-linecap="round" stroke-dasharray="8 36" opacity=".7"/>
<circle class="dp-pulse" style="--i:0;transform-origin:56px 236px" cx="56" cy="236" r="32" fill="url(#dpa-${u})"/>
<path d="M53 264 H59 V292 H53 Z" fill="url(#dpx-${u})" stroke="#3b0f6b" stroke-width="1"/><ellipse cx="56" cy="294" rx="15" ry="4.4" fill="url(#dpx-${u})" stroke="#3b0f6b" stroke-width="1"/>
<path d="M34 234 H78 C78 258 67 268 56 268 C45 268 34 258 34 234 Z" fill="url(#dpx-${u})" stroke="#3b0f6b" stroke-width="1.2"/><ellipse cx="56" cy="234" rx="22" ry="5.5" fill="${LILAS}" stroke="#fff" stroke-width=".8"/><ellipse class="dp-oeil" cx="56" cy="234" rx="14" ry="3" fill="#fff"/>
<path d="M76 300 C62 288 46 290 40 300 L52 312 Z" fill="url(#dpr-${u})" stroke="#8b5cf6" stroke-width="1.2"/><ellipse cx="56" cy="282" rx="11" ry="7" fill="#1b0d30" stroke="#a78bfa" stroke-width="1.1"/>`; };
const valet = (c) => { const u = c.u; const carte = (a, e, coul, i) => `<g transform="translate(199 168) rotate(${a})"><g class="dp-levite" style="--i:${i}"><rect x="-13" y="-19" width="26" height="38" rx="3.5" fill="#F7F2FF" stroke="#3b1d6b" stroke-width="1.2"/>${enseigne(e, 0, 0, 17, `fill="${coul}"`)}</g></g>`;
  return `${eclatC(u, 50, 282, -8, 14, 34, 2)}${eclatC(u, 68, 296, 14, 10, 22, 4)}
${halo(c)}${robe(c)}${capuche(true, u)}${yeux(2.2)}
<path d="M116 190 Q125 196 134 190" fill="none" stroke="${LILAS}" stroke-width="1.2" stroke-linecap="round" opacity=".7"/>
${brasLeve(u)}<circle class="dp-pulse" style="--i:1;transform-origin:199px 166px" cx="199" cy="166" r="34" fill="url(#dpa-${u})"/>${carte(-17, 'H', '#E11D48', 0)}${carte(15, 'S', '#17120A', 3)}
<g transform="translate(184 138)"><path class="dp-glint" style="--i:0" d="${eclat4(8)}" fill="#fff"/></g>`; };

export default {
  ...v1, aura: ['#C084FC', '#6D28D9'],
  bouge: 'Dos : l’aura respire, les cristaux du trône s’allument l’un après l’autre, les signes tournent autour de la capuche, volutes et poussières montent. Recto : le dieu, la prêtresse et l’acolyte ont les yeux qui luisent ; la couronne de cristaux flotte, le calice fume, les deux cartes rouge et noire lévitent. Sur les chiffres, chaque enseigne est un cristal taillé qui lévite et s’illumine à son tour. L’as est un cristal géant entouré d’une ronde.',
  retournement: 'Une bouffée de fumée violette, une onde et des éclats de cristal.',
  face: { papier: '#1B0A33', encre: '#F7F2FF', rouge: '#FF6B88', sombre: true, contour: '#12061f', contourEp: 6, reflet: '#F5D0FE', onglet: '#12061f', ongletOp: 0.5 },
  css: v1.css + `
.dp-levite { animation: dp-levite 3.4s ease-in-out infinite alternate; animation-delay: calc(var(--i) * -.43s); }
@keyframes dp-levite { from { transform: translateY(2.5px); } to { transform: translateY(-3.5px); } }
.dp-pulse { opacity: .3; animation: dp-pulse 4.4s ease-in-out infinite; animation-delay: calc(var(--i) * .34s); }
@keyframes dp-pulse { 0%, 100% { opacity: .2; transform: scale(.82); } 12% { opacity: 1; transform: scale(1.16); } 34% { opacity: .3; transform: scale(.9); } }
.dp-glint { opacity: .8; animation: dp-glint 3.3s ease-in-out infinite; animation-delay: calc(var(--i) * -.47s); }
@keyframes dp-glint { 0%, 100% { transform: scale(.15) rotate(0deg); opacity: 0; } 50% { transform: scale(1) rotate(45deg); opacity: 1; } }
.dp-voile { transform-origin: 92px 196px; animation: dp-voile 4s ease-in-out infinite alternate; }
.dp-voile.b { transform-origin: 158px 196px; animation-delay: -2s; }
@keyframes dp-voile { from { transform: rotate(-3deg); } to { transform: rotate(4deg); } }
.dp-ronde { transform-origin: 125px 176px; animation: dp-tourne 26s linear infinite; }
.dp-rayon { transform-origin: 125px 350px; animation: dp-rayon 3.6s ease-in-out infinite alternate; }
@keyframes dp-rayon { from { opacity: .35; transform: scaleX(.8); } to { opacity: .9; transform: scaleX(1.15); } }
.dp-cadre { animation: dp-cadre 14s linear infinite; }
@keyframes dp-cadre { to { stroke-dashoffset: -300; } }
`,
  recto(c) {
    const u = c.u; const fig = 'VDR'.includes(c.rang); const h = hasard(9 + c.num);
    const grains = (nb) => Array.from({ length: nb }, (_, i) => `<circle class="dp-grain" style="--t:${n(4.5 + h() * 4)}s;--d:${n(-h() * 8)}s" cx="${n(18 + h() * 214)}" cy="${n(250 + h() * 90)}" r="${n(.9 + h() * 1.5)}" fill="${i % 3 ? LILAS : '#fff'}"/>`).join('');
    const volute = (x, s) => `<path class="dp-volute" d="M${x} 336 C${x + 16 * s} 296 ${x - 16 * s} 256 ${x} 216 C${x + 16 * s} 176 ${x - 16 * s} 136 ${x} 96 C${x + 12 * s} 66 ${x - 8 * s} 46 ${x} 26" fill="none" stroke="${PALE}" stroke-width="2.2" stroke-linecap="round" stroke-dasharray="10 34" opacity=".45"/>`;
    const coinC = `<path d="M18 30 L26 18 L34 30 L26 42 Z" fill="#a855f7" stroke="${LILAS}" stroke-width="1"/>`;
    return {
      fond: `<defs><linearGradient id="dpf-${u}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0b0416"/><stop offset=".55" stop-color="#2E1065"/><stop offset="1" stop-color="#12061f"/></linearGradient>
<radialGradient id="dpa-${u}"><stop offset="0" stop-color="${PALE}" stop-opacity=".85"/><stop offset=".4" stop-color="${VIO2}" stop-opacity=".5"/><stop offset="1" stop-color="#7E22CE" stop-opacity="0"/></radialGradient>
<linearGradient id="dpx-${u}" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#6b21a8"/><stop offset=".6" stop-color="#a855f7"/><stop offset="1" stop-color="#e9d5ff"/></linearGradient>
<linearGradient id="dpr-${u}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#6d3fd0"/><stop offset=".6" stop-color="#3a1b78"/><stop offset="1" stop-color="#160828"/></linearGradient>
<linearGradient id="dph-${u}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#8b5cf6"/><stop offset="1" stop-color="#3a1b78"/></linearGradient>
<linearGradient id="dpl-${u}" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="${LILAS}" stop-opacity=".7"/><stop offset="1" stop-color="${LILAS}" stop-opacity="0"/></linearGradient>
<clipPath id="dpc-${u}"><path d="${ENSEIGNES[c.ens]}"/></clipPath></defs>
${cadre(`fill="url(#dpf-${u})"`)}<ellipse class="dp-aura" style="transform-origin:125px ${fig ? 180 : 176}px" cx="125" cy="${fig ? 180 : 176}" rx="118" ry="${fig ? 150 : 130}" fill="url(#dpa-${u})" opacity=".8"/>${volute(26, 1)}${volute(224, -1)}${grains(8)}`,
      bord: `<rect x="7" y="7" width="${L - 14}" height="${H - 14}" rx="16" fill="none" stroke="${VIO2}" stroke-width="2"/><rect class="dp-cadre" x="12.5" y="12.5" width="${L - 25}" height="${H - 25}" rx="12" fill="none" stroke="${LILAS}" stroke-width="1.2" stroke-dasharray="60 40 20 30" opacity=".85"/>${coinC}${miroir(coinC)}<g transform="rotate(180 125 175)">${coinC}${miroir(coinC)}</g>`,
      devant: grains(10),
    };
  },
  pip(c, p, i) {
    return `<g transform="translate(${p.x} ${p.y})"><circle class="dp-pulse" style="--i:${i}" r="${n(p.t * .74)}" fill="url(#dpa-${c.u})"/><g class="dp-levite" style="--i:${i}">${taille(c, p.t, p.bas ? 'rotate(180) ' : '')}<g transform="translate(${n(-p.t * .2)} ${n(-p.t * .2)})"><path class="dp-glint" style="--i:${i}" d="${eclat4(n(p.t * .2))}" fill="#fff"/></g></g></g>`;
  },
  as(c) {
    const u = c.u;
    const ronde = Array.from({ length: 10 }, (_, i) => { const a = (i / 10) * Math.PI * 2; return eclatC(u, n(125 + Math.cos(a) * 92), n(176 + Math.sin(a) * 92), n((a * 180) / Math.PI + 90), i % 2 ? 9 : 12, i % 2 ? 18 : 26, i); }).join('');
    return `<path class="dp-rayon" d="M95 350 L112 40 H138 L155 350 Z" fill="url(#dpl-${u})"/>
<g class="dp-ronde">${ronde}</g>
<circle class="dp-pulse" style="--i:0;transform-origin:125px 176px" cx="125" cy="176" r="86" fill="url(#dpa-${u})"/>
<g transform="translate(125 176)"><g class="dp-levite" style="--i:0;animation-duration:2.6s">${taille(c, 124)}<g transform="translate(-26 -30)"><path class="dp-glint" style="--i:0" d="${eclat4(20)}" fill="#fff"/></g><g transform="translate(24 16)"><path class="dp-glint" style="--i:3" d="${eclat4(12)}" fill="#fff"/></g></g></g>`;
  },
  figure(c) { return c.rang === 'R' ? roi(c) : c.rang === 'D' ? dame(c) : valet(c); },
};
