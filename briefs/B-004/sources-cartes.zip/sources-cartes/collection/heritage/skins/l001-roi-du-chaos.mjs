// L-001 Roi du Chaos (version 2) : couronne fendue au dos ; au recto, seigneurs du chaos aux yeux qui brûlent,
// enseignes fissurées reliées par des éclairs, as fendu en deux.
import { L, H, cadre, zigzag, hasard, n, enseigne, ENSEIGNES, eclat4, chaine, miroir } from '../outils.mjs';
const CX = 125, CY = 162;
const OR = '#F5C518', OR2 = '#FFD23F', OR3 = '#FFE27A', VIO = '#7C3AED', VIO2 = '#8B5CF6', NUIT = '#08060c';

const couronne = (u) => `
  <path d="M80 182 L73 136 L88 160 L99 124 L112 154 L125 112 L138 154 L151 124 L162 160 L177 136 L170 182 Z" fill="url(#rc-or-sombre-${u})" stroke="#F5C518" stroke-width="2.6" stroke-linejoin="round"/>
  <rect x="77" y="179" width="96" height="17" rx="3.5" fill="#17111f" stroke="#F5C518" stroke-width="2.4"/>
  <path d="M103 187.5 l6 -5.5 6 5.5 -6 5.5z M119 187.5 l6 -5.5 6 5.5 -6 5.5z M135 187.5 l6 -5.5 6 5.5 -6 5.5z" fill="#8B5CF6" stroke="#E9D5FF" stroke-width=".8"/>
  <path d="M88 187.5 l4 -4 4 4 -4 4z M154 187.5 l4 -4 4 4 -4 4z" fill="#F5C518"/>
  <circle cx="73" cy="136" r="4.6" fill="#F5C518"/><circle cx="99" cy="124" r="4.6" fill="#F5C518"/><circle cx="125" cy="111" r="5.4" fill="#FFE27A"/><circle cx="151" cy="124" r="4.6" fill="#F5C518"/><circle cx="177" cy="136" r="4.6" fill="#F5C518"/>
  <path d="M86 150 L96 136 M118 146 L124 126 M146 150 L152 136" stroke="#5b4a1c" stroke-width="1.4" stroke-linecap="round" opacity=".8"/>`;
const FENTE = '125,104 120,126 129,142 119,158 128,173 122,200';
const foudre = (cibles, cx, cy, graine, pas = 2) => cibles.map(([x, y], i) => { const p = zigzag(cx, cy, x, y, 8, 13, graine + i); return `<g class="rc-eclair" style="--i:${i * pas}"><polyline points="${p}" fill="none" stroke="${OR2}" stroke-width="8" opacity=".2" stroke-linejoin="round"/><polyline points="${p}" fill="none" stroke="${OR2}" stroke-width="2.4" stroke-linejoin="round"/><polyline points="${p}" fill="none" stroke="#FFFBE6" stroke-width="1" stroke-linejoin="round"/></g>`; }).join('');

// --- les figures : même carrure, trois têtes ---
const defsRecto = (u) => `<defs>
  <radialGradient id="rcf-${u}" cx="50%" cy="46%" r="74%"><stop offset="0" stop-color="#2d1755"/><stop offset=".5" stop-color="#130a22"/><stop offset="1" stop-color="#050308"/></radialGradient>
  <radialGradient id="rch-${u}"><stop offset="0" stop-color="#8B5CF6" stop-opacity=".7"/><stop offset=".55" stop-color="#7C3AED" stop-opacity=".2"/><stop offset="1" stop-color="#7C3AED" stop-opacity="0"/></radialGradient>
  <linearGradient id="rco-${u}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#3a2f45"/><stop offset="1" stop-color="#0d0912"/></linearGradient>
  <linearGradient id="rcm-${u}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#FFE27A"/><stop offset=".5" stop-color="#F5C518"/><stop offset="1" stop-color="#9a6b00"/></linearGradient>
  <linearGradient id="rcc-${u}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#4a2a8a"/><stop offset=".55" stop-color="#24134a"/><stop offset="1" stop-color="#0c0616"/></linearGradient>
  <linearGradient id="rcx-${u}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#7a62b8"/><stop offset=".5" stop-color="#3f2a78"/><stop offset="1" stop-color="#1a1030"/></linearGradient>
  <linearGradient id="rca-${u}" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#A78BFA" stop-opacity=".85"/><stop offset=".6" stop-color="#7C3AED" stop-opacity=".45"/><stop offset="1" stop-color="#7C3AED" stop-opacity="0"/></linearGradient>
</defs>`;
const cou = `<path d="M114 198 C115 214 111 232 104 246 L146 246 C139 232 135 214 136 198 Z" fill="#1a0f30"/>`;
const tete = `<path d="M101 152 C101 122 149 122 149 152 L146 186 C142 205 108 205 104 186 Z" fill="#2a1a4e" stroke="#8a66f0" stroke-width="1.3"/><path d="M125 124 C149 124 149 152 149 152 L146 186 C144 197 136 203 125 204 Z" fill="#000" opacity=".3"/>`;
const oeil = (coul, g = true, d = true) => `<g class="rc-oeil">${g ? `<ellipse cx="114" cy="166" rx="12" ry="6" fill="${coul}" opacity=".24"/><path d="M106 162.5 L122 166.5 L107 170.5 Z" fill="${coul}"/>` : ''}${d ? `<ellipse cx="136" cy="166" rx="12" ry="6" fill="${coul}" opacity=".24"/><path d="M144 162.5 L128 166.5 L143 170.5 Z" fill="${coul}"/>` : ''}</g>`;
const corps = (c) => { const u = c.u; const epaule = `<path d="M30 306 L40 264 L60 252 L96 246 L86 270 L56 284 Z" fill="#35206a" stroke="${OR}" stroke-width="1.1"/><path d="M42 264 L30 236 L56 254 Z" fill="url(#rcm-${u})"/><path d="M60 252 L58 228 L76 248 Z" fill="url(#rcm-${u})"/><path d="M98 246 L80 198 L112 228 Z" fill="#3b2378" stroke="${OR}" stroke-width="1.1"/>`;
  return `<path d="M20 350 C24 292 56 254 98 242 L152 242 C194 254 226 292 230 350 Z" fill="url(#rcc-${u})" stroke="${OR}" stroke-width="1.4"/>
${epaule}${miroir(epaule)}
<path d="M98 242 L125 262 L152 242 L158 304 L125 338 L92 304 Z" fill="#2a1856" stroke="${OR}" stroke-width="1.4"/><path d="M98 242 L125 262 L125 338 L92 304 Z" fill="#000" opacity=".22"/>
<polyline class="rc-fente" points="108,258 114,270 106,282" fill="none" stroke="${OR3}" stroke-width="1"/><polyline class="rc-fente" points="143,258 137,272 145,284" fill="none" stroke="${OR3}" stroke-width="1"/>
<circle cx="125" cy="298" r="21" fill="#0b0712" stroke="${OR}" stroke-width="1.2"/><circle class="rc-anneau" style="transform-origin:125px 298px;animation-duration:9s" cx="125" cy="298" r="25" fill="none" stroke="${OR3}" stroke-width=".9" stroke-dasharray="3 5"/>
${enseigne(c.ens, 125, 298, 27, `fill="${c.encre}"`)}`; };
const brasLeve = `<path d="M178 272 L188 204 L208 204 L216 266 Z" fill="#35206a" stroke="${OR}" stroke-width="1.1"/>`;
const poing = (y) => `<rect x="187" y="${y}" width="25" height="22" rx="6" fill="#4a2a8a" stroke="${OR}" stroke-width="1.2"/><path d="M191 ${y + 7} H208 M191 ${y + 14} H208" stroke="${OR}" stroke-width=".8" opacity=".7"/>`;
const SCEPTRE = '197,218 200,186 191,172 204,140 195,128 208,96 200,84 212,54';
const roi = (c) => { const u = c.u; return `
<path d="M106 204 H144 L153 250 H97 Z" fill="#2a1856" stroke="${OR}" stroke-width="1.2"/><path d="M104 222 H146 M100 237 H150" stroke="${OR}" stroke-width=".9" opacity=".7"/>
<path d="M100 200 C95 178 95 150 100 138 C107 113 143 113 150 138 C155 150 155 178 150 200 L137 214 L125 203 L113 214 Z" fill="url(#rcx-${u})" stroke="${OR}" stroke-width="1.6" stroke-linejoin="round"/>
<path d="M125 115 C142 115 148 132 150 138 C155 150 155 178 150 200 L137 214 L125 203 Z" fill="#000" opacity=".3"/>
<path d="M105 157 H145 V169 H131 V199 L125 205 L119 199 V169 H105 Z" fill="#04020a" stroke="${OR}" stroke-width="1"/>
<g class="rc-oeil"><ellipse cx="114" cy="163" rx="9" ry="5" fill="${OR2}" opacity=".35"/><ellipse cx="136" cy="163" rx="9" ry="5" fill="${OR2}" opacity=".35"/><path d="M107 160.6 L121 163.5 L108 166.4 Z M143 160.6 L129 163.5 L142 166.4 Z" fill="${OR3}"/></g>
<circle cx="103" cy="178" r="1.7" fill="${OR}"/><circle cx="147" cy="178" r="1.7" fill="${OR}"/><circle cx="105" cy="192" r="1.7" fill="${OR}"/><circle cx="145" cy="192" r="1.7" fill="${OR}"/>
<polyline class="rc-fente" points="140,140 136,150 141,157" fill="none" stroke="${OR3}" stroke-width="1.1"/>
<g transform="translate(0 -8)">
<path d="M97 134 L90 100 L106 119 L114 96 L119 112 L131 112 L136 96 L144 119 L160 100 L153 134 Z" fill="url(#rco-${u})" stroke="${OR}" stroke-width="2" stroke-linejoin="round"/>
<rect x="95" y="129" width="60" height="11" rx="2.5" fill="#17111f" stroke="${OR}" stroke-width="1.8"/>
<path d="M110 134.5 l4.5 -4 4.5 4 -4.5 4z M120.5 134.5 l4.5 -4 4.5 4 -4.5 4z M131 134.5 l4.5 -4 4.5 4 -4.5 4z" fill="${VIO2}" stroke="#E9D5FF" stroke-width=".6"/>
<circle cx="90" cy="100" r="3.6" fill="${OR}"/><circle cx="114" cy="95" r="3.6" fill="${OR}"/><circle cx="136" cy="95" r="3.6" fill="${OR}"/><circle cx="160" cy="100" r="3.6" fill="${OR}"/>
<g class="rc-eclair" style="--i:3"><polyline points="121,110 124,102 120,96 124,90" fill="none" stroke="${OR3}" stroke-width="1.5"/><polyline points="129,110 126,100 131,95 127,90" fill="none" stroke="${OR3}" stroke-width="1.5"/></g>
<g class="rc-bris"><path d="M118 88 L125 58 L132 88 L127 84 L123 90 Z" fill="url(#rco-${u})" stroke="${OR}" stroke-width="2" stroke-linejoin="round"/><circle cx="125" cy="56" r="4.4" fill="${OR3}"/></g>
</g>
${brasLeve}
<polyline class="rc-sceptre" points="${SCEPTRE}" fill="none" stroke="${OR2}" stroke-width="14" opacity=".5" stroke-linejoin="round"/>
<polyline points="${SCEPTRE}" fill="none" stroke="${OR2}" stroke-width="4.6"/><polyline points="${SCEPTRE}" fill="none" stroke="#FFFBE6" stroke-width="1.4"/>
<g transform="translate(212 50)"><path class="rc-etoile" d="${eclat4(14)}" fill="${OR3}"/></g>
${poing(186)}`; };
const dame = (c) => { const u = c.u;
  const meche = (b) => `<g class="rc-meche${b}"><path d="M106 134 C80 146 72 192 78 234 C80 252 70 268 56 278 C80 280 99 266 103 244 C108 214 101 178 110 150 Z" fill="#3b2378" stroke="#8a66f0" stroke-width="1"/><path d="M97 152 C86 178 86 216 89 242 M104 150 C96 178 96 208 96 230" fill="none" stroke="${OR}" stroke-width=".9" opacity=".8"/></g>`;
  return `
${meche('')}${miroir(meche(' b'))}
${cou}${tete}
<path d="M103 156 C110 150 120 152 125 158 C130 152 140 150 147 156 C146 168 138 173 130 170 L125 165 L120 170 C112 173 104 168 103 156 Z" fill="url(#rcm-${u})" stroke="#5b4a1c" stroke-width=".7"/>
<g class="rc-oeil"><ellipse cx="114" cy="161" rx="10" ry="6" fill="#C4B5FD" opacity=".3"/><ellipse cx="136" cy="161" rx="10" ry="6" fill="#C4B5FD" opacity=".3"/><path d="M108 161 Q114 156 120 162 Q114 166 108 161 Z M142 161 Q136 156 130 162 Q136 166 142 161 Z" fill="#F3ECFF"/></g>
<path d="M125 172 L123 180 L126 181" fill="none" stroke="#8a66f0" stroke-width="1" stroke-linecap="round"/>
<path d="M118.5 188 Q122 185 125 187 Q128 185 131.5 188 Q125 195 118.5 188 Z" fill="${c.rouge ? c.encre : OR}"/>
${[[107, 12], [116, 21], [125, 34], [134, 21], [143, 12]].map(([x, h]) => `<path d="M${x - 3.6} 133 L${x} ${132 - h} L${x + 3.6} 133 Z" fill="url(#rco-${u})" stroke="${OR}" stroke-width="1.2" stroke-linejoin="round"/>`).join('')}
<path d="M99 138 Q125 122 151 138 L151 145 Q125 129 99 145 Z" fill="url(#rcm-${u})" stroke="#5b4a1c" stroke-width=".6"/>
<g transform="translate(125 93)"><path class="rc-etoile" d="${eclat4(9)}" fill="#E9D5FF"/></g>
<path d="M107 216 Q125 236 143 216" fill="none" stroke="${OR}" stroke-width="1.5"/><path d="M125 226 l5 6 -5 7 -5 -7z" fill="${VIO2}" stroke="#E9D5FF" stroke-width=".7"/>
<path d="M32 292 Q56 306 82 290 L76 312 Q56 320 40 312 Z" fill="#4a2a8a" stroke="${OR}" stroke-width="1.1"/>
<circle class="rc-halo" style="transform-origin:56px 256px" cx="56" cy="256" r="34" fill="url(#rch-${u})"/>
<circle cx="56" cy="256" r="20" fill="#6D3AE0" stroke="#C4B5FD" stroke-width="1.5"/><circle cx="56" cy="256" r="13" fill="#A78BFA" opacity=".6"/><circle cx="50" cy="249" r="6" fill="#F3ECFF" opacity=".75"/>
<g transform="rotate(-28 56 256)"><ellipse class="rc-orbite" cx="56" cy="256" rx="27" ry="8" fill="none" stroke="${OR2}" stroke-width="1.7" stroke-dasharray="20 9 6 9"/></g>
<g transform="rotate(34 56 256)"><ellipse class="rc-orbite b" cx="56" cy="256" rx="27" ry="8" fill="none" stroke="#C4B5FD" stroke-width="1.3" stroke-dasharray="14 8"/></g>
<g transform="translate(56 256)"><path class="rc-etoile" d="${eclat4(10)}" fill="${OR3}"/></g>`; };
const valet = (c) => { const u = c.u; return `
<g class="rc-echarpe"><path d="M104 224 C84 232 68 228 46 246 C66 252 84 250 106 238 Z" fill="${VIO}" stroke="${VIO2}" stroke-width=".9"/><path d="M96 232 C80 238 68 238 56 244" fill="none" stroke="#C4B5FD" stroke-width=".8" opacity=".7"/></g>
${cou}${tete}
<path d="M100 206 C112 220 138 220 150 206 L150 226 C138 238 112 238 100 226 Z" fill="${VIO}" stroke="${VIO2}" stroke-width="1"/>
${oeil(OR3, true, false)}
<path d="M113 190 Q121 195 131 188" fill="none" stroke="${OR}" stroke-width="1.2" stroke-linecap="round"/>
<path d="M127 148 L151 146 L148 180 L129 175 Z" fill="url(#rcm-${u})" stroke="#5b4a1c" stroke-width=".8"/><path d="M132 162 L146 159 L145 166 Z" fill="${NUIT}"/><polyline points="140,147 137,156 142,166 138,178" fill="none" stroke="${NUIT}" stroke-width="1.1"/>
<g class="rc-panache"><path d="M126 106 C112 86 116 64 100 48 C122 54 134 72 132 98 Z" fill="${VIO}" stroke="${VIO2}" stroke-width=".9"/><path d="M128 106 C122 86 130 68 122 52 C138 64 142 84 134 102 Z" fill="${VIO2}" opacity=".85"/></g>
<path d="M98 152 C96 116 154 116 152 152 L152 160 L139 151 L125 160 L111 151 L98 160 Z" fill="#1d1233" stroke="${OR}" stroke-width="1.5" stroke-linejoin="round"/>
<path d="M125 122 L125 158 M106 131 Q125 121 144 131" fill="none" stroke="${OR}" stroke-width="1" opacity=".8"/>
<path d="M120 124 L125 102 L130 124 Z" fill="url(#rcm-${u})"/>
${brasLeve}
<path d="M198 192 L190 150 L198 132 L193 108 L201 84 L208 108 L204 132 L212 150 L206 192 Z" fill="url(#rcm-${u})" stroke="#5b4a1c" stroke-width=".8" stroke-linejoin="round"/>
<path d="M201 92 L201 186" stroke="#FFFBE6" stroke-width="1" opacity=".7"/>
<path class="rc-glint" d="M194 152 L208 144 L208 150 L194 158 Z" fill="#fff"/>
<rect x="184" y="188" width="34" height="6" rx="2" fill="${OR}" stroke="#5b4a1c" stroke-width=".6"/>
${poing(192)}
<g transform="translate(201 80)"><path class="rc-etoile" d="${eclat4(10)}" fill="#fff"/></g>`; };

export default {
  id: 'L-001', cle: 'l001-roi-du-chaos', nom: 'Roi du Chaos', rarete: 'Légendaire', fx: 'rc', aura: ['#F5C518', '#7C3AED'],
  bouge: 'Dos : sept éclairs frappent tour à tour, la couronne fendue flotte et s’écarte, deux anneaux tournent en sens contraire. Recto : le roi, la dame et le valet respirent, leurs yeux clignent, le sceptre, l’orbe et la dague crépitent. Sur les chiffres, les enseignes fissurées se chargent une à une et un éclair saute de l’une à l’autre. L’as est fendu en deux.',
  retournement: 'La carte tremble, une onde et des éclats d’or partent en étoile.',
  face: { papier: '#0B0910', encre: '#F4F1E8', rouge: '#FF4D5E', sombre: true, contour: NUIT, contourEp: 6, reflet: OR3, onglet: NUIT, ongletOp: 0.4 },
  css: `
.rc-halo { transform-origin: ${CX}px ${CY}px; animation: rc-halo 3.2s ease-in-out infinite alternate; }
@keyframes rc-halo { from { transform: scale(.9); opacity: .65; } to { transform: scale(1.12); opacity: 1; } }
.rc-anneau { transform-origin: ${CX}px ${CY}px; animation: rc-tourne 18s linear infinite; }
.rc-anneau.b { animation-duration: 27s; animation-direction: reverse; }
@keyframes rc-tourne { to { transform: rotate(360deg); } }
/* au repos (animations réduites) : un éclair sur trois reste allumé */
.rc-eclair { opacity: 0; animation: rc-eclair 4.9s linear infinite; animation-delay: calc(var(--i) * .7s); }
.rc-eclair:nth-of-type(3n+1) { opacity: .85; }
@keyframes rc-eclair { 0%, 3% { opacity: 0; } 4% { opacity: 1; } 7% { opacity: .15; } 9% { opacity: 1; } 16% { opacity: .55; } 24%, 100% { opacity: 0; } }
.rc-couronne { animation: rc-flotte 4.9s ease-in-out infinite; }
.rc-flotte-as { animation: rc-flotte 4.9s ease-in-out infinite; }
@keyframes rc-flotte { 0%, 100% { transform: translateY(0); } 4% { transform: translate(-1.6px, -1px); } 6% { transform: translate(1.8px, 1px); } 8% { transform: translate(-1px, .4px); } 10% { transform: translateY(0); } 50% { transform: translateY(-5px); } }
.rc-moitie-g { transform-origin: 122px 200px; animation: rc-ecarte-g 4.9s ease-in-out infinite; }
.rc-moitie-d { transform-origin: 122px 200px; animation: rc-ecarte-d 4.9s ease-in-out infinite; }
@keyframes rc-ecarte-g { 0%, 100% { transform: rotate(-1.4deg) translateX(-1px); } 50% { transform: rotate(-3.4deg) translateX(-2.6px); } }
@keyframes rc-ecarte-d { 0%, 100% { transform: rotate(1.4deg) translateX(1px); } 50% { transform: rotate(3.4deg) translateX(2.6px); } }
.rc-fente { animation: rc-fente 2.6s ease-in-out infinite; }
@keyframes rc-fente { 0%, 100% { opacity: .55; } 50% { opacity: 1; } }
.rc-etincelle { transform-origin: ${CX}px ${CY}px; opacity: 0; animation: rc-etincelle 2.8s ease-out infinite; animation-delay: calc(var(--i) * -.23s); }
@keyframes rc-etincelle { 0% { transform: rotate(var(--a)) translateX(34px) scale(1); opacity: 0; } 12% { opacity: 1; } 100% { transform: rotate(var(--a)) translateX(168px) scale(.25); opacity: 0; } }
.rc-eclat { transform-box: fill-box; transform-origin: center; animation: rc-eclat 7s ease-in-out infinite alternate; animation-delay: calc(var(--i) * -.9s); }
@keyframes rc-eclat { from { transform: translate(0, 0) rotate(0deg); } to { transform: translate(var(--dx), var(--dy)) rotate(70deg); } }
.rc-veine { opacity: .1; animation: rc-veine 4.9s ease-in-out infinite; animation-delay: calc(var(--i) * .35s); }
@keyframes rc-veine { 0%, 100% { opacity: .08; } 12% { opacity: .6; } 30% { opacity: .14; } }
.rc-cadre { animation: rc-cadre 16s linear infinite; }
@keyframes rc-cadre { to { stroke-dashoffset: -346; } }
.rc-braise { opacity: 0; animation: rc-braise var(--t) linear infinite; animation-delay: calc(var(--i) * -.47s); }
@keyframes rc-braise { 0% { transform: translate(var(--x), 356px) rotate(0deg); opacity: 0; } 10% { opacity: .95; } 80% { opacity: .8; } 100% { transform: translate(calc(var(--x) + 14px), 20px) rotate(240deg); opacity: 0; } }
.rc-pip-in { animation: rc-tremble 4.9s linear infinite; animation-delay: calc(var(--i) * .29s); }
@keyframes rc-tremble { 0%, 9%, 100% { transform: translate(0, 0); } 2% { transform: translate(-1.6px, .8px) rotate(-3deg); } 4% { transform: translate(1.8px, -.6px) rotate(3deg); } 6% { transform: translate(-1px, .4px); } }
.rc-pip-lueur { opacity: .14; animation: rc-charge 4.9s ease-in-out infinite; animation-delay: calc(var(--i) * .29s); }
@keyframes rc-charge { 0%, 100% { opacity: .12; } 4% { opacity: .8; } 22% { opacity: .2; } }
.rc-oeil { animation: rc-oeil 3.7s ease-in-out infinite; }
@keyframes rc-oeil { 0%, 100% { opacity: .8; } 40% { opacity: 1; } 46% { opacity: .15; } 52% { opacity: 1; } }
.rc-bris { transform-box: fill-box; transform-origin: center; animation: rc-bris 3.6s ease-in-out infinite alternate; }
@keyframes rc-bris { from { transform: translateY(1px) rotate(-7deg); } to { transform: translateY(-7px) rotate(9deg); } }
.rc-sceptre { animation: rc-sceptre 1.7s steps(1) infinite; }
@keyframes rc-sceptre { 0%, 100% { opacity: .3; } 20% { opacity: .7; } 28% { opacity: .15; } 36% { opacity: .7; } 60% { opacity: .45; } }
.rc-etoile { animation: rc-etoile 2.6s ease-in-out infinite; }
@keyframes rc-etoile { 0%, 100% { transform: rotate(0deg) scale(.7); opacity: .7; } 50% { transform: rotate(90deg) scale(1.25); opacity: 1; } }
.rc-meche { transform-origin: 104px 138px; animation: rc-meche 4.4s ease-in-out infinite alternate; }
.rc-meche.b { animation-delay: -2.2s; }
@keyframes rc-meche { from { transform: rotate(-2.5deg); } to { transform: rotate(3deg); } }
.rc-orbite { animation: rc-orbite 2.4s linear infinite; }
.rc-orbite.b { animation-direction: reverse; animation-duration: 3.4s; }
@keyframes rc-orbite { to { stroke-dashoffset: -88; } }
.rc-panache { transform-origin: 127px 106px; animation: rc-panache 2.4s ease-in-out infinite alternate; }
@keyframes rc-panache { from { transform: rotate(-6deg) scaleY(.95); } to { transform: rotate(7deg) scaleY(1.06); } }
.rc-echarpe { transform-origin: 104px 230px; animation: rc-echarpe 2.1s ease-in-out infinite alternate; }
@keyframes rc-echarpe { from { transform: rotate(-5deg); } to { transform: rotate(6deg); } }
.rc-glint { opacity: 0; animation: rc-glint 3.4s ease-in-out infinite; }
@keyframes rc-glint { 0%, 50% { transform: translateY(34px); opacity: 0; } 58% { opacity: .9; } 92% { transform: translateY(-56px); opacity: .9; } 100% { transform: translateY(-62px); opacity: 0; } }
.rc-aura { transform-origin: 125px 350px; animation: rc-aura 1.9s ease-in-out infinite alternate; }
.rc-aura.b { animation-duration: 2.7s; animation-delay: -.9s; }
.rc-aura.dos { transform-origin: 125px 200px; }
.rc-rayons { transform-origin: ${CX}px ${CY}px; animation: rc-tourne 60s linear infinite; }
@keyframes rc-aura { from { transform: scale(.94, .9) skewX(-3deg); opacity: .55; } to { transform: scale(1.04, 1.1) skewX(3deg); opacity: 1; } }
.rc-buste { animation: rc-buste 4.9s ease-in-out infinite; }
@keyframes rc-buste { 0%, 100% { transform: translateY(0); } 4% { transform: translate(-1.4px, .8px); } 6% { transform: translate(1.6px, -.4px); } 8% { transform: translateY(0); } 50% { transform: translateY(-3px); } }
`,
  dos(u) {
    const h = hasard(11);
    const cibles = [[18, 14], [236, 24], [247, 150], [228, 338], [120, 347], [16, 326], [3, 168]];
    const eclairs = cibles.map(([x, y], i) => {
      const p = zigzag(CX, CY, x, y, 9, 15, 30 + i); const pts = p.split(' '); const depart = pts[5].split(',').map(Number);
      const br = zigzag(depart[0], depart[1], depart[0] + (x - CX) * .28 + (i % 2 ? 26 : -26), depart[1] + (y - CY) * .28 + (i % 2 ? -18 : 18), 4, 7, 60 + i);
      return `<g class="rc-eclair" style="--i:${i}"><polyline points="${p}" fill="none" stroke="#FFD23F" stroke-width="9" opacity=".2" stroke-linejoin="round"/><polyline points="${p}" fill="none" stroke="#FFD23F" stroke-width="3" stroke-linejoin="round"/><polyline points="${br}" fill="none" stroke="#FFD23F" stroke-width="1.8" stroke-linejoin="round"/><polyline points="${p}" fill="none" stroke="#FFFBE6" stroke-width="1.2" stroke-linejoin="round"/></g>`; }).join('');
    const etincelles = Array.from({ length: 14 }, (_, i) => `<path class="rc-etincelle" style="--i:${i};--a:${Math.round(i * 25.7 + h() * 12)}deg" d="M${CX - 3} ${CY} l3 -3 3 3 -3 3z" fill="${i % 3 ? '#F5C518' : '#C4B5FD'}"/>`).join('');
    const eclats = Array.from({ length: 10 }, (_, i) => { const x = 20 + h() * 210, y = 20 + h() * 300, t = 5 + h() * 8; if (Math.hypot(x - CX, y - CY) < 70) return ''; return `<path class="rc-eclat" style="--i:${i};--dx:${n((h() - .5) * 18)}px;--dy:${n((h() - .5) * 18)}px" d="M${n(x)} ${n(y)} l${n(t)} ${n(-t * .5)} ${n(-t * .3)} ${n(t)}z" fill="${i % 2 ? '#7C3AED' : '#F5C518'}" opacity="${i % 2 ? .75 : .6}"/>`; }).join('');
    return `
<defs>
  <radialGradient id="rc-fond-${u}" cx="50%" cy="46%" r="75%"><stop offset="0" stop-color="#33195a"/><stop offset=".42" stop-color="#150b24"/><stop offset="1" stop-color="#040306"/></radialGradient>
  <radialGradient id="rc-halo-${u}"><stop offset="0" stop-color="#8B5CF6" stop-opacity=".75"/><stop offset=".55" stop-color="#7C3AED" stop-opacity=".22"/><stop offset="1" stop-color="#7C3AED" stop-opacity="0"/></radialGradient>
  <linearGradient id="rc-or-sombre-${u}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#3a2f45"/><stop offset="1" stop-color="#0d0912"/></linearGradient>
  <linearGradient id="rc-flamme-${u}" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#A78BFA" stop-opacity="0"/><stop offset=".22" stop-color="#A78BFA" stop-opacity=".75"/><stop offset=".6" stop-color="#7C3AED" stop-opacity=".4"/><stop offset="1" stop-color="#7C3AED" stop-opacity="0"/></linearGradient>
  <clipPath id="rc-g-${u}"><polygon points="40,90 125,104 120,126 129,142 119,158 128,173 122,200 40,210"/></clipPath>
  <clipPath id="rc-d-${u}"><polygon points="210,90 125,104 120,126 129,142 119,158 128,173 122,200 210,210"/></clipPath>
</defs>
${cadre(`fill="url(#rc-fond-${u})"`)}
<g class="rc-rayons">${Array.from({ length: 14 }, (_, i) => `<path transform="rotate(${n(i * 25.714)} ${CX} ${CY})" d="M${CX} ${CY} L${CX - 9} ${CY - 250} L${CX + 9} ${CY - 250} Z" fill="${i % 2 ? '#F5C518' : '#8B5CF6'}" opacity="${i % 2 ? .1 : .16}"/>`).join('')}</g>
<circle class="rc-halo" cx="${CX}" cy="${CY}" r="112" fill="url(#rc-halo-${u})"/>
<path class="rc-aura dos" d="M66 200 L60 150 L76 172 L80 108 L97 146 L105 58 L117 110 L125 14 L133 110 L145 58 L153 146 L170 108 L174 172 L190 150 L184 200 Z" fill="url(#rc-flamme-${u})"/>
<path class="rc-aura dos b" d="M66 200 L60 150 L76 172 L80 108 L97 146 L105 58 L117 110 L125 14 L133 110 L145 58 L153 146 L170 108 L174 172 L190 150 L184 200 Z" fill="url(#rc-flamme-${u})" opacity=".55"/>
${eclats}
<circle class="rc-anneau" cx="${CX}" cy="${CY}" r="84" fill="none" stroke="#8B5CF6" stroke-width="2.2" stroke-dasharray="46 14 6 20 70 16 12 28" stroke-linecap="round" opacity=".85"/>
<circle class="rc-anneau b" cx="${CX}" cy="${CY}" r="100" fill="none" stroke="#F5C518" stroke-width="1.2" stroke-dasharray="3 11 30 34 8 22" stroke-linecap="round" opacity=".6"/>
${eclairs}
${etincelles}
<g class="rc-couronne">
  <polyline class="rc-fente" points="${FENTE}" fill="none" stroke="#FFE27A" stroke-width="9" opacity=".35" stroke-linejoin="round"/>
  <g clip-path="url(#rc-g-${u})"><g class="rc-moitie-g">${couronne(u)}</g></g>
  <g clip-path="url(#rc-d-${u})"><g class="rc-moitie-d">${couronne(u)}</g></g>
  <polyline class="rc-fente" points="${FENTE}" fill="none" stroke="#FFF8D6" stroke-width="1.6" stroke-linejoin="round"/>
</g>
<rect class="rc-cadre" x="7.5" y="7.5" width="${L - 15}" height="${H - 15}" rx="16" fill="none" stroke="#F5C518" stroke-width="2.6" stroke-dasharray="84 10 26 7 120 14 52 9 18 6" stroke-linecap="round"/>
<rect x="13" y="13" width="${L - 26}" height="${H - 26}" rx="11" fill="none" stroke="#7C3AED" stroke-width="1" opacity=".7" stroke-dasharray="130 20 60 12"/>`;
  },
  // décor commun à tous les rectos : nuit violette, veines d'or, anneaux, cadre brisé qui court, braises qui montent
  recto(c) {
    const u = c.u; const cy = 'VDR'.includes(c.rang) ? 150 : 176;
    const veines = [[14, 40], [240, 70], [246, 240], [150, 346], [30, 300], [4, 170]].map(([x, y], i) => `<polyline class="rc-veine" style="--i:${i}" points="${zigzag(125, cy, x, y, 8, 11, 200 + i)}" fill="none" stroke="${OR}" stroke-width="1.1" stroke-linejoin="round"/>`).join('');
    const braises = Array.from({ length: 12 }, (_, i) => `<path class="rc-braise" style="--i:${i};--x:${20 + ((i * 53) % 210)}px;--t:${n(3.2 + (i % 5) * .7)}s" d="M-2.5 0 L0 -2.5 L2.5 0 L0 2.5 Z" fill="${i % 3 ? OR2 : '#C4B5FD'}"/>`).join('');
    return {
      fond: defsRecto(u) + cadre(`fill="url(#rcf-${u})"`) + `<circle class="rc-halo" style="transform-origin:125px ${cy}px" cx="125" cy="${cy}" r="120" fill="url(#rch-${u})"/>` + veines
        + `<circle class="rc-anneau" style="transform-origin:125px ${cy}px" cx="125" cy="${cy}" r="100" fill="none" stroke="${VIO2}" stroke-width="2" stroke-dasharray="46 14 6 20 70 16 12 28" stroke-linecap="round" opacity=".7"/><circle class="rc-anneau b" style="transform-origin:125px ${cy}px" cx="125" cy="${cy}" r="116" fill="none" stroke="${OR}" stroke-width="1.1" stroke-dasharray="3 11 30 34 8 22" stroke-linecap="round" opacity=".5"/>`,
      bord: `<rect class="rc-cadre" x="7.5" y="7.5" width="${L - 15}" height="${H - 15}" rx="16" fill="none" stroke="${OR}" stroke-width="2.6" stroke-dasharray="84 10 26 7 120 14 52 9 18 6" stroke-linecap="round"/><rect x="13" y="13" width="${L - 26}" height="${H - 26}" rx="11" fill="none" stroke="${VIO}" stroke-width="1" opacity=".7" stroke-dasharray="130 20 60 12"/>`,
      devant: braises,
    };
  },
  // cartes à chiffres : chaque enseigne est un éclat fissuré qui se charge, un éclair saute de l'une à l'autre
  liens(c, ps) {
    const ch = chaine(ps);
    return ch.slice(1).map((p, i) => { const a = ch[i]; const pts = zigzag(a.x, a.y, p.x, p.y, 5, 7, 90 + i); return `<g class="rc-eclair" style="--i:${i % 7}"><polyline points="${pts}" stroke="${OR2}" stroke-width="6" opacity=".22" fill="none" stroke-linejoin="round"/><polyline points="${pts}" stroke="${OR3}" stroke-width="1.7" fill="none" stroke-linejoin="round"/></g>`; }).join('');
  },
  pip(c, p, i) {
    const fiss = 'M12.6 1.6 L10.6 6.5 L13.6 10.5 L10.4 15 L13 19 L11.6 22.4';
    return `<g transform="translate(${p.x} ${p.y})${p.bas ? ' rotate(180)' : ''}"><g class="rc-pip-in" style="--i:${i}"><g transform="translate(${n(-p.t / 2)} ${n(-p.t / 2)}) scale(${n(p.t / 24, 3)})"><path class="rc-pip-lueur" style="--i:${i}" d="${ENSEIGNES[c.ens]}" fill="${OR2}" transform="translate(12 12) scale(1.36) translate(-12 -12)"/><path d="${ENSEIGNES[c.ens]}" fill="${c.encre}" stroke="${NUIT}" stroke-width=".7"/><path d="${fiss}" fill="none" stroke="${NUIT}" stroke-width="2.2" stroke-linejoin="round"/><path class="rc-fente" d="${fiss}" fill="none" stroke="${OR3}" stroke-width=".8" stroke-linejoin="round"/></g></g></g>`;
  },
  // l'as : la grande enseigne fendue en deux, la lumière passe par la fente
  as(c) {
    const u = c.u, T = 138, ox = 125 - T / 2, oy = 178 - T / 2;
    const forme = `<g transform="translate(${ox} ${oy}) scale(${n(T / 24, 3)})"><path d="${ENSEIGNES[c.ens]}" fill="${c.encre}" stroke="${OR}" stroke-width=".55" stroke-linejoin="round"/></g>`;
    const fente = '125,100 117,128 132,150 116,178 131,206 121,254';
    const eclats = Array.from({ length: 9 }, (_, i) => { const a = (i / 9) * Math.PI * 2, r = 94 + (i % 3) * 8; const x = 125 + Math.cos(a) * r, y = 178 + Math.sin(a) * r; return `<path d="M${n(x)} ${n(y)} l${5 + (i % 3) * 2} -3 l-2 ${6 + (i % 2) * 3} z" fill="${i % 2 ? VIO2 : OR}" opacity=".9"/>`; }).join('');
    return `<defs><clipPath id="rcg-${u}"><polygon points="0,60 ${fente} 0,300"/></clipPath><clipPath id="rcd-${u}"><polygon points="250,60 ${fente} 250,300"/></clipPath></defs>
${foudre([[20, 20], [234, 30], [244, 190], [200, 340], [40, 334], [6, 180]], 125, 178, 400, 1)}
<g class="rc-anneau" style="transform-origin:125px 178px;animation-duration:26s">${eclats}</g>
<path d="M108 92 L104 72 L114 82 L119 68 L123 80 L127 80 L131 68 L136 82 L146 72 L142 92 Z" fill="url(#rco-${u})" stroke="${OR}" stroke-width="1.8" stroke-linejoin="round"/>
<g class="rc-bris"><path d="M121 64 L125 46 L129 64 Z" fill="url(#rco-${u})" stroke="${OR}" stroke-width="1.6" stroke-linejoin="round"/></g>
<polyline class="rc-fente" points="${fente}" fill="none" stroke="${OR3}" stroke-width="18" opacity=".4" stroke-linejoin="round"/>
<g class="rc-flotte-as"><g clip-path="url(#rcg-${u})"><g class="rc-moitie-g" style="transform-origin:121px 254px">${forme}</g></g><g clip-path="url(#rcd-${u})"><g class="rc-moitie-d" style="transform-origin:121px 254px">${forme}</g></g>
<polyline class="rc-fente" points="${fente}" fill="none" stroke="#FFF8D6" stroke-width="2.2" stroke-linejoin="round"/></g>
<g transform="translate(125 178)"><path class="rc-etoile" d="${eclat4(18)}" fill="#FFFBE6"/></g>`;
  },
  figure(c) {
    const flammes = 'M26 350 L18 268 L42 300 L38 216 L64 262 L68 166 L92 214 L102 96 L118 150 L125 40 L134 150 L150 92 L160 214 L184 164 L188 262 L214 216 L210 300 L234 268 L226 350 Z';
    return `<path class="rc-aura" d="${flammes}" fill="url(#rca-${c.u})"/><path class="rc-aura b" d="${flammes}" fill="url(#rca-${c.u})" opacity=".6"/>${foudre([[14, 150], [236, 22], [240, 330], [20, 336]], 125, 150, 300 + c.rang.charCodeAt(0))}<g class="rc-buste">${corps(c)}${c.rang === 'R' ? roi(c) : c.rang === 'D' ? dame(c) : valet(c)}</g>`;
  },
};
