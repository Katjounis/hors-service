// L-004 Trou Noir (version 2) : le dos de la première version ; au recto, cosmonautes couronnés devant l'horizon,
// enseignes étirées vers le centre, as en forme de trou noir.
import v1 from '../dos/l004-trou-noir.mjs';
import { L, H, cadre, semis, n, enseigne, ENSEIGNES, eclat4, miroir } from '../outils.mjs';
const OR = '#FF9F1C', OR2 = '#FF7A1A', CREME = '#FFF3D6', VIO = '#7B2FF7', ENCRE = '#2a2620';
const ANN = [[92, 26, 4.5, VIO, '60 20 26 12', 9], [78, 21, 4.5, OR2, '44 12 20 8', 6.5], [64, 16.5, 4, OR, '34 10 14 8', 5], [52, 12.5, 3, CREME, '24 7 9 5', 3.6]];
const disque = (cx, cy, clip, k = 1, op = 1) => ANN.map(([rx, ry, ep, coul, tirets, t]) => { const fin = -tirets.split(' ').map(Number).reduce((a, b) => a + b, 0) * 4; return `<ellipse class="l04-anneau" style="--t:${t * 4}s;--fin:${fin}" cx="${cx}" cy="${cy}" rx="${n(rx * k)}" ry="${n(ry * k)}" fill="none" stroke="${coul}" stroke-width="${n(ep * k)}" stroke-dasharray="${tirets}" stroke-linecap="round" opacity="${op}"${clip ? ` clip-path="url(#${clip})"` : ''}/>`; }).join('');
const VISIERE = 'M86 176 C86 146 164 146 164 176 C164 208 148 222 125 222 C102 222 86 208 86 176 Z';
const bras = (u) => `<path d="M82 268 L56 214 L36 224 L50 284 Z" fill="url(#tns-${u})" stroke="${ENCRE}" stroke-width="1.2" stroke-linejoin="round"/><path d="M46 240 L66 230 L70 240 L49 251 Z" fill="${OR2}"/><circle cx="44" cy="212" r="12" fill="${OR2}" stroke="${ENCRE}" stroke-width="1.2"/><path d="M38 208 H50 M38 214 H50" stroke="${ENCRE}" stroke-width=".9" opacity=".6"/>`;
// le cosmonaute : sac, combinaison, col, casque, visière où se reflète le disque
const cosmo = (c, derriere, devant) => { const u = c.u; const bande = `<path d="M50 304 L78 292 L83 305 L54 318 Z" fill="${OR2}"/>`;
  return `<circle cx="125" cy="172" r="96" fill="url(#l04l-${u})"/><circle class="l04-photon" style="transform-origin:125px 172px" cx="125" cy="172" r="73" fill="none" stroke="${CREME}" stroke-width="2.4"/><circle cx="125" cy="172" r="78" fill="none" stroke="${OR}" stroke-width="5" opacity=".28"/>
<g class="l04-flotte">${derriere || ''}
<rect x="72" y="224" width="106" height="110" rx="18" fill="#6f6a5e" stroke="${ENCRE}" stroke-width="1.2"/>
<path d="M36 350 C38 298 60 266 96 252 L154 252 C190 266 212 298 214 350 Z" fill="url(#tns-${u})" stroke="${ENCRE}" stroke-width="1.3"/>
<path d="M125 252 L154 252 C190 266 212 298 214 350 L125 350 Z" fill="#000" opacity=".14"/>
<path d="M72 302 L64 350 M178 302 L186 350" stroke="#8f897a" stroke-width="1.4"/>${bande}${miroir(bande)}
<circle cx="125" cy="302" r="20" fill="#0b0b14" stroke="${OR}" stroke-width="1.8"/>${enseigne(c.ens, 125, 302, 25, `fill="${c.encre}"`)}
<circle class="l04-led" style="--i:0" cx="94" cy="286" r="3.2" fill="#7CFFB2"/><circle class="l04-led" style="--i:1" cx="94" cy="298" r="3.2" fill="${OR}"/><circle class="l04-led" style="--i:2" cx="156" cy="286" r="3.2" fill="#FF5964"/>
<ellipse cx="125" cy="247" rx="43" ry="10.5" fill="#9a9486" stroke="${ENCRE}" stroke-width="1.2"/><ellipse cx="125" cy="244" rx="36" ry="7" fill="#d2ccba"/>
<circle cx="125" cy="178" r="57" fill="url(#tns-${u})" stroke="${ENCRE}" stroke-width="1.4"/>
<path d="M125 121 A57 57 0 0 1 125 235 A38 57 0 0 0 125 121 Z" fill="#000" opacity=".13"/>
<clipPath id="l04v-${u}"><path d="${VISIERE}"/></clipPath>
<path d="${VISIERE}" fill="#07060f" stroke="${OR}" stroke-width="2.6"/>
<g clip-path="url(#l04v-${u})"><ellipse cx="118" cy="188" rx="60" ry="26" fill="url(#l04l-${u})"/>${disque(118, 188, '', 0.56)}<circle cx="118" cy="188" r="9" fill="#000"/><circle class="l04-photon" style="transform-origin:118px 188px" cx="118" cy="188" r="10" fill="none" stroke="${CREME}" stroke-width="1.2"/>
<circle cx="98" cy="162" r="1.2" fill="#fff"/><circle cx="150" cy="166" r="1" fill="#fff"/><circle cx="142" cy="204" r="1.2" fill="#fff"/><circle cx="104" cy="210" r=".9" fill="#fff"/>
<g transform="skewX(-20)"><rect class="l04-glint" x="60" y="140" width="16" height="92" fill="#fff" opacity=".3"/></g></g>
<path d="M93 166 C97 153 108 149 119 149" fill="none" stroke="#fff" stroke-width="2.6" stroke-linecap="round" opacity=".65"/>
${devant || ''}</g>`; };
const etoileEnOr = (x, y, r, cl = 'l04-etoile') => `<g transform="translate(${x} ${y})"><path class="${cl}" d="${eclat4(r)}" fill="${CREME}"/></g>`;
const roi = (c) => { const u = c.u;
  return cosmo(c, '', `<path d="M168 268 L194 214 L214 224 L200 284 Z" fill="url(#tns-${u})" stroke="${ENCRE}" stroke-width="1.2" stroke-linejoin="round"/><path d="M184 240 L204 231 L201 251 L180 251 Z" fill="${OR2}"/>
<path d="M198 240 L216 96" stroke="#8a5a00" stroke-width="6" stroke-linecap="round"/><path d="M198 240 L216 96" stroke="url(#l04o-${u})" stroke-width="3.6" stroke-linecap="round"/>
<circle cx="217" cy="84" r="12" fill="#B5179E" stroke="${CREME}" stroke-width="1"/><path d="M207 80 Q217 88 227 80" fill="none" stroke="#FF8ad8" stroke-width="2" opacity=".7"/>
<g transform="rotate(-22 217 84)"><ellipse class="l04-anneau" style="--t:2.4s;--fin:-60" cx="217" cy="84" rx="21" ry="5.5" fill="none" stroke="${CREME}" stroke-width="2" stroke-dasharray="20 10"/></g>
<circle cx="206" cy="214" r="12" fill="${OR2}" stroke="${ENCRE}" stroke-width="1.2"/><path d="M200 210 H212 M200 216 H212" stroke="${ENCRE}" stroke-width=".9" opacity=".6"/>
<g class="l04-couronne"><path d="M101 116 L95 86 L110 102 L125 76 L140 102 L155 86 L149 116 Z" fill="url(#l04o-${u})" stroke="#7a4a00" stroke-width="1.6" stroke-linejoin="round"/><rect x="100" y="110" width="50" height="9" rx="2" fill="#FFE7B0" stroke="#7a4a00" stroke-width="1.2"/><circle cx="125" cy="114.5" r="2.6" fill="#B5179E"/><circle cx="112" cy="114.5" r="2" fill="${VIO}"/><circle cx="138" cy="114.5" r="2" fill="${VIO}"/><circle cx="95" cy="85" r="3.2" fill="${CREME}"/><circle cx="125" cy="75" r="3.6" fill="${CREME}"/><circle cx="155" cy="85" r="3.2" fill="${CREME}"/></g>
${etoileEnOr(78, 104, 6)}${etoileEnOr(172, 110, 5, 'l04-etoile b')}`); };
const dame = (c) => { const u = c.u;
  const ronde = Array.from({ length: 9 }, (_, i) => { const a = (i / 9) * Math.PI * 2; return `<path transform="translate(${n(125 + Math.cos(a) * 67)} ${n(178 + Math.sin(a) * 67)})" d="${eclat4(i % 3 ? 4 : 6.5)}" fill="${i % 3 ? CREME : OR}"/>`; }).join('');
  return cosmo(c, '', `${bras(u)}
<g transform="translate(44 178)"><circle class="l04-photon" style="transform-origin:0 0" r="19" fill="url(#l04l-${u})"/><path class="l04-etoile" d="${eclat4(17)}" fill="${CREME}"/><path class="l04-etoile b" d="${eclat4(9, .3)}" fill="${OR}"/></g>
<g transform="rotate(20 44 178)"><ellipse class="l04-anneau" style="--t:3s;--fin:-52" cx="44" cy="178" rx="26" ry="7" fill="none" stroke="${OR}" stroke-width="1.6" stroke-dasharray="6 7"/></g>
<path d="M106 128 L110 108 L118 120 L125 100 L132 120 L140 108 L144 128 Q125 118 106 128 Z" fill="url(#l04o-${u})" stroke="#7a4a00" stroke-width="1.4" stroke-linejoin="round"/><circle cx="125" cy="99" r="3.2" fill="${CREME}"/><path d="M125 116 l3.2 4.2 -3.2 4.2 -3.2 -4.2z" fill="#B5179E"/>
<g class="l04-ronde" style="transform-origin:125px 178px">${ronde}</g>`); };
const valet = (c) => { const u = c.u;
  return cosmo(c, `<path d="M47 322 L40 140" stroke="#5c574c" stroke-width="5" stroke-linecap="round"/><path d="M47 322 L40 140" stroke="#d2ccba" stroke-width="2.6" stroke-linecap="round"/><g class="l04-fanion"><path d="M41 144 C58 150 74 146 92 156 C76 164 58 162 42 174 Z" fill="${OR2}" stroke="${ENCRE}" stroke-width="1"/><g transform="translate(58 158)"><path d="${eclat4(6)}" fill="${CREME}"/></g></g>`,
    `${bras(u)}<path d="M150 132 L168 98" stroke="${ENCRE}" stroke-width="3.4" stroke-linecap="round"/><path d="M150 132 L168 98" stroke="#d2ccba" stroke-width="1.6" stroke-linecap="round"/><circle class="l04-led" style="--i:1" cx="169" cy="95" r="5" fill="#FF5964"/><circle cx="169" cy="95" r="9" fill="#FF5964" opacity=".25" class="l04-led" style="--i:1"/>
<path d="M72 160 C78 132 104 120 125 120 C146 120 172 132 178 160 C160 140 142 134 125 134 C108 134 90 140 72 160 Z" fill="${OR2}" stroke="${ENCRE}" stroke-width="1.1"/>`); };

export default {
  ...v1, aura: ['#FF9F1C', '#7B2FF7'],
  bouge: 'Dos : le disque de matière tourne, chaque anneau à sa vitesse, neuf étoiles sont aspirées en spirale. Recto : le roi, la dame et le valet sont des cosmonautes qui flottent, le disque se reflète dans leur visière, les voyants clignotent, la couronne dérive en apesanteur. Sur les chiffres, chaque enseigne s’étire vers le centre et perd un filet de lumière. L’as est un trou noir en forme d’enseigne.',
  retournement: 'La carte est avalée en tournant, puis recrachée de l’autre côté dans une onde orange.',
  face: { papier: '#000000', encre: '#F5F2EA', rouge: '#FF5964', sombre: true, contour: '#000', contourEp: 7, reflet: '#FFE7B0', onglet: '#000', ongletOp: 0.6 },
  css: v1.css + `
.l04-cadre { animation: l04-cadre 12s linear infinite; }
@keyframes l04-cadre { to { stroke-dashoffset: -400; } }
.l04-etire { animation: l04-etire 3.6s ease-in-out infinite; animation-delay: calc(var(--i) * -.41s); }
@keyframes l04-etire { 0%, 100% { transform: scaleX(1) translateX(0); } 50% { transform: scaleX(1.2) translateX(3px); } }
.l04-trainee { animation: l04-trainee 1.1s linear infinite; animation-delay: calc(var(--i) * -.17s); }
@keyframes l04-trainee { to { stroke-dashoffset: -32; } }
.l04-flotte { transform-origin: 125px 240px; animation: l04-flotte 6s ease-in-out infinite; }
@keyframes l04-flotte { 0%, 100% { transform: translateY(1px) rotate(-2.2deg); } 50% { transform: translateY(-6px) rotate(2.2deg); } }
.l04-led { animation: l04-led 1.8s steps(1) infinite; animation-delay: calc(var(--i) * .6s); }
@keyframes l04-led { 0%, 55% { opacity: 1; } 56%, 100% { opacity: .18; } }
.l04-glint { animation: l04-glint 5s ease-in-out infinite; }
@keyframes l04-glint { 0%, 55% { transform: translateX(0); } 100% { transform: translateX(175px); } }
.l04-etoile { animation: l04-etoile 2.8s ease-in-out infinite; }
.l04-etoile.b { animation-delay: -1.4s; animation-direction: reverse; }
@keyframes l04-etoile { 0%, 100% { transform: rotate(0deg) scale(.65); opacity: .7; } 50% { transform: rotate(90deg) scale(1.2); opacity: 1; } }
.l04-couronne { transform-box: fill-box; transform-origin: center; animation: l04-couronne 5.4s ease-in-out infinite; }
@keyframes l04-couronne { 0%, 100% { transform: translate(-3px, 0) rotate(-7deg); } 50% { transform: translate(3px, -8px) rotate(8deg); } }
.l04-ronde { animation: l04-tourne 22s linear infinite; }
.l04-fanion { transform-origin: 41px 159px; animation: l04-fanion 1.7s ease-in-out infinite alternate; }
@keyframes l04-fanion { from { transform: skewY(-5deg) scaleX(.94); } to { transform: skewY(5deg) scaleX(1.03); } }
`,
  recto(c) {
    const u = c.u; const fig = 'VDR'.includes(c.rang); const cy = fig ? 172 : 176;
    const etoiles = semis(44, 3 + c.num + c.rang.charCodeAt(0), { r0: .5, r1: 1.4, duree: [1.6, 4.5] }).map((e, i) => `<circle${i % 3 === 0 ? ` class="l04-scintille" style="--t:${e.t}s;--d:${e.d}s"` : ''} cx="${e.x}" cy="${e.y}" r="${e.r}" fill="${i % 7 === 0 ? '#C4B5FD' : i % 5 === 0 ? '#FFD9A8' : '#fff'}" opacity="${i % 3 === 0 ? 1 : .5}"/>`).join('');
    const chutes = Array.from({ length: 7 }, (_, i) => `<circle class="l04-chute" style="--i:${i};--a:${i * 51}deg;transform-origin:125px ${cy}px" cx="245" cy="${cy}" r="${i % 3 === 0 ? 2.4 : 1.7}" fill="${i % 2 ? '#FFE7B0' : '#fff'}"/>`).join('');
    return {
      fond: `<defs><radialGradient id="tnf-${u}" cx="50%" cy="${n(cy / 3.5)}%" r="72%"><stop offset="0" stop-color="#1c0b3a"/><stop offset=".5" stop-color="#090414"/><stop offset="1" stop-color="#000"/></radialGradient>
<linearGradient id="tnb-${u}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${OR}"/><stop offset=".5" stop-color="${CREME}"/><stop offset="1" stop-color="${VIO}"/></linearGradient>
<radialGradient id="l04l-${u}"><stop offset="0" stop-color="${OR}" stop-opacity=".55"/><stop offset=".6" stop-color="${VIO}" stop-opacity=".2"/><stop offset="1" stop-color="${VIO}" stop-opacity="0"/></radialGradient>
<linearGradient id="tnt-${u}" gradientUnits="userSpaceOnUse" x1="0" y1="0" x2="112" y2="0"><stop offset="0" stop-color="${CREME}" stop-opacity=".95"/><stop offset="1" stop-color="${OR}" stop-opacity="0"/></linearGradient>
<linearGradient id="tns-${u}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#FBF8EE"/><stop offset="1" stop-color="#BDB6A4"/></linearGradient>
<linearGradient id="l04o-${u}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFE7B0"/><stop offset="1" stop-color="${OR}"/></linearGradient></defs>
${cadre(`fill="url(#tnf-${u})"`)}<g class="l04-ciel" style="transform-origin:125px ${cy}px">${etoiles}</g>`,
      bord: `<rect class="l04-cadre" x="7" y="7" width="${L - 14}" height="${H - 14}" rx="16" fill="none" stroke="url(#tnb-${u})" stroke-width="2.2" stroke-dasharray="150 30 40 30 90 60" stroke-linecap="round"/><rect x="12" y="12" width="${L - 24}" height="${H - 24}" rx="12" fill="none" stroke="${VIO}" stroke-width=".8" opacity=".6"/>`,
      devant: chutes,
    };
  },
  // au centre des cartes à chiffres : un petit trou noir qui tire tout à lui
  liens(c) {
    return `<ellipse cx="125" cy="176" rx="70" ry="30" fill="url(#l04l-${c.u})"/>${disque(125, 176, '', 0.5, 0.85)}<circle cx="125" cy="176" r="9" fill="#000"/><circle class="l04-photon" style="transform-origin:125px 176px" cx="125" cy="176" r="10" fill="none" stroke="${CREME}" stroke-width="1.2"/>`;
  },
  pip(c, p, i) {
    const dx = 125 - p.x, dy = 176 - p.y, d = Math.hypot(dx, dy), a = d < 2 ? -90 : n((Math.atan2(dy, dx) * 180) / Math.PI);
    const trainee = d < 2 ? '' : `<line class="l04-trainee" style="--i:${i}" x1="${n(p.t * .45)}" y1="0" x2="${n(Math.max(d - 12, p.t * .6))}" y2="0" stroke="url(#tnt-${c.u})" stroke-width="2.2" stroke-dasharray="7 9" stroke-linecap="round"/>`;
    return `<g transform="translate(${p.x} ${p.y}) rotate(${a})">${trainee}<g class="l04-etire" style="--i:${i}"><g transform="rotate(${n(-a + (p.bas ? 180 : 0))}) translate(${n(-p.t / 2)} ${n(-p.t / 2)}) scale(${n(p.t / 24, 3)})"><path d="${ENSEIGNES[c.ens]}" fill="none" stroke="${OR}" stroke-width="3.6" opacity=".4" stroke-linejoin="round"/><path d="${ENSEIGNES[c.ens]}" fill="${c.encre}" stroke="#000" stroke-width=".5" stroke-linejoin="round"/></g></g></g>`;
  },
  as(c) {
    const u = c.u, T = 120, cy = 176, k = n(T / 24, 3);
    const f = (attrs) => `<g transform="translate(${125 - T / 2} ${cy - T / 2}) scale(${k})"><path d="${ENSEIGNES[c.ens]}" ${attrs}/></g>`;
    return `<defs><clipPath id="tnh-${u}"><rect x="0" y="0" width="250" height="${cy}"/></clipPath><clipPath id="tnba-${u}"><rect x="0" y="${cy}" width="250" height="${H - cy}"/></clipPath></defs>
<ellipse cx="125" cy="${cy}" rx="124" ry="64" fill="url(#l04l-${u})"/>
${disque(125, cy, `tnh-${u}`, 1.26)}
<g class="l04-photon" style="transform-origin:125px ${cy}px">${f(`fill="none" stroke="${c.encre}" stroke-width="3" opacity=".3" stroke-linejoin="round"`)}</g>
${f(`fill="#000" stroke="${c.encre}" stroke-width="1.15" stroke-linejoin="round"`)}
${f(`fill="${c.encre}" opacity=".2"`)}
${disque(125, cy, `tnba-${u}`, 1.26)}
${etoileEnOr(78, 96, 7)}${etoileEnOr(188, 262, 6, 'l04-etoile b')}`;
  },
  figure(c) { return c.rang === 'R' ? roi(c) : c.rang === 'D' ? dame(c) : valet(c); },
};
