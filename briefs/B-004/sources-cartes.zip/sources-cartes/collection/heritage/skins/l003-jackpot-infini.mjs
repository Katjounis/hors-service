// L-003 Jackpot Infini (version 2) : la machine à sous au dos ; au recto, statues d'or du casino (le Flambeur, Dame Chance,
// le Croupier), enseignes frappées sur des jetons qui se retournent, as sur un jeton géant.
import v1 from '../dos/l003-jackpot-infini.mjs';
import { L, H, cadre, n, enseigne, ENSEIGNES, eclat4, miroir } from '../outils.mjs';
const IVOIRE = '#FFF9EA', OR = '#F5B301', OR2 = '#FFD23F', OR3 = '#FFF1A8', BRUN = '#7a4a00', ROUGE = '#C8102E', NOIR = '#17120A', ROSE = '#FF4FA3', VERT = '#0B6B3A';
const TETE = 'M97 158 C97 128 153 128 153 158 C153 190 142 208 125 208 C108 208 97 190 97 158 Z';
const INFINI = 'M125 150 C100 118 52 118 52 150 C52 182 100 182 125 150 C150 118 198 118 198 150 C198 182 150 182 125 150 Z';
const jeton = (c, x, y, r, t, i, bas, cl = 'jk-jeton') => { const bord = c.rouge ? ROUGE : NOIR; const pas = n((2 * Math.PI * (r - 2.4)) / 16, 2);
  return `<g transform="translate(${x} ${y})"><circle cx="1.5" cy="3.5" r="${r}" fill="#000" opacity=".2"/><g class="${cl}" style="--i:${i}"><circle r="${r}" fill="${bord}"/><circle class="jk-crans" r="${n(r - 2.4)}" fill="none" stroke="#fff" stroke-width="${n(Math.max(3.2, r * .2))}" stroke-dasharray="${pas} ${pas}"/><circle r="${n(r * .76)}" fill="#FFFDF4" stroke="${OR}" stroke-width="${n(Math.max(1, r * .05))}"/><g${bas ? ' transform="rotate(180)"' : ''}>${enseigne(c.ens, 0, 0, t, `fill="${c.encre}"`)}</g></g></g>`; };
const or = (u) => `fill="url(#jkg-${u})" stroke="${BRUN}" stroke-width="1.1"`;
const tete = (u) => `<path d="M112 206 C112 232 110 248 106 258 L144 258 C140 248 138 232 138 206 Z" ${or(u)}/><circle cx="97" cy="166" r="6" ${or(u)}/><circle cx="153" cy="166" r="6" ${or(u)}/><path d="${TETE}" ${or(u)}/><path d="M125 168 L122 180 L127 181" fill="none" stroke="${BRUN}" stroke-width="1" opacity=".7" stroke-linecap="round"/>
<clipPath id="jkt-${u}"><path d="${TETE}"/></clipPath><g clip-path="url(#jkt-${u})"><g transform="skewX(-20)"><rect class="jk-brille" x="80" y="120" width="13" height="96" fill="#fff" opacity=".6"/></g></g>`;
const epingle = (c) => jeton(c, 92, 304, 14, 17, 0, false, 'jk-fixe');
const main = (x, y, u) => `<circle cx="${x}" cy="${y}" r="11" ${or(u)}/>`;
const roi = (c) => { const u = c.u; const revers = `<path d="M96 254 L125 302 L107 318 L82 262 Z" fill="#2c261c" stroke="#000" stroke-width=".8"/>`;
  return `<path d="M34 350 C36 300 58 268 96 254 L154 254 C192 268 214 300 216 350 Z" fill="${NOIR}"/><path d="M108 256 L125 304 L142 256 Z" fill="#FFFDF4"/>${revers}${miroir(revers)}
<circle cx="125" cy="318" r="2.6" fill="${OR}"/><circle cx="125" cy="332" r="2.6" fill="${OR}"/>
<g transform="translate(0 18)">${tete(u)}
<path d="M99 155 H151 V160 C151 173 143 179 137 179 C131 179 127 173 127 164 H123 C123 173 119 179 113 179 C107 179 99 173 99 160 Z" fill="${NOIR}"/>
<clipPath id="jkl-${u}"><path d="M99 155 H151 V160 C151 173 143 179 137 179 C131 179 127 173 127 164 H123 C123 173 119 179 113 179 C107 179 99 173 99 160 Z"/></clipPath>
<g clip-path="url(#jkl-${u})"><g transform="skewX(-28)"><rect class="jk-lunette" x="170" y="150" width="6" height="34" fill="#fff" opacity=".85"/><rect class="jk-lunette" x="181" y="150" width="2.5" height="34" fill="#fff" opacity=".7"/></g></g>
<path d="M125 187 C118 181 108 185 103 194 C112 191 120 194 125 191 C130 194 138 191 147 194 C142 185 132 181 125 187 Z" fill="${BRUN}"/><path d="M117 199 Q125 205 133 199" fill="none" stroke="${BRUN}" stroke-width="1.6" stroke-linecap="round"/>
<g class="jk-chapeau"><path d="M100 136 L105 72 H147 L152 136 Z" fill="${NOIR}"/><path d="M101 124 L102.4 110 H149.6 L151 124 Z" fill="${ROUGE}"/><rect x="118" y="108" width="14" height="18" rx="2" fill="url(#jkg-${u})" stroke="${BRUN}" stroke-width=".8"/><text x="125" y="122.5" text-anchor="middle" font-family="'Alfa Slab One', Georgia, serif" font-size="13" fill="${ROUGE}">7</text><rect x="84" y="132" width="84" height="9" rx="4.5" fill="${NOIR}"/><path d="M110 78 L112 104" stroke="#fff" stroke-width="2" opacity=".25" stroke-linecap="round"/></g></g>
<path d="M125 262 L107 251 L107 275 Z M125 262 L143 251 L143 275 Z" fill="${ROUGE}" stroke="#7a0a1c" stroke-width=".8"/><circle cx="125" cy="262" r="4.4" fill="${ROUGE}" stroke="#7a0a1c" stroke-width=".8"/>
<path d="M170 272 L192 216 L213 226 L200 288 Z" fill="${NOIR}"/><path d="M190 222 L211 232 L208 242 L187 232 Z" fill="#FFFDF4"/>${main(204, 212, u)}
<g transform="translate(206 168)"><g class="jk-lance"><g class="jk-pile"><circle r="14" fill="url(#jkg-${u})" stroke="${BRUN}" stroke-width="1.4"/><circle r="10" fill="none" stroke="${BRUN}" stroke-width=".9" opacity=".7"/><path d="${eclat4(7, .32)}" fill="${BRUN}"/></g></g></g>
${epingle(c)}`; };
const dame = (c) => { const u = c.u;
  const plume = (a, coul, i) => `<g transform="translate(125 116) rotate(${a})"><g class="jk-plume" style="--i:${i}"><path d="M0 0 C-12 -24 -10 -52 0 -70 C10 -52 12 -24 0 0 Z" fill="${coul}" stroke="${BRUN}" stroke-width=".8"/><path d="M0 -4 V-64" stroke="${BRUN}" stroke-width=".9" opacity=".6"/></g></g>`;
  const boucle = `<path d="M96 158 C82 180 86 212 100 230 C97 208 102 190 103 170 Z" fill="${NOIR}"/>`;
  const de = (x, y, i) => `<g transform="translate(${x} ${y})"><g class="jk-de" style="--i:${i}"><rect x="-10" y="-10" width="20" height="20" rx="4" fill="#fff" stroke="${NOIR}" stroke-width="1.2"/><circle cx="-4.5" cy="-4.5" r="2" fill="${ROUGE}"/><circle cx="4.5" cy="4.5" r="2" fill="${ROUGE}"/><circle r="2" fill="${ROUGE}"/></g></g>`;
  const pend = (x) => `<g transform="translate(${x} 172)"><g class="jk-pendule"><path d="M0 0 V8" stroke="${BRUN}" stroke-width="1"/><rect x="-4.5" y="8" width="9" height="9" rx="1.6" fill="#fff" stroke="${NOIR}" stroke-width=".9"/><circle cy="12.5" r="1.3" fill="${ROUGE}"/></g></g>`;
  return `<g transform="translate(0 18)">${plume(-30, ROUGE, 0)}${plume(30, ROUGE, 2)}${plume(0, OR2, 1)}</g>
<path d="M40 350 C44 304 62 274 92 260 C100 276 112 287 125 291 C138 287 150 276 158 260 C188 274 206 304 210 350 Z" fill="${ROUGE}" stroke="#7a0a1c" stroke-width="1"/>
<path d="M92 260 C100 249 112 245 125 245 C138 245 150 249 158 260 C150 276 138 287 125 291 C112 287 100 276 92 260 Z" ${or(u)}/>
<g transform="translate(0 18)">${boucle}${miroir(boucle)}</g>
<g transform="translate(0 18)">${tete(u)}
<path d="M93 166 C84 128 106 106 125 106 C144 106 166 128 157 166 C156 146 146 134 125 134 C104 134 94 146 93 166 Z" fill="${NOIR}"/>
<circle cx="125" cy="116" r="5.5" fill="url(#jkg-${u})" stroke="${BRUN}" stroke-width=".9"/>
<g transform="translate(101 150) scale(1.0)"><path d="${ENSEIGNES.H}" fill="${ROUGE}" stroke="${NOIR}" stroke-width="1.2"/></g><g transform="translate(125 150)"><path d="${ENSEIGNES.H}" fill="${ROUGE}" stroke="${NOIR}" stroke-width="1.2"/></g><path d="M122 160 H128" stroke="${NOIR}" stroke-width="1.6"/>
<path class="jk-scint" d="M106 156 l5 -3 M130 156 l5 -3" stroke="#fff" stroke-width="1.8" stroke-linecap="round"/>
<path d="M118 190 Q121.5 186.5 125 189 Q128.5 186.5 132 190 Q125 197 118 190 Z" fill="${ROUGE}"/>
${pend(95)}${pend(155)}</g>
${[0, 1, 2, 3, 4, 5, 6].map((i) => { const k = i / 6, x = 105 + k * 40, y = 262 + Math.sin(k * Math.PI) * 14; return `<circle cx="${n(x)}" cy="${n(y)}" r="2.8" fill="#FFFDF4" stroke="${BRUN}" stroke-width=".6"/>`; }).join('')}
<path d="M80 278 L54 222 L35 232 L52 292 Z" ${or(u)}/>${main(44, 216, u)}
${de(40, 178, 0)}${de(66, 158, 1)}
${jeton(c, 125, 316, 15, 18, 0, false, 'jk-fixe')}`; };
const valet = (c) => { const u = c.u; const jarretiere = `<path d="M186 228 L207 238 L205 246 L184 236 Z" fill="${ROUGE}"/>`;
  const carte = (a, i, e, coul) => `<g transform="translate(206 204)"><g class="jk-eventail" style="--a:${a}deg"><rect x="-12" y="-52" width="24" height="34" rx="3.5" fill="#FFFDF4" stroke="${NOIR}" stroke-width="1.1"/>${enseigne(e, 0, -35, 13, `fill="${coul}"`)}</g></g>`;
  return `<path d="M34 350 C36 300 58 268 96 254 L154 254 C192 268 214 300 216 350 Z" fill="#FFFDF4" stroke="${BRUN}" stroke-width="1"/>
<path d="M82 262 L125 322 L168 262 L178 350 L72 350 Z" fill="${NOIR}"/><circle cx="125" cy="336" r="2.6" fill="${OR}"/>
<g transform="translate(0 18)">${tete(u)}
<ellipse cx="113" cy="170" rx="3.4" ry="4.4" fill="${NOIR}"/><ellipse cx="137" cy="170" rx="3.4" ry="4.4" fill="${NOIR}"/><circle cx="114.2" cy="168.4" r="1.1" fill="#fff"/><circle cx="138.2" cy="168.4" r="1.1" fill="#fff"/>
<path d="M114 192 Q126 202 137 189" fill="none" stroke="${BRUN}" stroke-width="1.8" stroke-linecap="round"/>
<path d="M112 134 C114 120 122 116 128 122 C134 114 142 122 138 134 Z" fill="${BRUN}"/>
<path d="M97 152 C97 132 153 132 153 152 L153 158 H97 Z" fill="${VERT}" stroke="#063d21" stroke-width="1"/>
<path d="M90 157 H160 L170 174 Q125 162 80 174 Z" fill="${VERT}" opacity=".82" stroke="#063d21" stroke-width="1"/></g>
<path d="M125 262 L108 252 L108 274 Z M125 262 L142 252 L142 274 Z" fill="${VERT}" stroke="#063d21" stroke-width=".8"/><circle cx="125" cy="262" r="4.2" fill="${VERT}" stroke="#063d21" stroke-width=".8"/>
<path d="M170 272 L192 216 L213 226 L200 288 Z" fill="#FFFDF4" stroke="${BRUN}" stroke-width="1"/>${jarretiere}
${carte(-26, 0, 'H', ROUGE)}${carte(0, 1, 'S', NOIR)}${carte(26, 2, 'D', ROUGE)}
${main(205, 210, u)}
${epingle(c)}`; };

export default {
  ...v1, aura: ['#F5B301', '#FF4FA3'],
  bouge: 'Dos : les trois rouleaux tournent et s’arrêtent sur 7-7-7, la manette s’abaisse, les pièces tombent, le néon infini court. Recto : le Flambeur lance sa pièce, Dame Chance fait rouler ses dés et ses plumes ondulent, le Croupier ouvre son éventail de cartes ; l’or brille par vagues. Sur les chiffres, chaque enseigne est frappée sur un jeton qui se retourne, l’un après l’autre. L’as est un jeton géant sous le néon infini.',
  retournement: 'La carte rebondit, une gerbe de pièces et de jetons jaillit.',
  face: { papier: IVOIRE, encre: NOIR, rouge: ROUGE, sombre: false, contour: IVOIRE, contourEp: 7, reflet: '#FFFFFF', onglet: IVOIRE, ongletOp: 0.6 },
  css: v1.css + `
.jk-soleil { transform-origin: 125px 175px; animation: jk-soleil 50s linear infinite; }
@keyframes jk-soleil { to { transform: rotate(360deg); } }
.jk-jeton { animation: jk-jeton 5.6s ease-in-out infinite; animation-delay: calc(var(--i) * .17s); }
@keyframes jk-jeton { 0%, 74%, 100% { transform: scaleX(1) translateY(0); } 80% { transform: scaleX(.06) translateY(-5px); } 86% { transform: scaleX(1) translateY(-5px); } 92% { transform: scaleX(1) translateY(0); } }
.jk-crans { animation: jk-soleil 7s linear infinite; transform-origin: 0 0; }
.jk-brille { animation: jk-brille 4.4s ease-in-out infinite; }
@keyframes jk-brille { 0%, 50% { transform: translateX(0); } 100% { transform: translateX(150px); } }
.jk-lunette { animation: jk-lunette 3.8s ease-in-out infinite; }
@keyframes jk-lunette { 0%, 40% { transform: translateX(0); } 100% { transform: translateX(84px); } }
.jk-chapeau { transform-origin: 125px 136px; transform: rotate(-5deg); animation: jk-chapeau 2.8s ease-in-out infinite alternate; }
@keyframes jk-chapeau { from { transform: rotate(-7deg); } to { transform: rotate(-2deg) translateY(-1.5px); } }
.jk-lance { animation: jk-lance 1.5s cubic-bezier(.3, 0, .7, 1) infinite alternate; }
@keyframes jk-lance { from { transform: translateY(22px); } to { transform: translateY(-64px); } }
.jk-pile { animation: jk-pile .5s linear infinite; }
@keyframes jk-pile { 0%, 100% { transform: scaleY(1); } 50% { transform: scaleY(.1); } }
.jk-plume { animation: jk-plume 2.6s ease-in-out infinite alternate; animation-delay: calc(var(--i) * -.6s); }
@keyframes jk-plume { from { transform: rotate(-6deg); } to { transform: rotate(7deg) scaleY(1.04); } }
.jk-pendule { animation: jk-pendule 1.3s ease-in-out infinite alternate; }
@keyframes jk-pendule { from { transform: rotate(-16deg); } to { transform: rotate(16deg); } }
.jk-de { animation: jk-de 2.2s ease-in-out infinite; animation-delay: calc(var(--i) * -.9s); }
@keyframes jk-de { 0%, 100% { transform: translateY(8px) rotate(0deg); } 50% { transform: translateY(-16px) rotate(200deg); } }
.jk-eventail { transform: rotate(var(--a)); animation: jk-eventail 3.6s ease-in-out infinite; }
@keyframes jk-eventail { 0%, 12%, 100% { transform: rotate(0deg); } 30%, 82% { transform: rotate(var(--a)); } }
.jk-scint { animation: jk-scint 2.2s ease-in-out infinite; }
@keyframes jk-scint { 0%, 100% { opacity: .2; } 50% { opacity: 1; } }
.jk-infini { animation: jk-infini 2.6s linear infinite; }
@keyframes jk-infini { to { stroke-dashoffset: -440; } }
.jk-pluie { opacity: 0; animation: jk-pluie var(--t) linear infinite; animation-delay: var(--d); }
@keyframes jk-pluie { 0% { transform: translate(var(--x), -20px) scaleX(1); opacity: 0; } 8% { opacity: .9; } 25% { transform: translate(var(--x), 78px) scaleX(.15); } 50% { transform: translate(var(--x), 176px) scaleX(1); } 75% { transform: translate(var(--x), 274px) scaleX(.15); } 92% { opacity: .9; } 100% { transform: translate(var(--x), 372px) scaleX(1); opacity: 0; } }
.jk-geant { animation: jk-geant 5.6s ease-in-out infinite; }
@keyframes jk-geant { 0%, 62%, 100% { transform: scaleX(1); } 70% { transform: scaleX(.04); } 78% { transform: scaleX(1); } 84% { transform: scaleX(1.06) scaleY(1.06); } 90% { transform: scaleX(1); } }
`,
  recto(c) {
    const u = c.u; const fig = 'VDR'.includes(c.rang);
    const rayons = Array.from({ length: 16 }, (_, i) => `<path transform="rotate(${i * 22.5} 125 175)" d="M125 175 L${125 - 20} -110 L${125 + 20} -110 Z" fill="${i % 2 ? '#FBE3A0' : '#FFF1C4'}"/>`).join('');
    const amp = (pair) => { const o = []; for (let i = 0; i < 7; i++) { const x = 30 + i * 31.67; if (i % 2 === pair) { o.push([x, 8.5], [x, H - 8.5]); } } for (let i = 0; i < 10; i++) { const y = 34 + i * 31.33; if (i % 2 === pair) { o.push([8.5, y], [L - 8.5, y]); } } return o.map(([x, y]) => `<circle cx="${n(x)}" cy="${n(y)}" r="3.4" fill="${OR3}" stroke="${BRUN}" stroke-width=".6"/>`).join(''); };
    const pluie = Array.from({ length: 5 }, (_, i) => `<g class="jk-pluie" style="--x:${[22, 232, 60, 196, 228][i]}px;--t:${[4.2, 5, 5.8, 4.6, 6.2][i]}s;--d:${[-1, -2.6, -4, -0.4, -3.2][i]}s"><circle r="7" fill="url(#jkg-${u})" stroke="${BRUN}" stroke-width="1"/><circle r="4.4" fill="none" stroke="${BRUN}" stroke-width=".7" opacity=".7"/></g>`).join('');
    return {
      fond: `<defs><linearGradient id="jkg-${u}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${OR3}"/><stop offset=".5" stop-color="${OR}"/><stop offset="1" stop-color="#B97A00"/></linearGradient>
<radialGradient id="jkc-${u}"><stop offset="0" stop-color="#fff" stop-opacity="1"/><stop offset=".6" stop-color="#fff" stop-opacity=".7"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></radialGradient></defs>
${cadre(`fill="${IVOIRE}"`)}<g class="jk-soleil">${rayons}</g><circle cx="125" cy="175" r="${fig ? 128 : 112}" fill="url(#jkc-${u})"/>${pluie}
`,
      bord: `<rect x="8.5" y="8.5" width="${L - 17}" height="${H - 17}" rx="15" fill="none" stroke="${ROUGE}" stroke-width="10"/><rect x="3" y="3" width="${L - 6}" height="${H - 6}" rx="19.5" fill="none" stroke="${OR}" stroke-width="1.4"/><rect x="14" y="14" width="${L - 28}" height="${H - 28}" rx="10" fill="none" stroke="${OR}" stroke-width="1.4"/><g class="jk-amp">${amp(0)}</g><g class="jk-amp b">${amp(1)}</g>`,
      devant: `<g transform="translate(34 196)"><path class="jk-eclat" style="--d:0s" d="${eclat4(8)}" fill="${OR}"/></g><g transform="translate(214 140)"><path class="jk-eclat" style="--d:-.8s" d="${eclat4(7)}" fill="${OR}"/></g><g transform="translate(196 40)"><path class="jk-eclat" style="--d:-1.5s" d="${eclat4(6)}" fill="${ROSE}"/></g>`,
    };
  },
  pip(c, p, i) { return jeton(c, p.x, p.y, n(p.t / 2 + 3.5), n(p.t * .74), i, p.bas); },
  as(c) {
    const u = c.u; const bas = 'M125 276 C108 256 78 256 78 276 C78 296 108 296 125 276 C142 256 172 256 172 276 C172 296 142 296 125 276 Z';
    return `<path d="${bas}" fill="none" stroke="${ROSE}" stroke-width="12" opacity=".22"/><path d="${bas}" fill="none" stroke="${ROSE}" stroke-width="5"/><path class="jk-infini" d="${bas}" fill="none" stroke="#fff" stroke-width="2.2" stroke-dasharray="36 404" stroke-linecap="round"/>
<g transform="translate(125 168)"><circle cx="2" cy="5" r="68" fill="#000" opacity=".2"/><g class="jk-geant"><circle r="68" fill="${c.rouge ? ROUGE : NOIR}"/><circle class="jk-crans" r="62" fill="none" stroke="#fff" stroke-width="12" stroke-dasharray="24.35 24.35"/><circle r="52" fill="#FFFDF4" stroke="${OR}" stroke-width="3"/><circle r="46" fill="none" stroke="${OR}" stroke-width="1" stroke-dasharray="2 4"/>${enseigne(c.ens, 0, 0, 66, `fill="${c.encre}"`)}</g></g>
${[[92, 78, 9, 0], [158, 78, 9, -.7], [125, 66, 11, -1.3]].map(([x, y, r, d]) => `<g transform="translate(${x} ${y})"><path class="jk-eclat" style="--d:${d}s" d="${eclat4(r)}" fill="${OR}"/></g>`).join('')}`;
  },
  figure(c) { return c.rang === 'R' ? roi(c) : c.rang === 'D' ? dame(c) : valet(c); },
};
