// E-001 Dragon de feu (épique) : la tête du dragon de face dans les flammes. Au recto, le roi, la dame et le valet sont des dragons ;
// chaque enseigne brûle, l'as est dans un cercle de feu. Animation en boucle plus calme que les légendaires.
import { L, H, cadre, hasard, n, enseigne, ENSEIGNES, eclat4, miroir } from '../outils.mjs';
import { flammes } from '../../kit/effets.mjs';
const OR = '#FFC94A', ORANGE = '#FF7A1A', BRAISE = '#FFE29A', SANG = '#7a0c0c', NUIT = '#150404';
const FLAMME = 'M0 0 C-11 -8 -13 -22 -5 -34 C-5 -26 0 -24 1 -30 C4 -40 0 -48 4 -58 C14 -44 18 -26 11 -10 C9 -4 5 -1 0 0 Z';
const flamme = (x, y, k, i, coul = ORANGE, a = 0) => `<g transform="translate(${x} ${y}) rotate(${a}) scale(${k})"><path class="df-flamme" style="--i:${i}" d="${FLAMME}" fill="${coul}" stroke="${NUIT}" stroke-width="${n(1.6 / k, 2)}" stroke-linejoin="round"/><g transform="scale(.5)"><path class="df-flamme" style="--i:${i + 2}" d="${FLAMME}" fill="${BRAISE}"/></g></g>`;
const defs = (u) => `<defs><radialGradient id="dff-${u}" cx="50%" cy="60%" r="80%"><stop offset="0" stop-color="#5a0f0a"/><stop offset=".55" stop-color="#2a0806"/><stop offset="1" stop-color="${NUIT}"/></radialGradient>
<linearGradient id="dfr-${u}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FF5A3C"/><stop offset=".5" stop-color="#C81E1E"/><stop offset="1" stop-color="#7a0c0c"/></linearGradient>
<linearGradient id="dfo-${u}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${BRAISE}"/><stop offset="1" stop-color="#C98A00"/></linearGradient>
<radialGradient id="dfl-${u}"><stop offset="0" stop-color="${ORANGE}" stop-opacity=".75"/><stop offset="1" stop-color="${ORANGE}" stop-opacity="0"/></radialGradient></defs>`;
// la tête du dragon, de face (moitié gauche dessinée, l'autre en miroir)
const tete = (u, rang) => { const corne = rang === 'V' ? 'M96 110 C88 96 84 84 88 70 C94 82 102 92 110 100 Z' : rang === 'D' ? 'M92 112 C70 100 54 72 66 40 C68 66 84 82 108 102 Z' : 'M92 112 C76 92 62 60 70 30 C78 58 92 84 108 102 Z';
  const cote = `<path d="${corne}" fill="url(#dfo-${u})" stroke="${SANG}" stroke-width="1.2" stroke-linejoin="round"/><path d="M80 150 L52 138 L72 166 L48 176 L78 190 L60 206 L88 208 Z" fill="url(#dfr-${u})" stroke="${SANG}" stroke-width="1.2" stroke-linejoin="round"/>`;
  const face = `<path d="M94 152 L121 163 L95 168 Z" fill="${SANG}"/><path class="df-oeil" d="M98 169 L120 173 L101 181 Z" fill="${OR}"/><ellipse cx="116" cy="238" rx="3.6" ry="2.4" fill="${NUIT}"/><path d="M104 214 l4 9 4 -8 M108 232 l3 8 4 -7" fill="#FFF3E0" stroke="${SANG}" stroke-width=".6"/><path d="M104 126 q6 -5 12 0 M100 138 q6 -5 12 0 M112 136 q6 -5 12 0" fill="none" stroke="${SANG}" stroke-width="1.1" opacity=".7"/>`;
  return `${cote}${miroir(cote)}<path d="M125 96 C150 96 170 118 172 150 C174 176 160 196 152 214 L140 248 L125 256 L110 248 L98 214 C90 196 76 176 78 150 C80 118 100 96 125 96 Z" fill="url(#dfr-${u})" stroke="${SANG}" stroke-width="1.6" stroke-linejoin="round"/><path d="M125 96 C150 96 170 118 172 150 C174 176 160 196 152 214 L140 248 L125 256 Z" fill="#000" opacity=".2"/>
<path d="M125 100 L121 120 L125 136 L129 120 Z M125 140 L122 156 L125 168 L128 156 Z" fill="url(#dfo-${u})" opacity=".9"/>${face}${miroir(face)}`; };
const coiffe = (u, rang) => rang === 'R' ? `<path d="M103 100 L98 70 L111 86 L125 60 L139 86 L152 70 L147 100 Z" fill="url(#dfo-${u})" stroke="${SANG}" stroke-width="1.4" stroke-linejoin="round"/><rect x="102" y="94" width="46" height="9" rx="2" fill="${OR}" stroke="${SANG}" stroke-width="1.1"/><circle cx="125" cy="98.500" r="2.6" fill="#C81E1E"/>`
  : rang === 'D' ? `<path d="M106 102 L110 84 L118 96 L125 78 L132 96 L140 84 L144 102 Q125 92 106 102 Z" fill="url(#dfo-${u})" stroke="${SANG}" stroke-width="1.2" stroke-linejoin="round"/><circle cx="125" cy="77" r="3" fill="#FFF3E0"/><path d="M100 262 Q125 284 150 262" fill="none" stroke="${OR}" stroke-width="1.6"/>${[108, 116, 125, 134, 142].map((x, i) => `<circle cx="${x}" cy="${[270, 274, 276, 274, 270][i]}" r="2.6" fill="#FFF3E0" stroke="${SANG}" stroke-width=".6"/>`).join('')}`
  : `<path d="M98 122 C100 96 150 96 152 122 L146 112 L125 106 L104 112 Z" fill="#8a8f98" stroke="${SANG}" stroke-width="1.2" stroke-linejoin="round"/><path d="M125 98 V110" stroke="${SANG}" stroke-width="1.2"/>`;
const braises = (nb, g) => { const h = hasard(g); return Array.from({ length: nb }, (_, i) => `<circle class="df-braise" style="--x:${n(14 + h() * 222)}px;--t:${n(3 + h() * 3.5)}s;--d:${n(-h() * 6)}s" r="${n(1 + h() * 1.6)}" fill="${i % 3 ? ORANGE : BRAISE}"/>`).join(''); };
// le brasier du bas : deux rangées de vraies flammes (encre, trois tons) qui vacillent chacune à son rythme
const brasier = (y, nb = 9, g = 1) => flammes({ y: y + 2, h: 74, nb: nb - 1, couleurs: [NUIT, '#B8231A', ORANGE, BRAISE], graine: g + 40, ep: 2 }) + flammes({ y: y + 4, h: 48, nb, couleurs: [NUIT, '#E0431B', '#FFB347', BRAISE], graine: g + 41, ep: 2 });
const bord = `<rect x="7" y="7" width="${L - 14}" height="${H - 14}" rx="16" fill="none" stroke="${ORANGE}" stroke-width="2.2"/><rect x="12.5" y="12.5" width="${L - 25}" height="${H - 25}" rx="12" fill="none" stroke="${OR}" stroke-width=".9" opacity=".7"/>`;

export default {
  id: 'E-001', cle: 'e001-dragon-de-feu', nom: 'Dragon de feu', rarete: 'Épique', fx: 'df', aura: ['#FF7A1A', '#C81E1E'],
  bouge: 'Les flammes ondulent derrière le dragon, ses yeux luisent, des braises montent. Au recto, le roi, la dame et le valet sont trois dragons ; chaque enseigne a sa flamme.',
  retournement: 'Un éclair orange et une onde de chaleur.',
  face: { papier: '#1d0606', encre: '#FFF3E0', rouge: '#FF5A3C', sombre: true, contour: NUIT, contourEp: 6, onglet: NUIT, ongletOp: 0.5 },
  css: `
.df-flamme { transform-origin: 0 0; animation: df-flamme 1.5s ease-in-out infinite alternate; animation-delay: calc(var(--i) * -.23s); }
@keyframes df-flamme { from { transform: scale(.94, .86) skewX(-5deg); } to { transform: scale(1.05, 1.14) skewX(6deg); } }
.df-oeil { animation: df-oeil 3.4s ease-in-out infinite; }
@keyframes df-oeil { 0%, 100% { opacity: .75; } 45% { opacity: 1; } 50% { opacity: .2; } 55% { opacity: 1; } }
.df-braise { opacity: 0; animation: df-braise var(--t) linear infinite; animation-delay: var(--d); }
@keyframes df-braise { 0% { transform: translate(var(--x), 352px); opacity: 0; } 12% { opacity: 1; } 100% { transform: translate(calc(var(--x) + 16px), 40px); opacity: 0; } }
.df-souffle { transform-origin: 125px 246px; animation: df-souffle 2.8s ease-in-out infinite; }
@keyframes df-souffle { 0%, 100% { transform: scale(.6); opacity: .3; } 50% { transform: scale(1.1); opacity: 1; } }
.df-cercle { transform-origin: 125px 176px; animation: df-cercle 30s linear infinite; }
@keyframes df-cercle { to { transform: rotate(360deg); } }
`,
  dos(u) {
    return `${defs(u)}${cadre(`fill="url(#dff-${u})"`)}<circle cx="125" cy="180" r="120" fill="url(#dfl-${u})"/>
${brasier(352, 9)}${[[66, 206, 2.6, 0, '#E0431B', -14], [184, 206, 2.6, 3, '#E0431B', 14], [96, 150, 3, 1, ORANGE, -6], [154, 150, 3, 4, ORANGE, 6], [125, 120, 3.4, 2, ORANGE, 0]].map((a) => flamme(...a)).join('')}
${tete(u, 'R')}
<g class="df-souffle">${flamme(116, 236, .5, 1, BRAISE, -12)}${flamme(134, 236, .5, 4, BRAISE, 12)}</g>
${braises(16, 5)}${bord}
${[[26, 30, 0], [224, 30, 90], [224, 320, 180], [26, 320, 270]].map(([x, y, a]) => `<g transform="translate(${x} ${y})"><path d="${eclat4(9, .3)}" fill="${OR}"/></g>`).join('')}`;
  },
  recto(c) {
    const u = c.u;
    return { fond: `${defs(u)}${cadre(`fill="url(#dff-${u})"`)}<circle cx="125" cy="180" r="124" fill="url(#dfl-${u})" opacity=".8"/>${brasier(354, 8)}`, bord, devant: braises(8, 3 + c.num) };
  },
  pip(c, p, i) {
    const k = n(p.t / 30, 2);
    return `<g transform="translate(${p.x} ${p.y})${p.bas ? ' rotate(180)' : ''}">${flamme(0, n(p.t * .46), n(k * 1.02), i, ORANGE)}${enseigne(c.ens, 0, 0, p.t, `fill="${c.encre}" stroke="${NUIT}" stroke-width=".8"`)}</g>`;
  },
  as(c) {
    const tour = Array.from({ length: 14 }, (_, i) => { const a = (i / 14) * 360; return `<g transform="rotate(${n(a)} 125 176)">${flamme(125, 96, 0.8, i, i % 2 ? ORANGE : '#E0431B')}</g>`; }).join('');
    return `<circle cx="125" cy="176" r="98" fill="url(#dfl-${c.u})"/><g class="df-cercle">${tour}</g><circle cx="125" cy="176" r="76" fill="${NUIT}" stroke="${ORANGE}" stroke-width="2.4"/><circle cx="125" cy="176" r="70" fill="none" stroke="${OR}" stroke-width=".9" stroke-dasharray="3 5"/>
${flamme(125, 236, 2.3, 1, '#E0431B')}${enseigne(c.ens, 125, 176, 96, `fill="${c.encre}" stroke="${NUIT}" stroke-width="1"`)}`;
  },
  figure(c) {
    const u = c.u;
    return `${[[70, 214, 2.4, 0, '#E0431B', -14], [180, 214, 2.4, 3, '#E0431B', 14], [125, 130, 3, 2, ORANGE, 0]].map((a) => flamme(...a)).join('')}
<path d="M40 350 C44 306 66 280 100 268 L150 268 C184 280 206 306 210 350 Z" fill="url(#dfr-${u})" stroke="${SANG}" stroke-width="1.4"/><path d="M125 268 L150 268 C184 280 206 306 210 350 L125 350 Z" fill="#000" opacity=".2"/>
<path d="M84 284 q10 -8 20 0 M146 284 q10 -8 20 0 M70 306 q10 -8 20 0 M160 306 q10 -8 20 0" fill="none" stroke="${SANG}" stroke-width="1.2" opacity=".7"/>
<circle cx="125" cy="312" r="20" fill="${NUIT}" stroke="${OR}" stroke-width="1.8"/>${enseigne(c.ens, 125, 312, 25, `fill="${c.encre}"`)}
<g transform="translate(0 -6)">${tete(u, c.rang)}${coiffe(u, c.rang)}<g class="df-souffle">${flamme(116, 236, c.rang === 'V' ? .32 : .5, 1, BRAISE, -12)}${flamme(134, 236, c.rang === 'V' ? .32 : .5, 4, BRAISE, 12)}</g></g>`;
  },
};
