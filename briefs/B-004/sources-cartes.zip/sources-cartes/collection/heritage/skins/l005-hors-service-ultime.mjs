// L-005 Hors Service Ultime (version 2) : l'enseigne au néon au dos ; au recto, le patron, la patronne et le serveur en tubes
// de néon qui changent de pose, enseignes en néon dont une est toujours en panne, as sur le panneau « HORS SERVICE » qui se balance.
import v1 from '../dos/l005-hors-service-ultime.mjs';
import { L, H, cadre, n, enseigne, ENSEIGNES, eclat4, miroir } from '../outils.mjs';
const OR = '#FFC93C', OR2 = '#FFD76A', JAUNE = '#FFD400', IVOIRE = '#F6F1E4';
const neon = (d, coul, w = 2.6, cl = '') => `<g${cl ? ` class="${cl}"` : ''} fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="${d}" stroke="${coul}" stroke-width="${n(w * 3.4)}" opacity=".2"/><path d="${d}" stroke="${coul}" stroke-width="${w}"/><path d="${d}" stroke="#fff" stroke-width="${n(w * .34, 2)}" opacity=".85"/></g>`;
const tubeEnseigne = (c, t, plein = 0.26) => { const k = t / 24, sw = n(2.7 / k, 2), E = ENSEIGNES[c.ens]; return `<g transform="translate(${n(-t / 2)} ${n(-t / 2)}) scale(${n(k, 3)})"><path d="${E}" fill="${c.encre}" opacity="${plein}"/><path d="${E}" fill="none" stroke="${c.encre}" stroke-width="${n(sw * 3.2, 2)}" opacity=".22" stroke-linejoin="round"/><path d="${E}" fill="none" stroke="${c.encre}" stroke-width="${sw}" stroke-linejoin="round"/><path d="${E}" fill="none" stroke="#fff" stroke-width="${n(sw * .32, 2)}" opacity=".85" stroke-linejoin="round"/></g>`; };
const ruban = (u, k, x, y, a, inv) => `<g transform="translate(${x} ${y}) rotate(${a})"><clipPath id="hur${k}-${u}"><rect x="-90" y="-9" width="180" height="18"/></clipPath><rect x="-90" y="-9" width="180" height="18" fill="${JAUNE}"/><g clip-path="url(#hur${k}-${u})"><g class="hu-bande${inv ? ' inv' : ''}">${Array.from({ length: 12 }, (_, i) => `<path d="M${-120 + i * 24} 9 L${-108 + i * 24} -9 L${-96 + i * 24} -9 L${-108 + i * 24} 9 Z" fill="#111"/>`).join('')}</g></g><path d="M-90 -9 H90 M-90 9 H90" stroke="#111" stroke-width="1.2"/></g>`;
// le buste commun : épaules, cou, tête ronde ; puis chacun sa coiffe, son visage et ses deux poses
const buste = (c) => neon('M50 350 C52 304 74 276 106 266 M144 266 C176 276 198 304 200 350 M112 228 V264 M138 228 V264', OR) + neon('M125 122 A36 36 0 1 0 125.1 122', OR) + `<g transform="translate(125 316)">${tubeEnseigne(c, 34)}</g>`;
const pose = (a, b) => `<g class="hu-pose-a">${a}</g><g class="hu-pose-b">${b}</g>`;
const chope = (x, y, a) => `<g transform="translate(${x} ${y}) rotate(${a})">${neon('M-11 -12 H11 V14 H-11 Z M11 -5 H18 V7 H11', OR2, 2.2)}${neon('M-12 -13 C-12 -20 -4 -20 -3 -15 C-1 -21 7 -20 7 -15 C10 -19 14 -16 12 -12', IVOIRE, 2)}</g>`;
const roi = (c) => buste(c)
  + neon('M97 132 L91 96 L108 116 L125 88 L142 116 L159 96 L153 132 Z', OR, 2.8, 'hu-tube panne') + neon('M108 108 l0 .1 M125 100 l0 .1 M142 108 l0 .1', c.encre, 3.4)
  + neon('M108 152 l0 .1 M142 152 l0 .1', IVOIRE, 4.2) + neon('M125 170 C116 162 104 166 100 176 M125 170 C134 162 146 166 150 176', IVOIRE, 2.6) + neon('M116 182 Q125 188 134 182', c.encre, 2.2)
  + pose(neon('M172 286 L204 232', OR) + chope(210, 204, 8), neon('M172 286 L176 226', OR) + chope(166, 198, -52) + neon('M150 206 l0 .1 M144 214 l0 .1', IVOIRE, 2.4))
  + neon('M78 286 L60 330', OR);
const dame = (c) => buste(c)
  + neon('M104 126 L108 104 L117 118 L125 98 L133 118 L142 104 L146 126', OR, 2.6, 'hu-tube panne')
  + neon('M90 150 C70 150 66 182 84 190 C74 196 76 214 92 212 M160 150 C180 150 184 182 166 190 C176 196 174 214 158 212', c.encre, 2.4)
  + pose(neon('M106 152 q5 -5 10 0 M134 152 q5 -5 10 0', IVOIRE, 2.6), neon('M106 152 q5 -5 10 0 M134 150 h10', IVOIRE, 2.6))
  + neon('M117 178 Q125 186 133 178 Q125 181 117 178 Z', c.encre, 2.2) + neon('M110 240 Q125 254 140 240', IVOIRE, 2)
  + pose(neon('M78 286 L52 236', OR) + `<g transform="translate(46 204)">${neon('M-16 -14 H16 L0 6 Z M0 6 V22 M-9 22 H9', OR2, 2.2)}${neon('M-5 -6 l0 .1', c.encre, 5)}</g>`, neon('M78 286 L58 230', OR) + `<g transform="translate(56 198) rotate(14)">${neon('M-16 -14 H16 L0 6 Z M0 6 V22 M-9 22 H9', OR2, 2.2)}${neon('M-5 -6 l0 .1', c.encre, 5)}</g>`)
  + neon('M172 286 L190 330', OR);
const valet = (c) => buste(c)
  + neon('M94 138 C96 112 154 112 156 138 Z M156 138 H178', OR, 2.8, 'hu-tube panne')
  + neon('M110 156 l0 .1 M140 156 l0 .1', IVOIRE, 4.2) + neon('M112 176 Q126 190 140 174', c.encre, 2.4)
  + neon('M125 268 L108 258 V278 Z M125 268 L142 258 V278 Z', c.encre, 2.2)
  + neon('M172 286 L200 236', OR) + neon('M176 228 H232', IVOIRE, 2.6)
  + pose(`<g transform="translate(196 228)">${neon('M-6 0 V-26 Q-6 -34 -2 -36 V-46 H4 V-36 Q8 -34 8 -26 V0 Z', OR2, 2.2)}</g><g transform="translate(220 228)">${neon('M-7 -18 H7 L4 0 H-4 Z', c.encre, 2)}</g>`,
    `<g transform="translate(196 228) rotate(9)">${neon('M-6 0 V-26 Q-6 -34 -2 -36 V-46 H4 V-36 Q8 -34 8 -26 V0 Z', OR2, 2.2)}</g><g transform="translate(220 228) rotate(-7)">${neon('M-7 -18 H7 L4 0 H-4 Z', c.encre, 2)}</g>`)
  + neon('M78 286 L60 330', OR);

export default {
  ...v1, aura: ['#FFC93C', '#FF4D6A'],
  bouge: 'Dos : l’enseigne « HORS SERVICE » s’allume lettre par lettre, les rubans de chantier défilent, le voyant clignote. Recto : le patron, la patronne et le serveur sont des néons de bar qui changent de pose (la chope se lève, le clin d’œil, le plateau qui penche), avec un tube toujours en panne dans la coiffe. Sur les chiffres, les enseignes s’allument en série et l’une d’elles grésille. L’as est un panneau « HORS SERVICE » qui se balance à son clou.',
  retournement: 'Flash blanc, onde dorée et gerbe d’étincelles, comme un néon qu’on rallume.',
  face: { papier: '#0B0B0B', encre: '#F6F1E4', rouge: '#FF4D6A', sombre: true, contour: '#000', contourEp: 6, reflet: '#FFD76A', onglet: '#000', ongletOp: 0.55 },
  css: v1.css + `
.hu-bande { animation: hu-bande 1.2s linear infinite; }
.hu-bande.inv { animation-direction: reverse; }
@keyframes hu-bande { to { transform: translateX(24px); } }
.hu-tube { animation: hu-allume 6.4s linear infinite; animation-delay: calc(var(--i, 0) * .13s); }
@keyframes hu-allume { 0% { opacity: .12; } 1.5% { opacity: 1; } 2.5% { opacity: .25; } 4% { opacity: 1; } 5% { opacity: .5; } 6%, 100% { opacity: 1; } }
.hu-tube.panne { animation: hu-panne 3.3s steps(1) infinite; }
@keyframes hu-panne { 0%, 100% { opacity: 1; } 38% { opacity: .32; } 41% { opacity: 1; } 44% { opacity: .32; } 52% { opacity: .9; } 55% { opacity: .32; } 70% { opacity: 1; } }
.hu-pose-a { animation: hu-pose 1.9s steps(1) infinite; }
.hu-pose-b { opacity: 0; animation: hu-pose 1.9s steps(1) infinite; animation-delay: -.95s; }
@keyframes hu-pose { 0%, 100% { opacity: 1; } 50% { opacity: 0; } }
.hu-balance { transform-origin: 125px 36px; animation: hu-balance 3.2s ease-in-out infinite alternate; }
@keyframes hu-balance { from { transform: rotate(-5.5deg); } to { transform: rotate(5.5deg); } }
.hu-neon-cadre { animation: hu-neon-cadre 5.2s linear infinite; }
@keyframes hu-neon-cadre { 0%, 100% { opacity: 1; } 46% { opacity: 1; } 47% { opacity: .35; } 48.5% { opacity: 1; } 50% { opacity: .5; } 51% { opacity: 1; } }
.hu-grain { animation: hu-grain 2.4s ease-in-out infinite; animation-delay: var(--d); }
@keyframes hu-grain { 0%, 100% { transform: scale(.3) rotate(0deg); opacity: 0; } 50% { transform: scale(1) rotate(60deg); opacity: 1; } }
`,
  recto(c) {
    const u = c.u;
    return {
      fond: `<defs><pattern id="hub-${u}" width="44" height="22" patternUnits="userSpaceOnUse"><path d="M0 0 H44 M0 11 H44 M22 0 V11 M0 11 V22 M44 11 V22" fill="none" stroke="#1d1a15" stroke-width="1.4"/></pattern><radialGradient id="hug-${u}"><stop offset="0" stop-color="${OR}" stop-opacity=".2"/><stop offset="1" stop-color="${OR}" stop-opacity="0"/></radialGradient></defs>
${cadre('fill="#0B0B0B"')}${cadre(`fill="url(#hub-${u})"`)}<ellipse cx="125" cy="180" rx="130" ry="160" fill="url(#hug-${u})"/>${ruban(u, 'a', 208, 34, 32, false)}${ruban(u, 'b', 42, 316, 32, true)}`,
      bord: `<g class="hu-neon-cadre"><rect x="8" y="8" width="${L - 16}" height="${H - 16}" rx="15" fill="none" stroke="${OR}" stroke-width="8" opacity=".2"/><rect x="8" y="8" width="${L - 16}" height="${H - 16}" rx="15" fill="none" stroke="${OR}" stroke-width="2.6"/><rect x="8" y="8" width="${L - 16}" height="${H - 16}" rx="15" fill="none" stroke="#fff" stroke-width=".8" opacity=".8"/></g><rect x="14.5" y="14.5" width="${L - 29}" height="${H - 29}" rx="10" fill="none" stroke="${OR}" stroke-width=".9" opacity=".5"/>`,
      devant: [[30, 150, 7, 0], [222, 210, 6, -.9], [60, 60, 5, -1.6]].map(([x, y, r, d]) => `<g transform="translate(${x} ${y})"><path class="hu-grain" style="--d:${d}s" d="${eclat4(r)}" fill="${OR2}"/></g>`).join(''),
    };
  },
  pip(c, p, i) {
    const panne = i === (c.num > 4 ? c.num - 2 : 0);
    return `<g transform="translate(${p.x} ${p.y})${p.bas ? ' rotate(180)' : ''}"><g class="hu-tube${panne ? ' panne' : ''}" style="--i:${i}">${tubeEnseigne(c, p.t)}</g></g>`;
  },
  as(c) {
    return `<circle cx="125" cy="36" r="4.4" fill="#8a8170" stroke="#000" stroke-width="1"/>
<g class="hu-balance"><path d="M125 36 L84 110 M125 36 L166 110" stroke="#8a8170" stroke-width="2" stroke-dasharray="5 3"/>
<rect x="64" y="108" width="122" height="150" rx="11" fill="#14110d" stroke="#000" stroke-width="2"/>
<g class="hu-neon-cadre"><rect x="70" y="114" width="110" height="138" rx="8" fill="none" stroke="${OR}" stroke-width="7" opacity=".2"/><rect x="70" y="114" width="110" height="138" rx="8" fill="none" stroke="${OR}" stroke-width="2.4"/><rect x="70" y="114" width="110" height="138" rx="8" fill="none" stroke="#fff" stroke-width=".7" opacity=".8"/></g>
<g transform="translate(125 160)"><g class="hu-tube" style="--i:0">${tubeEnseigne(c, 68, 0.3)}</g></g>
<g font-family="'Alfa Slab One', Georgia, serif" font-size="17" text-anchor="middle" fill="${OR2}" stroke="${OR}" stroke-width="3.4" stroke-opacity=".25" paint-order="stroke"><text x="125" y="221">HORS</text><text class="hu-tube panne" x="125" y="241">SERVICE</text></g></g>`;
  },
  figure(c) { return c.rang === 'R' ? roi(c) : c.rang === 'D' ? dame(c) : valet(c); },
};
