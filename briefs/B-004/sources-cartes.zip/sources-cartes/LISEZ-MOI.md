# Sources des cartes custom (B-004)

Le dessin des 100 skins de cartes (5 légendaires, 10 épiques, 30 rares, 55 communes), en code : chaque carte est un SVG
dessiné à la demande, en aplats avec un trait d'encre et des trames, sans dégradé ni filtre (charte du Drive).
Les animations sont en CSS (transform et opacity seulement).

## Construire cartes-skins.js (le fichier de l'appli)

```
npm i -g esbuild              # une fois
cd collection
node controle.mjs             # contrôles : 100 skins, 5/10/30/55, pas de dégradé, pas de filtre, pas de référence cassée
node appli/construire.mjs ../../site/cartes-skins.js
```

`appli/cartes-skins.src.mjs` est l'entrée : il habille les cartes de l'appli (`.pc`) avec le skin choisi
et expose `window.HS_CARTES` (liste, dos, recto, activer, animer, budget) pour `compte.js`.
Les noms anglais des skins sont dans `appli/noms-anglais.mjs`.

## Où est quoi

- `collection/kit/` : le dessin commun. `carte.mjs` (dos, rectos, coins à la place de ceux de l'appli), `figures.mjs`
  (rois, dames, valets : trois silhouettes, sept styles, variantes par skin), `effets.mjs` (flammes, braises, foudre,
  fumée, étincelles, bulles, pièces, pluie, vent), `aplat.mjs` (transforme les anciens dégradés en aplats),
  `glyphes.json` (les chiffres et lettres des coins, en contours : pas de police à charger).
- `collection/skins/` : les fiches des 100 skins. `themes.mjs` ajoute aux épiques et légendaires leurs effets animés.
- `collection/heritage/` : les dos et skins du premier jet repris dans la collection (légendaires, E-001, E-004).
- `catalogue/concepts.mjs` : les 100 concepts validés (textes du dos et du recto).

## Outils (facultatifs, avec Playwright : `npm i playwright`)

- `node galerie.mjs` : la galerie des 100 skins en une page (`galerie-100-skins.html`).
- `node exporter.mjs` : un dossier par skin (SVG autonomes animés, vignettes, fiche), catalogue JSON et CSV.
- `node planches.mjs` : planches d'aperçu par rareté. `node film-collection.mjs Légendaire sortie.mp4 5` : film (ffmpeg).
- `node test-galerie.mjs`, `node test-svg.mjs` : essais de la galerie et des SVG exportés.
